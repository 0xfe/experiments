// This file is a hack to support loading `tools/fonts/inspector/otf.html` in a local browser.
// We prepend `window.SMuFLGlyphInfo = ` to the `glyphnames.json` file to make this
// object available as a global variable named: `SMuFLGlyphInfo`.
window.SMuFLGlyphInfo = {
  '4stringTabClef': {
    codepoint: 'U+E06E',
  },
  '6stringTabClef': {
    codepoint: 'U+E06D',
  },
  accSagittal11LargeDiesisDown: {
    codepoint: 'U+E30D',
  },
  accSagittal11LargeDiesisUp: {
    codepoint: 'U+E30C',
  },
  accSagittal11MediumDiesisDown: {
    codepoint: 'U+E30B',
  },
  accSagittal11MediumDiesisUp: {
    codepoint: 'U+E30A',
  },
  accSagittal11v19LargeDiesisDown: {
    codepoint: 'U+E3AB',
  },
  accSagittal11v19LargeDiesisUp: {
    codepoint: 'U+E3AA',
  },
  accSagittal11v19MediumDiesisDown: {
    codepoint: 'U+E3A3',
  },
  accSagittal11v19MediumDiesisUp: {
    codepoint: 'U+E3A2',
  },
  accSagittal11v49CommaDown: {
    codepoint: 'U+E397',
  },
  accSagittal11v49CommaUp: {
    codepoint: 'U+E396',
  },
  accSagittal143CommaDown: {
    codepoint: 'U+E395',
  },
  accSagittal143CommaUp: {
    codepoint: 'U+E394',
  },
  accSagittal17CommaDown: {
    codepoint: 'U+E343',
  },
  accSagittal17CommaUp: {
    codepoint: 'U+E342',
  },
  accSagittal17KleismaDown: {
    codepoint: 'U+E393',
  },
  accSagittal17KleismaUp: {
    codepoint: 'U+E392',
  },
  accSagittal19CommaDown: {
    codepoint: 'U+E399',
  },
  accSagittal19CommaUp: {
    codepoint: 'U+E398',
  },
  accSagittal19SchismaDown: {
    codepoint: 'U+E391',
  },
  accSagittal19SchismaUp: {
    codepoint: 'U+E390',
  },
  accSagittal1MinaDown: {
    codepoint: 'U+E3F5',
  },
  accSagittal1MinaUp: {
    codepoint: 'U+E3F4',
  },
  accSagittal1TinaDown: {
    codepoint: 'U+E3F9',
  },
  accSagittal1TinaUp: {
    codepoint: 'U+E3F8',
  },
  accSagittal23CommaDown: {
    codepoint: 'U+E371',
  },
  accSagittal23CommaUp: {
    codepoint: 'U+E370',
  },
  accSagittal23SmallDiesisDown: {
    codepoint: 'U+E39F',
  },
  accSagittal23SmallDiesisUp: {
    codepoint: 'U+E39E',
  },
  accSagittal25SmallDiesisDown: {
    codepoint: 'U+E307',
  },
  accSagittal25SmallDiesisUp: {
    codepoint: 'U+E306',
  },
  accSagittal2MinasDown: {
    codepoint: 'U+E3F7',
  },
  accSagittal2MinasUp: {
    codepoint: 'U+E3F6',
  },
  accSagittal2TinasDown: {
    codepoint: 'U+E3FB',
  },
  accSagittal2TinasUp: {
    codepoint: 'U+E3FA',
  },
  accSagittal35LargeDiesisDown: {
    codepoint: 'U+E30F',
  },
  accSagittal35LargeDiesisUp: {
    codepoint: 'U+E30E',
  },
  accSagittal35MediumDiesisDown: {
    codepoint: 'U+E309',
  },
  accSagittal35MediumDiesisUp: {
    codepoint: 'U+E308',
  },
  accSagittal3TinasDown: {
    codepoint: 'U+E3FD',
  },
  accSagittal3TinasUp: {
    codepoint: 'U+E3FC',
  },
  accSagittal49LargeDiesisDown: {
    codepoint: 'U+E3A9',
  },
  accSagittal49LargeDiesisUp: {
    codepoint: 'U+E3A8',
  },
  accSagittal49MediumDiesisDown: {
    codepoint: 'U+E3A5',
  },
  accSagittal49MediumDiesisUp: {
    codepoint: 'U+E3A4',
  },
  accSagittal49SmallDiesisDown: {
    codepoint: 'U+E39D',
  },
  accSagittal49SmallDiesisUp: {
    codepoint: 'U+E39C',
  },
  accSagittal4TinasDown: {
    codepoint: 'U+E3FF',
  },
  accSagittal4TinasUp: {
    codepoint: 'U+E3FE',
  },
  accSagittal55CommaDown: {
    codepoint: 'U+E345',
  },
  accSagittal55CommaUp: {
    codepoint: 'U+E344',
  },
  accSagittal5CommaDown: {
    codepoint: 'U+E303',
  },
  accSagittal5CommaUp: {
    codepoint: 'U+E302',
  },
  accSagittal5TinasDown: {
    codepoint: 'U+E401',
  },
  accSagittal5TinasUp: {
    codepoint: 'U+E400',
  },
  accSagittal5v11SmallDiesisDown: {
    codepoint: 'U+E349',
  },
  accSagittal5v11SmallDiesisUp: {
    codepoint: 'U+E348',
  },
  accSagittal5v13LargeDiesisDown: {
    codepoint: 'U+E3AD',
  },
  accSagittal5v13LargeDiesisUp: {
    codepoint: 'U+E3AC',
  },
  accSagittal5v13MediumDiesisDown: {
    codepoint: 'U+E3A1',
  },
  accSagittal5v13MediumDiesisUp: {
    codepoint: 'U+E3A0',
  },
  accSagittal5v19CommaDown: {
    codepoint: 'U+E373',
  },
  accSagittal5v19CommaUp: {
    codepoint: 'U+E372',
  },
  accSagittal5v23SmallDiesisDown: {
    codepoint: 'U+E375',
  },
  accSagittal5v23SmallDiesisUp: {
    codepoint: 'U+E374',
  },
  accSagittal5v49MediumDiesisDown: {
    codepoint: 'U+E3A7',
  },
  accSagittal5v49MediumDiesisUp: {
    codepoint: 'U+E3A6',
  },
  accSagittal5v7KleismaDown: {
    codepoint: 'U+E301',
  },
  accSagittal5v7KleismaUp: {
    codepoint: 'U+E300',
  },
  accSagittal6TinasDown: {
    codepoint: 'U+E403',
  },
  accSagittal6TinasUp: {
    codepoint: 'U+E402',
  },
  accSagittal7CommaDown: {
    codepoint: 'U+E305',
  },
  accSagittal7CommaUp: {
    codepoint: 'U+E304',
  },
  accSagittal7TinasDown: {
    codepoint: 'U+E405',
  },
  accSagittal7TinasUp: {
    codepoint: 'U+E404',
  },
  accSagittal7v11CommaDown: {
    codepoint: 'U+E347',
  },
  accSagittal7v11CommaUp: {
    codepoint: 'U+E346',
  },
  accSagittal7v11KleismaDown: {
    codepoint: 'U+E341',
  },
  accSagittal7v11KleismaUp: {
    codepoint: 'U+E340',
  },
  accSagittal7v19CommaDown: {
    codepoint: 'U+E39B',
  },
  accSagittal7v19CommaUp: {
    codepoint: 'U+E39A',
  },
  accSagittal8TinasDown: {
    codepoint: 'U+E407',
  },
  accSagittal8TinasUp: {
    codepoint: 'U+E406',
  },
  accSagittal9TinasDown: {
    codepoint: 'U+E409',
  },
  accSagittal9TinasUp: {
    codepoint: 'U+E408',
  },
  accSagittalAcute: {
    codepoint: 'U+E3F2',
  },
  accSagittalDoubleFlat: {
    codepoint: 'U+E335',
  },
  accSagittalDoubleFlat11v49CUp: {
    codepoint: 'U+E3E9',
  },
  accSagittalDoubleFlat143CUp: {
    codepoint: 'U+E3EB',
  },
  accSagittalDoubleFlat17CUp: {
    codepoint: 'U+E365',
  },
  accSagittalDoubleFlat17kUp: {
    codepoint: 'U+E3ED',
  },
  accSagittalDoubleFlat19CUp: {
    codepoint: 'U+E3E7',
  },
  accSagittalDoubleFlat19sUp: {
    codepoint: 'U+E3EF',
  },
  accSagittalDoubleFlat23CUp: {
    codepoint: 'U+E387',
  },
  accSagittalDoubleFlat23SUp: {
    codepoint: 'U+E3E1',
  },
  accSagittalDoubleFlat25SUp: {
    codepoint: 'U+E32D',
  },
  accSagittalDoubleFlat49SUp: {
    codepoint: 'U+E3E3',
  },
  accSagittalDoubleFlat55CUp: {
    codepoint: 'U+E363',
  },
  accSagittalDoubleFlat5CUp: {
    codepoint: 'U+E331',
  },
  accSagittalDoubleFlat5v11SUp: {
    codepoint: 'U+E35F',
  },
  accSagittalDoubleFlat5v19CUp: {
    codepoint: 'U+E385',
  },
  accSagittalDoubleFlat5v23SUp: {
    codepoint: 'U+E383',
  },
  accSagittalDoubleFlat5v7kUp: {
    codepoint: 'U+E333',
  },
  accSagittalDoubleFlat7CUp: {
    codepoint: 'U+E32F',
  },
  accSagittalDoubleFlat7v11CUp: {
    codepoint: 'U+E361',
  },
  accSagittalDoubleFlat7v11kUp: {
    codepoint: 'U+E367',
  },
  accSagittalDoubleFlat7v19CUp: {
    codepoint: 'U+E3E5',
  },
  accSagittalDoubleSharp: {
    codepoint: 'U+E334',
  },
  accSagittalDoubleSharp11v49CDown: {
    codepoint: 'U+E3E8',
  },
  accSagittalDoubleSharp143CDown: {
    codepoint: 'U+E3EA',
  },
  accSagittalDoubleSharp17CDown: {
    codepoint: 'U+E364',
  },
  accSagittalDoubleSharp17kDown: {
    codepoint: 'U+E3EC',
  },
  accSagittalDoubleSharp19CDown: {
    codepoint: 'U+E3E6',
  },
  accSagittalDoubleSharp19sDown: {
    codepoint: 'U+E3EE',
  },
  accSagittalDoubleSharp23CDown: {
    codepoint: 'U+E386',
  },
  accSagittalDoubleSharp23SDown: {
    codepoint: 'U+E3E0',
  },
  accSagittalDoubleSharp25SDown: {
    codepoint: 'U+E32C',
  },
  accSagittalDoubleSharp49SDown: {
    codepoint: 'U+E3E2',
  },
  accSagittalDoubleSharp55CDown: {
    codepoint: 'U+E362',
  },
  accSagittalDoubleSharp5CDown: {
    codepoint: 'U+E330',
  },
  accSagittalDoubleSharp5v11SDown: {
    codepoint: 'U+E35E',
  },
  accSagittalDoubleSharp5v19CDown: {
    codepoint: 'U+E384',
  },
  accSagittalDoubleSharp5v23SDown: {
    codepoint: 'U+E382',
  },
  accSagittalDoubleSharp5v7kDown: {
    codepoint: 'U+E332',
  },
  accSagittalDoubleSharp7CDown: {
    codepoint: 'U+E32E',
  },
  accSagittalDoubleSharp7v11CDown: {
    codepoint: 'U+E360',
  },
  accSagittalDoubleSharp7v11kDown: {
    codepoint: 'U+E366',
  },
  accSagittalDoubleSharp7v19CDown: {
    codepoint: 'U+E3E4',
  },
  accSagittalFlat: {
    codepoint: 'U+E319',
  },
  accSagittalFlat11LDown: {
    codepoint: 'U+E329',
  },
  accSagittalFlat11MDown: {
    codepoint: 'U+E327',
  },
  accSagittalFlat11v19LDown: {
    codepoint: 'U+E3DB',
  },
  accSagittalFlat11v19MDown: {
    codepoint: 'U+E3D3',
  },
  accSagittalFlat11v49CDown: {
    codepoint: 'U+E3C7',
  },
  accSagittalFlat11v49CUp: {
    codepoint: 'U+E3B9',
  },
  accSagittalFlat143CDown: {
    codepoint: 'U+E3C5',
  },
  accSagittalFlat143CUp: {
    codepoint: 'U+E3BB',
  },
  accSagittalFlat17CDown: {
    codepoint: 'U+E357',
  },
  accSagittalFlat17CUp: {
    codepoint: 'U+E351',
  },
  accSagittalFlat17kDown: {
    codepoint: 'U+E3C3',
  },
  accSagittalFlat17kUp: {
    codepoint: 'U+E3BD',
  },
  accSagittalFlat19CDown: {
    codepoint: 'U+E3C9',
  },
  accSagittalFlat19CUp: {
    codepoint: 'U+E3B7',
  },
  accSagittalFlat19sDown: {
    codepoint: 'U+E3C1',
  },
  accSagittalFlat19sUp: {
    codepoint: 'U+E3BF',
  },
  accSagittalFlat23CDown: {
    codepoint: 'U+E37D',
  },
  accSagittalFlat23CUp: {
    codepoint: 'U+E37B',
  },
  accSagittalFlat23SDown: {
    codepoint: 'U+E3CF',
  },
  accSagittalFlat23SUp: {
    codepoint: 'U+E3B1',
  },
  accSagittalFlat25SDown: {
    codepoint: 'U+E323',
  },
  accSagittalFlat25SUp: {
    codepoint: 'U+E311',
  },
  accSagittalFlat35LDown: {
    codepoint: 'U+E32B',
  },
  accSagittalFlat35MDown: {
    codepoint: 'U+E325',
  },
  accSagittalFlat49LDown: {
    codepoint: 'U+E3D9',
  },
  accSagittalFlat49MDown: {
    codepoint: 'U+E3D5',
  },
  accSagittalFlat49SDown: {
    codepoint: 'U+E3CD',
  },
  accSagittalFlat49SUp: {
    codepoint: 'U+E3B3',
  },
  accSagittalFlat55CDown: {
    codepoint: 'U+E359',
  },
  accSagittalFlat55CUp: {
    codepoint: 'U+E34F',
  },
  accSagittalFlat5CDown: {
    codepoint: 'U+E31F',
  },
  accSagittalFlat5CUp: {
    codepoint: 'U+E315',
      'Flat 5C-up, 2\u00b0[22 29] 3\u00b0[27 34 41] 4\u00b0[39 46 53] 5\u00b072 7\u00b0[96] down, 5/12-tone down',
  },
  accSagittalFlat5v11SDown: {
    codepoint: 'U+E35D',
  },
  accSagittalFlat5v11SUp: {
    codepoint: 'U+E34B',
  },
  accSagittalFlat5v13LDown: {
    codepoint: 'U+E3DD',
  },
  accSagittalFlat5v13MDown: {
    codepoint: 'U+E3D1',
  },
  accSagittalFlat5v19CDown: {
    codepoint: 'U+E37F',
  },
  accSagittalFlat5v19CUp: {
    codepoint: 'U+E379',
  },
  accSagittalFlat5v23SDown: {
    codepoint: 'U+E381',
  },
  accSagittalFlat5v23SUp: {
    codepoint: 'U+E377',
  },
  accSagittalFlat5v49MDown: {
    codepoint: 'U+E3D7',
  },
  accSagittalFlat5v7kDown: {
    codepoint: 'U+E31D',
  },
  accSagittalFlat5v7kUp: {
    codepoint: 'U+E317',
  },
  accSagittalFlat7CDown: {
    codepoint: 'U+E321',
  },
  accSagittalFlat7CUp: {
    codepoint: 'U+E313',
  },
  accSagittalFlat7v11CDown: {
    codepoint: 'U+E35B',
  },
  accSagittalFlat7v11CUp: {
    codepoint: 'U+E34D',
  },
  accSagittalFlat7v11kDown: {
    codepoint: 'U+E355',
  },
  accSagittalFlat7v11kUp: {
    codepoint: 'U+E353',
  },
  accSagittalFlat7v19CDown: {
    codepoint: 'U+E3CB',
  },
  accSagittalFlat7v19CUp: {
    codepoint: 'U+E3B5',
  },
  accSagittalFractionalTinaDown: {
    codepoint: 'U+E40B',
  },
  accSagittalFractionalTinaUp: {
    codepoint: 'U+E40A',
  },
  accSagittalGrave: {
    codepoint: 'U+E3F3',
  },
  accSagittalShaftDown: {
    codepoint: 'U+E3F1',
  },
  accSagittalShaftUp: {
    codepoint: 'U+E3F0',
  },
  accSagittalSharp: {
    codepoint: 'U+E318',
  },
  accSagittalSharp11LUp: {
    codepoint: 'U+E328',
  },
  accSagittalSharp11MUp: {
    codepoint: 'U+E326',
  },
  accSagittalSharp11v19LUp: {
    codepoint: 'U+E3DA',
  },
  accSagittalSharp11v19MUp: {
    codepoint: 'U+E3D2',
  },
  accSagittalSharp11v49CDown: {
    codepoint: 'U+E3B8',
  },
  accSagittalSharp11v49CUp: {
    codepoint: 'U+E3C6',
  },
  accSagittalSharp143CDown: {
    codepoint: 'U+E3BA',
  },
  accSagittalSharp143CUp: {
    codepoint: 'U+E3C4',
  },
  accSagittalSharp17CDown: {
    codepoint: 'U+E350',
  },
  accSagittalSharp17CUp: {
    codepoint: 'U+E356',
  },
  accSagittalSharp17kDown: {
    codepoint: 'U+E3BC',
  },
  accSagittalSharp17kUp: {
    codepoint: 'U+E3C2',
  },
  accSagittalSharp19CDown: {
    codepoint: 'U+E3B6',
  },
  accSagittalSharp19CUp: {
    codepoint: 'U+E3C8',
  },
  accSagittalSharp19sDown: {
    codepoint: 'U+E3BE',
  },
  accSagittalSharp19sUp: {
    codepoint: 'U+E3C0',
  },
  accSagittalSharp23CDown: {
    codepoint: 'U+E37A',
  },
  accSagittalSharp23CUp: {
    codepoint: 'U+E37C',
  },
  accSagittalSharp23SDown: {
    codepoint: 'U+E3B0',
  },
  accSagittalSharp23SUp: {
    codepoint: 'U+E3CE',
  },
  accSagittalSharp25SDown: {
    codepoint: 'U+E310',
  },
  accSagittalSharp25SUp: {
    codepoint: 'U+E322',
  },
  accSagittalSharp35LUp: {
    codepoint: 'U+E32A',
  },
  accSagittalSharp35MUp: {
    codepoint: 'U+E324',
  },
  accSagittalSharp49LUp: {
    codepoint: 'U+E3D8',
  },
  accSagittalSharp49MUp: {
    codepoint: 'U+E3D4',
  },
  accSagittalSharp49SDown: {
    codepoint: 'U+E3B2',
  },
  accSagittalSharp49SUp: {
    codepoint: 'U+E3CC',
  },
  accSagittalSharp55CDown: {
    codepoint: 'U+E34E',
  },
  accSagittalSharp55CUp: {
    codepoint: 'U+E358',
  },
  accSagittalSharp5CDown: {
    codepoint: 'U+E314',
      'Sharp 5C-down, 2\u00b0[22 29] 3\u00b0[27 34 41] 4\u00b0[39 46 53] 5\u00b0[72] 7\u00b0[96] up, 5/12-tone up',
  },
  accSagittalSharp5CUp: {
    codepoint: 'U+E31E',
  },
  accSagittalSharp5v11SDown: {
    codepoint: 'U+E34A',
  },
  accSagittalSharp5v11SUp: {
    codepoint: 'U+E35C',
  },
  accSagittalSharp5v13LUp: {
    codepoint: 'U+E3DC',
  },
  accSagittalSharp5v13MUp: {
    codepoint: 'U+E3D0',
  },
  accSagittalSharp5v19CDown: {
    codepoint: 'U+E378',
  },
  accSagittalSharp5v19CUp: {
    codepoint: 'U+E37E',
  },
  accSagittalSharp5v23SDown: {
    codepoint: 'U+E376',
  },
  accSagittalSharp5v23SUp: {
    codepoint: 'U+E380',
  },
  accSagittalSharp5v49MUp: {
    codepoint: 'U+E3D6',
  },
  accSagittalSharp5v7kDown: {
    codepoint: 'U+E316',
  },
  accSagittalSharp5v7kUp: {
    codepoint: 'U+E31C',
  },
  accSagittalSharp7CDown: {
    codepoint: 'U+E312',
  },
  accSagittalSharp7CUp: {
    codepoint: 'U+E320',
  },
  accSagittalSharp7v11CDown: {
    codepoint: 'U+E34C',
  },
  accSagittalSharp7v11CUp: {
    codepoint: 'U+E35A',
  },
  accSagittalSharp7v11kDown: {
    codepoint: 'U+E352',
  },
  accSagittalSharp7v11kUp: {
    codepoint: 'U+E354',
  },
  accSagittalSharp7v19CDown: {
    codepoint: 'U+E3B4',
  },
  accSagittalSharp7v19CUp: {
    codepoint: 'U+E3CA',
  },
  accSagittalUnused1: {
    codepoint: 'U+E31A',
  },
  accSagittalUnused2: {
    codepoint: 'U+E31B',
  },
  accSagittalUnused3: {
    codepoint: 'U+E3DE',
  },
  accSagittalUnused4: {
    codepoint: 'U+E3DF',
  },
  accdnCombDot: {
    codepoint: 'U+E8CA',
  },
  accdnCombLH2RanksEmpty: {
    codepoint: 'U+E8C8',
  },
  accdnCombLH3RanksEmptySquare: {
    codepoint: 'U+E8C9',
  },
  accdnCombRH3RanksEmpty: {
    codepoint: 'U+E8C6',
  },
  accdnCombRH4RanksEmpty: {
    codepoint: 'U+E8C7',
  },
  accdnDiatonicClef: {
    codepoint: 'U+E079',
  },
  accdnLH2Ranks16Round: {
    codepoint: 'U+E8BC',
  },
  accdnLH2Ranks8Plus16Round: {
    codepoint: 'U+E8BD',
  },
  accdnLH2Ranks8Round: {
    codepoint: 'U+E8BB',
  },
  accdnLH2RanksFullMasterRound: {
    codepoint: 'U+E8C0',
  },
  accdnLH2RanksMasterPlus16Round: {
    codepoint: 'U+E8BF',
  },
  accdnLH2RanksMasterRound: {
    codepoint: 'U+E8BE',
  },
  accdnLH3Ranks2Plus8Square: {
    codepoint: 'U+E8C4',
  },
  accdnLH3Ranks2Square: {
    codepoint: 'U+E8C2',
  },
  accdnLH3Ranks8Square: {
    codepoint: 'U+E8C1',
  },
  accdnLH3RanksDouble8Square: {
    codepoint: 'U+E8C3',
  },
  accdnLH3RanksTuttiSquare: {
    codepoint: 'U+E8C5',
  },
  accdnPull: {
    codepoint: 'U+E8CC',
  },
  accdnPush: {
    codepoint: 'U+E8CB',
  },
  accdnRH3RanksAccordion: {
    codepoint: 'U+E8AC',
  },
  accdnRH3RanksAuthenticMusette: {
    codepoint: 'U+E8A8',
  },
  accdnRH3RanksBandoneon: {
    codepoint: 'U+E8AB',
  },
  accdnRH3RanksBassoon: {
    codepoint: 'U+E8A4',
  },
  accdnRH3RanksClarinet: {
    codepoint: 'U+E8A1',
  },
  accdnRH3RanksDoubleTremoloLower8ve: {
    codepoint: 'U+E8B1',
  },
  accdnRH3RanksDoubleTremoloUpper8ve: {
    codepoint: 'U+E8B2',
  },
  accdnRH3RanksFullFactory: {
    codepoint: 'U+E8B3',
  },
  accdnRH3RanksHarmonium: {
    codepoint: 'U+E8AA',
  },
  accdnRH3RanksImitationMusette: {
    codepoint: 'U+E8A7',
  },
  accdnRH3RanksLowerTremolo8: {
    codepoint: 'U+E8A3',
  },
  accdnRH3RanksMaster: {
    codepoint: 'U+E8AD',
  },
  accdnRH3RanksOboe: {
    codepoint: 'U+E8A5',
  },
  accdnRH3RanksOrgan: {
    codepoint: 'U+E8A9',
  },
  accdnRH3RanksPiccolo: {
    codepoint: 'U+E8A0',
  },
  accdnRH3RanksTremoloLower8ve: {
    codepoint: 'U+E8AF',
  },
  accdnRH3RanksTremoloUpper8ve: {
    codepoint: 'U+E8B0',
  },
  accdnRH3RanksTwoChoirs: {
    codepoint: 'U+E8AE',
  },
  accdnRH3RanksUpperTremolo8: {
    codepoint: 'U+E8A2',
  },
  accdnRH3RanksViolin: {
    codepoint: 'U+E8A6',
  },
  accdnRH4RanksAlto: {
    codepoint: 'U+E8B5',
  },
  accdnRH4RanksBassAlto: {
    codepoint: 'U+E8BA',
  },
  accdnRH4RanksMaster: {
    codepoint: 'U+E8B7',
  },
  accdnRH4RanksSoftBass: {
    codepoint: 'U+E8B8',
  },
  accdnRH4RanksSoftTenor: {
    codepoint: 'U+E8B9',
  },
  accdnRH4RanksSoprano: {
    codepoint: 'U+E8B4',
  },
  accdnRH4RanksTenor: {
    codepoint: 'U+E8B6',
  },
  accdnRicochet2: {
    codepoint: 'U+E8CD',
  },
  accdnRicochet3: {
    codepoint: 'U+E8CE',
  },
  accdnRicochet4: {
    codepoint: 'U+E8CF',
  },
  accdnRicochet5: {
    codepoint: 'U+E8D0',
  },
  accdnRicochet6: {
    codepoint: 'U+E8D1',
  },
  accdnRicochetStem2: {
    codepoint: 'U+E8D2',
  },
  accdnRicochetStem3: {
    codepoint: 'U+E8D3',
  },
  accdnRicochetStem4: {
    codepoint: 'U+E8D4',
  },
  accdnRicochetStem5: {
    codepoint: 'U+E8D5',
  },
  accdnRicochetStem6: {
    codepoint: 'U+E8D6',
  },
  accidental1CommaFlat: {
    codepoint: 'U+E454',
  },
  accidental1CommaSharp: {
    codepoint: 'U+E450',
  },
  accidental2CommaFlat: {
    codepoint: 'U+E455',
  },
  accidental2CommaSharp: {
    codepoint: 'U+E451',
  },
  accidental3CommaFlat: {
    codepoint: 'U+E456',
  },
  accidental3CommaSharp: {
    codepoint: 'U+E452',
  },
  accidental4CommaFlat: {
    codepoint: 'U+E457',
  },
  accidental5CommaSharp: {
    codepoint: 'U+E453',
  },
  accidentalArrowDown: {
    codepoint: 'U+E27B',
  },
  accidentalArrowUp: {
    codepoint: 'U+E27A',
  },
  accidentalBakiyeFlat: {
    codepoint: 'U+E442',
  },
  accidentalBakiyeSharp: {
    codepoint: 'U+E445',
  },
  accidentalBracketLeft: {
    codepoint: 'U+E26C',
  },
  accidentalBracketRight: {
    codepoint: 'U+E26D',
  },
  accidentalBuyukMucennebFlat: {
    codepoint: 'U+E440',
  },
  accidentalBuyukMucennebSharp: {
    codepoint: 'U+E447',
  },
  accidentalCombiningCloseCurlyBrace: {
    codepoint: 'U+E2EF',
  },
  accidentalCombiningLower17Schisma: {
    codepoint: 'U+E2E6',
  },
  accidentalCombiningLower19Schisma: {
    codepoint: 'U+E2E8',
  },
  accidentalCombiningLower23Limit29LimitComma: {
    codepoint: 'U+E2EA',
  },
  accidentalCombiningLower29LimitComma: {
    codepoint: 'U+EE50',
  },
  accidentalCombiningLower31Schisma: {
    codepoint: 'U+E2EC',
  },
  accidentalCombiningLower37Quartertone: {
    codepoint: 'U+EE52',
  },
  accidentalCombiningLower41Comma: {
    codepoint: 'U+EE54',
  },
  accidentalCombiningLower43Comma: {
    codepoint: 'U+EE56',
  },
  accidentalCombiningLower47Quartertone: {
    codepoint: 'U+EE58',
  },
  accidentalCombiningLower53LimitComma: {
    codepoint: 'U+E2F7',
  },
  accidentalCombiningOpenCurlyBrace: {
    codepoint: 'U+E2EE',
  },
  accidentalCombiningRaise17Schisma: {
    codepoint: 'U+E2E7',
  },
  accidentalCombiningRaise19Schisma: {
    codepoint: 'U+E2E9',
  },
  accidentalCombiningRaise23Limit29LimitComma: {
    codepoint: 'U+E2EB',
  },
  accidentalCombiningRaise29LimitComma: {
    codepoint: 'U+EE51',
  },
  accidentalCombiningRaise31Schisma: {
    codepoint: 'U+E2ED',
  },
  accidentalCombiningRaise37Quartertone: {
    codepoint: 'U+EE53',
  },
  accidentalCombiningRaise41Comma: {
    codepoint: 'U+EE55',
  },
  accidentalCombiningRaise43Comma: {
    codepoint: 'U+EE57',
  },
  accidentalCombiningRaise47Quartertone: {
    codepoint: 'U+EE59',
  },
  accidentalCombiningRaise53LimitComma: {
    codepoint: 'U+E2F8',
  },
  accidentalCommaSlashDown: {
    codepoint: 'U+E47A',
  },
  accidentalCommaSlashUp: {
    codepoint: 'U+E479',
  },
  accidentalDoubleFlat: {
    alternateCodepoint: 'U+1D12B',
    codepoint: 'U+E264',
  },
  accidentalDoubleFlatArabic: {
    codepoint: 'U+ED30',
  },
  accidentalDoubleFlatEqualTempered: {
    codepoint: 'U+E2F0',
  },
  accidentalDoubleFlatOneArrowDown: {
    codepoint: 'U+E2C0',
  },
  accidentalDoubleFlatOneArrowUp: {
    codepoint: 'U+E2C5',
  },
  accidentalDoubleFlatReversed: {
    codepoint: 'U+E483',
  },
  accidentalDoubleFlatThreeArrowsDown: {
    codepoint: 'U+E2D4',
  },
  accidentalDoubleFlatThreeArrowsUp: {
    codepoint: 'U+E2D9',
  },
  accidentalDoubleFlatTurned: {
    codepoint: 'U+E485',
  },
  accidentalDoubleFlatTwoArrowsDown: {
    codepoint: 'U+E2CA',
  },
  accidentalDoubleFlatTwoArrowsUp: {
    codepoint: 'U+E2CF',
  },
  accidentalDoubleSharp: {
    alternateCodepoint: 'U+1D12A',
    codepoint: 'U+E263',
  },
  accidentalDoubleSharpArabic: {
    codepoint: 'U+ED38',
  },
  accidentalDoubleSharpEqualTempered: {
    codepoint: 'U+E2F4',
  },
  accidentalDoubleSharpOneArrowDown: {
    codepoint: 'U+E2C4',
  },
  accidentalDoubleSharpOneArrowUp: {
    codepoint: 'U+E2C9',
  },
  accidentalDoubleSharpThreeArrowsDown: {
    codepoint: 'U+E2D8',
  },
  accidentalDoubleSharpThreeArrowsUp: {
    codepoint: 'U+E2DD',
  },
  accidentalDoubleSharpTwoArrowsDown: {
    codepoint: 'U+E2CE',
  },
  accidentalDoubleSharpTwoArrowsUp: {
    codepoint: 'U+E2D3',
  },
  accidentalEnharmonicAlmostEqualTo: {
    codepoint: 'U+E2FA',
  },
  accidentalEnharmonicEquals: {
    codepoint: 'U+E2FB',
  },
  accidentalEnharmonicTilde: {
    codepoint: 'U+E2F9',
  },
  accidentalFilledReversedFlatAndFlat: {
    codepoint: 'U+E296',
  },
  accidentalFilledReversedFlatAndFlatArrowDown: {
    codepoint: 'U+E298',
  },
  accidentalFilledReversedFlatAndFlatArrowUp: {
    codepoint: 'U+E297',
  },
  accidentalFilledReversedFlatArrowDown: {
    codepoint: 'U+E293',
  },
  accidentalFilledReversedFlatArrowUp: {
    codepoint: 'U+E292',
  },
  accidentalFiveQuarterTonesFlatArrowDown: {
    codepoint: 'U+E279',
  },
  accidentalFiveQuarterTonesSharpArrowUp: {
    codepoint: 'U+E276',
  },
  accidentalFlat: {
    alternateCodepoint: 'U+266D',
    codepoint: 'U+E260',
  },
  accidentalFlatArabic: {
    codepoint: 'U+ED32',
  },
  accidentalFlatEqualTempered: {
    codepoint: 'U+E2F1',
  },
  accidentalFlatLoweredStockhausen: {
    codepoint: 'U+ED53',
  },
  accidentalFlatOneArrowDown: {
    codepoint: 'U+E2C1',
  },
  accidentalFlatOneArrowUp: {
    codepoint: 'U+E2C6',
  },
  accidentalFlatRaisedStockhausen: {
    codepoint: 'U+ED52',
  },
  accidentalFlatRepeatedLineStockhausen: {
    codepoint: 'U+ED5C',
  },
  accidentalFlatRepeatedSpaceStockhausen: {
    codepoint: 'U+ED5B',
  },
  accidentalFlatThreeArrowsDown: {
    codepoint: 'U+E2D5',
  },
  accidentalFlatThreeArrowsUp: {
    codepoint: 'U+E2DA',
  },
  accidentalFlatTurned: {
    codepoint: 'U+E484',
  },
  accidentalFlatTwoArrowsDown: {
    codepoint: 'U+E2CB',
  },
  accidentalFlatTwoArrowsUp: {
    codepoint: 'U+E2D0',
  },
  accidentalHabaFlatQuarterToneHigher: {
    codepoint: 'U+EE65',
  },
  accidentalHabaFlatThreeQuarterTonesLower: {
    codepoint: 'U+EE69',
  },
  accidentalHabaQuarterToneHigher: {
    codepoint: 'U+EE64',
  },
  accidentalHabaQuarterToneLower: {
    codepoint: 'U+EE67',
  },
  accidentalHabaSharpQuarterToneLower: {
    codepoint: 'U+EE68',
  },
  accidentalHabaSharpThreeQuarterTonesHigher: {
    codepoint: 'U+EE66',
  },
  accidentalHalfSharpArrowDown: {
    codepoint: 'U+E29A',
  },
  accidentalHalfSharpArrowUp: {
    codepoint: 'U+E299',
  },
  accidentalJohnston13: {
    codepoint: 'U+E2B6',
  },
  accidentalJohnston31: {
    codepoint: 'U+E2B7',
  },
  accidentalJohnstonDown: {
    codepoint: 'U+E2B5',
  },
  accidentalJohnstonEl: {
    codepoint: 'U+E2B2',
  },
  accidentalJohnstonMinus: {
    codepoint: 'U+E2B1',
  },
  accidentalJohnstonPlus: {
    codepoint: 'U+E2B0',
  },
  accidentalJohnstonSeven: {
    codepoint: 'U+E2B3',
  },
  accidentalJohnstonUp: {
    codepoint: 'U+E2B4',
  },
  accidentalKomaFlat: {
    codepoint: 'U+E443',
  },
  accidentalKomaSharp: {
    codepoint: 'U+E444',
  },
  accidentalKoron: {
    codepoint: 'U+E460',
  },
  accidentalKucukMucennebFlat: {
    codepoint: 'U+E441',
  },
  accidentalKucukMucennebSharp: {
    codepoint: 'U+E446',
  },
  accidentalLargeDoubleSharp: {
    codepoint: 'U+E47D',
  },
  accidentalLowerOneSeptimalComma: {
    codepoint: 'U+E2DE',
  },
  accidentalLowerOneTridecimalQuartertone: {
    codepoint: 'U+E2E4',
  },
  accidentalLowerOneUndecimalQuartertone: {
    codepoint: 'U+E2E2',
  },
  accidentalLowerTwoSeptimalCommas: {
    codepoint: 'U+E2E0',
  },
  accidentalLoweredStockhausen: {
    codepoint: 'U+ED51',
  },
  accidentalNarrowReversedFlat: {
    codepoint: 'U+E284',
  },
  accidentalNarrowReversedFlatAndFlat: {
    codepoint: 'U+E285',
  },
  accidentalNatural: {
    alternateCodepoint: 'U+266E',
    codepoint: 'U+E261',
  },
  accidentalNaturalArabic: {
    codepoint: 'U+ED34',
  },
  accidentalNaturalEqualTempered: {
    codepoint: 'U+E2F2',
  },
  accidentalNaturalFlat: {
    codepoint: 'U+E267',
  },
  accidentalNaturalLoweredStockhausen: {
    codepoint: 'U+ED55',
  },
  accidentalNaturalOneArrowDown: {
    codepoint: 'U+E2C2',
  },
  accidentalNaturalOneArrowUp: {
    codepoint: 'U+E2C7',
  },
  accidentalNaturalRaisedStockhausen: {
    codepoint: 'U+ED54',
  },
  accidentalNaturalReversed: {
    codepoint: 'U+E482',
  },
  accidentalNaturalSharp: {
    codepoint: 'U+E268',
  },
  accidentalNaturalThreeArrowsDown: {
    codepoint: 'U+E2D6',
  },
  accidentalNaturalThreeArrowsUp: {
    codepoint: 'U+E2DB',
  },
  accidentalNaturalTwoArrowsDown: {
    codepoint: 'U+E2CC',
  },
  accidentalNaturalTwoArrowsUp: {
    codepoint: 'U+E2D1',
  },
  accidentalOneAndAHalfSharpsArrowDown: {
    codepoint: 'U+E29C',
  },
  accidentalOneAndAHalfSharpsArrowUp: {
    codepoint: 'U+E29B',
  },
  accidentalOneQuarterToneFlatFerneyhough: {
    codepoint: 'U+E48F',
  },
  accidentalOneQuarterToneFlatStockhausen: {
    codepoint: 'U+ED59',
  },
  accidentalOneQuarterToneSharpFerneyhough: {
    codepoint: 'U+E48E',
  },
  accidentalOneQuarterToneSharpStockhausen: {
    codepoint: 'U+ED58',
  },
  accidentalOneThirdToneFlatFerneyhough: {
    codepoint: 'U+E48B',
  },
  accidentalOneThirdToneSharpFerneyhough: {
    codepoint: 'U+E48A',
  },
  accidentalParensLeft: {
    codepoint: 'U+E26A',
  },
  accidentalParensRight: {
    codepoint: 'U+E26B',
  },
  accidentalQuarterFlatEqualTempered: {
    codepoint: 'U+E2F5',
  },
  accidentalQuarterSharpEqualTempered: {
    codepoint: 'U+E2F6',
  },
  accidentalQuarterToneFlat4: {
    alternateCodepoint: 'U+1D133',
    codepoint: 'U+E47F',
  },
  accidentalQuarterToneFlatArabic: {
    codepoint: 'U+ED33',
  },
  accidentalQuarterToneFlatArrowUp: {
    alternateCodepoint: 'U+1D12C',
    codepoint: 'U+E270',
  },
  accidentalQuarterToneFlatFilledReversed: {
    codepoint: 'U+E480',
  },
  accidentalQuarterToneFlatNaturalArrowDown: {
    alternateCodepoint: 'U+1D12F',
    codepoint: 'U+E273',
  },
  accidentalQuarterToneFlatPenderecki: {
    codepoint: 'U+E478',
  },
  accidentalQuarterToneFlatStein: {
    codepoint: 'U+E280',
  },
  accidentalQuarterToneFlatVanBlankenburg: {
    codepoint: 'U+E488',
  },
  accidentalQuarterToneSharp4: {
    alternateCodepoint: 'U+1D132',
    codepoint: 'U+E47E',
  },
  accidentalQuarterToneSharpArabic: {
    codepoint: 'U+ED35',
  },
  accidentalQuarterToneSharpArrowDown: {
    alternateCodepoint: 'U+1D131',
    codepoint: 'U+E275',
  },
  accidentalQuarterToneSharpBusotti: {
    codepoint: 'U+E472',
  },
  accidentalQuarterToneSharpNaturalArrowUp: {
    alternateCodepoint: 'U+1D12E',
    codepoint: 'U+E272',
  },
  accidentalQuarterToneSharpStein: {
    codepoint: 'U+E282',
  },
  accidentalQuarterToneSharpWiggle: {
    codepoint: 'U+E475',
  },
  accidentalRaiseOneSeptimalComma: {
    codepoint: 'U+E2DF',
  },
  accidentalRaiseOneTridecimalQuartertone: {
    codepoint: 'U+E2E5',
  },
  accidentalRaiseOneUndecimalQuartertone: {
    codepoint: 'U+E2E3',
  },
  accidentalRaiseTwoSeptimalCommas: {
    codepoint: 'U+E2E1',
  },
  accidentalRaisedStockhausen: {
    codepoint: 'U+ED50',
  },
  accidentalReversedFlatAndFlatArrowDown: {
    codepoint: 'U+E295',
  },
  accidentalReversedFlatAndFlatArrowUp: {
    codepoint: 'U+E294',
  },
  accidentalReversedFlatArrowDown: {
    codepoint: 'U+E291',
  },
  accidentalReversedFlatArrowUp: {
    codepoint: 'U+E290',
  },
  accidentalSharp: {
    alternateCodepoint: 'U+266F',
    codepoint: 'U+E262',
  },
  accidentalSharpArabic: {
    codepoint: 'U+ED36',
  },
  accidentalSharpEqualTempered: {
    codepoint: 'U+E2F3',
  },
  accidentalSharpLoweredStockhausen: {
    codepoint: 'U+ED57',
  },
  accidentalSharpOneArrowDown: {
    codepoint: 'U+E2C3',
  },
  accidentalSharpOneArrowUp: {
    codepoint: 'U+E2C8',
  },
  accidentalSharpOneHorizontalStroke: {
    codepoint: 'U+E473',
  },
  accidentalSharpRaisedStockhausen: {
    codepoint: 'U+ED56',
  },
  accidentalSharpRepeatedLineStockhausen: {
    codepoint: 'U+ED5E',
  },
  accidentalSharpRepeatedSpaceStockhausen: {
    codepoint: 'U+ED5D',
  },
  accidentalSharpReversed: {
    codepoint: 'U+E481',
  },
  accidentalSharpSharp: {
    codepoint: 'U+E269',
  },
  accidentalSharpThreeArrowsDown: {
    codepoint: 'U+E2D7',
  },
  accidentalSharpThreeArrowsUp: {
    codepoint: 'U+E2DC',
  },
  accidentalSharpTwoArrowsDown: {
    codepoint: 'U+E2CD',
  },
  accidentalSharpTwoArrowsUp: {
    codepoint: 'U+E2D2',
  },
  accidentalSims12Down: {
    codepoint: 'U+E2A0',
  },
  accidentalSims12Up: {
    codepoint: 'U+E2A3',
  },
  accidentalSims4Down: {
    codepoint: 'U+E2A2',
  },
  accidentalSims4Up: {
    codepoint: 'U+E2A5',
  },
  accidentalSims6Down: {
    codepoint: 'U+E2A1',
  },
  accidentalSims6Up: {
    codepoint: 'U+E2A4',
  },
  accidentalSori: {
    codepoint: 'U+E461',
  },
  accidentalTavenerFlat: {
    codepoint: 'U+E477',
  },
  accidentalTavenerSharp: {
    codepoint: 'U+E476',
  },
  accidentalThreeQuarterTonesFlatArabic: {
    codepoint: 'U+ED31',
  },
  accidentalThreeQuarterTonesFlatArrowDown: {
    alternateCodepoint: 'U+1D12D',
    codepoint: 'U+E271',
  },
  accidentalThreeQuarterTonesFlatArrowUp: {
    codepoint: 'U+E278',
  },
  accidentalThreeQuarterTonesFlatCouper: {
    codepoint: 'U+E489',
  },
  accidentalThreeQuarterTonesFlatGrisey: {
    codepoint: 'U+E486',
  },
  accidentalThreeQuarterTonesFlatTartini: {
    codepoint: 'U+E487',
  },
  accidentalThreeQuarterTonesFlatZimmermann: {
    codepoint: 'U+E281',
  },
  accidentalThreeQuarterTonesSharpArabic: {
    codepoint: 'U+ED37',
  },
  accidentalThreeQuarterTonesSharpArrowDown: {
    codepoint: 'U+E277',
  },
  accidentalThreeQuarterTonesSharpArrowUp: {
    alternateCodepoint: 'U+1D130',
    codepoint: 'U+E274',
  },
  accidentalThreeQuarterTonesSharpBusotti: {
    codepoint: 'U+E474',
  },
  accidentalThreeQuarterTonesSharpStein: {
    codepoint: 'U+E283',
  },
  accidentalThreeQuarterTonesSharpStockhausen: {
    codepoint: 'U+ED5A',
  },
  accidentalTripleFlat: {
    codepoint: 'U+E266',
  },
  accidentalTripleSharp: {
    codepoint: 'U+E265',
  },
  accidentalTwoThirdTonesFlatFerneyhough: {
    codepoint: 'U+E48D',
  },
  accidentalTwoThirdTonesSharpFerneyhough: {
    codepoint: 'U+E48C',
  },
  accidentalUpsAndDownsDown: {
    codepoint: 'U+EE61',
  },
  accidentalUpsAndDownsLess: {
    codepoint: 'U+EE63',
  },
  accidentalUpsAndDownsMore: {
    codepoint: 'U+EE62',
  },
  accidentalUpsAndDownsUp: {
    codepoint: 'U+EE60',
  },
  accidentalWilsonMinus: {
    codepoint: 'U+E47C',
  },
  accidentalWilsonPlus: {
    codepoint: 'U+E47B',
  },
  accidentalWyschnegradsky10TwelfthsFlat: {
    codepoint: 'U+E434',
  },
  accidentalWyschnegradsky10TwelfthsSharp: {
    codepoint: 'U+E429',
  },
  accidentalWyschnegradsky11TwelfthsFlat: {
    codepoint: 'U+E435',
  },
  accidentalWyschnegradsky11TwelfthsSharp: {
    codepoint: 'U+E42A',
  },
  accidentalWyschnegradsky1TwelfthsFlat: {
    codepoint: 'U+E42B',
  },
  accidentalWyschnegradsky1TwelfthsSharp: {
    codepoint: 'U+E420',
  },
  accidentalWyschnegradsky2TwelfthsFlat: {
    codepoint: 'U+E42C',
  },
  accidentalWyschnegradsky2TwelfthsSharp: {
    codepoint: 'U+E421',
  },
  accidentalWyschnegradsky3TwelfthsFlat: {
    codepoint: 'U+E42D',
  },
  accidentalWyschnegradsky3TwelfthsSharp: {
    codepoint: 'U+E422',
  },
  accidentalWyschnegradsky4TwelfthsFlat: {
    codepoint: 'U+E42E',
  },
  accidentalWyschnegradsky4TwelfthsSharp: {
    codepoint: 'U+E423',
  },
  accidentalWyschnegradsky5TwelfthsFlat: {
    codepoint: 'U+E42F',
  },
  accidentalWyschnegradsky5TwelfthsSharp: {
    codepoint: 'U+E424',
  },
  accidentalWyschnegradsky6TwelfthsFlat: {
    codepoint: 'U+E430',
  },
  accidentalWyschnegradsky6TwelfthsSharp: {
    codepoint: 'U+E425',
  },
  accidentalWyschnegradsky7TwelfthsFlat: {
    codepoint: 'U+E431',
  },
  accidentalWyschnegradsky7TwelfthsSharp: {
    codepoint: 'U+E426',
  },
  accidentalWyschnegradsky8TwelfthsFlat: {
    codepoint: 'U+E432',
  },
  accidentalWyschnegradsky8TwelfthsSharp: {
    codepoint: 'U+E427',
  },
  accidentalWyschnegradsky9TwelfthsFlat: {
    codepoint: 'U+E433',
  },
  accidentalWyschnegradsky9TwelfthsSharp: {
    codepoint: 'U+E428',
  },
  accidentalXenakisOneThirdToneSharp: {
    codepoint: 'U+E470',
  },
  accidentalXenakisTwoThirdTonesSharp: {
    codepoint: 'U+E471',
  },
  analyticsChoralmelodie: {
    codepoint: 'U+E86A',
  },
  analyticsEndStimme: {
    alternateCodepoint: 'U+1D1A8',
    codepoint: 'U+E863',
  },
  analyticsHauptrhythmus: {
    codepoint: 'U+E86B',
  },
  analyticsHauptstimme: {
    alternateCodepoint: 'U+1D1A6',
    codepoint: 'U+E860',
  },
  analyticsInversion1: {
    codepoint: 'U+E869',
  },
  analyticsNebenstimme: {
    alternateCodepoint: 'U+1D1A7',
    codepoint: 'U+E861',
  },
  analyticsStartStimme: {
    codepoint: 'U+E862',
  },
  analyticsTheme: {
    codepoint: 'U+E864',
  },
  analyticsTheme1: {
    codepoint: 'U+E868',
  },
  analyticsThemeInversion: {
    codepoint: 'U+E867',
  },
  analyticsThemeRetrograde: {
    codepoint: 'U+E865',
  },
  analyticsThemeRetrogradeInversion: {
    codepoint: 'U+E866',
  },
  arpeggiato: {
    codepoint: 'U+E63C',
  },
  arpeggiatoDown: {
    alternateCodepoint: 'U+1D184',
    codepoint: 'U+E635',
  },
  arpeggiatoUp: {
    alternateCodepoint: 'U+1D183',
    codepoint: 'U+E634',
  },
  arrowBlackDown: {
    codepoint: 'U+EB64',
  },
  arrowBlackDownLeft: {
    codepoint: 'U+EB65',
  },
  arrowBlackDownRight: {
    codepoint: 'U+EB63',
  },
  arrowBlackLeft: {
    codepoint: 'U+EB66',
  },
  arrowBlackRight: {
    codepoint: 'U+EB62',
  },
  arrowBlackUp: {
    codepoint: 'U+EB60',
  },
  arrowBlackUpLeft: {
    codepoint: 'U+EB67',
  },
  arrowBlackUpRight: {
    codepoint: 'U+EB61',
  },
  arrowOpenDown: {
    codepoint: 'U+EB74',
  },
  arrowOpenDownLeft: {
    codepoint: 'U+EB75',
  },
  arrowOpenDownRight: {
    codepoint: 'U+EB73',
  },
  arrowOpenLeft: {
    codepoint: 'U+EB76',
  },
  arrowOpenRight: {
    codepoint: 'U+EB72',
  },
  arrowOpenUp: {
    codepoint: 'U+EB70',
  },
  arrowOpenUpLeft: {
    codepoint: 'U+EB77',
  },
  arrowOpenUpRight: {
    codepoint: 'U+EB71',
  },
  arrowWhiteDown: {
    codepoint: 'U+EB6C',
  },
  arrowWhiteDownLeft: {
    codepoint: 'U+EB6D',
  },
  arrowWhiteDownRight: {
    codepoint: 'U+EB6B',
  },
  arrowWhiteLeft: {
    codepoint: 'U+EB6E',
  },
  arrowWhiteRight: {
    codepoint: 'U+EB6A',
  },
  arrowWhiteUp: {
    codepoint: 'U+EB68',
  },
  arrowWhiteUpLeft: {
    codepoint: 'U+EB6F',
  },
  arrowWhiteUpRight: {
    codepoint: 'U+EB69',
  },
  arrowheadBlackDown: {
    codepoint: 'U+EB7C',
  },
  arrowheadBlackDownLeft: {
    codepoint: 'U+EB7D',
  },
  arrowheadBlackDownRight: {
    codepoint: 'U+EB7B',
  },
  arrowheadBlackLeft: {
    codepoint: 'U+EB7E',
  },
  arrowheadBlackRight: {
    codepoint: 'U+EB7A',
  },
  arrowheadBlackUp: {
    codepoint: 'U+EB78',
  },
  arrowheadBlackUpLeft: {
    codepoint: 'U+EB7F',
  },
  arrowheadBlackUpRight: {
    codepoint: 'U+EB79',
  },
  arrowheadOpenDown: {
    codepoint: 'U+EB8C',
  },
  arrowheadOpenDownLeft: {
    codepoint: 'U+EB8D',
  },
  arrowheadOpenDownRight: {
    codepoint: 'U+EB8B',
  },
  arrowheadOpenLeft: {
    codepoint: 'U+EB8E',
  },
  arrowheadOpenRight: {
    codepoint: 'U+EB8A',
  },
  arrowheadOpenUp: {
    codepoint: 'U+EB88',
  },
  arrowheadOpenUpLeft: {
    codepoint: 'U+EB8F',
  },
  arrowheadOpenUpRight: {
    codepoint: 'U+EB89',
  },
  arrowheadWhiteDown: {
    codepoint: 'U+EB84',
  },
  arrowheadWhiteDownLeft: {
    codepoint: 'U+EB85',
  },
  arrowheadWhiteDownRight: {
    codepoint: 'U+EB83',
  },
  arrowheadWhiteLeft: {
    codepoint: 'U+EB86',
  },
  arrowheadWhiteRight: {
    codepoint: 'U+EB82',
  },
  arrowheadWhiteUp: {
    codepoint: 'U+EB80',
  },
  arrowheadWhiteUpLeft: {
    codepoint: 'U+EB87',
  },
  arrowheadWhiteUpRight: {
    codepoint: 'U+EB81',
  },
  articAccentAbove: {
    alternateCodepoint: 'U+1D17B',
    codepoint: 'U+E4A0',
  },
  articAccentBelow: {
    codepoint: 'U+E4A1',
  },
  articAccentStaccatoAbove: {
    alternateCodepoint: 'U+1D181',
    codepoint: 'U+E4B0',
  },
  articAccentStaccatoBelow: {
    codepoint: 'U+E4B1',
  },
  articLaissezVibrerAbove: {
    codepoint: 'U+E4BA',
  },
  articLaissezVibrerBelow: {
    codepoint: 'U+E4BB',
  },
  articMarcatoAbove: {
    alternateCodepoint: 'U+1D17F',
    codepoint: 'U+E4AC',
  },
  articMarcatoBelow: {
    codepoint: 'U+E4AD',
  },
  articMarcatoStaccatoAbove: {
    alternateCodepoint: 'U+1D180',
    codepoint: 'U+E4AE',
  },
  articMarcatoStaccatoBelow: {
    codepoint: 'U+E4AF',
  },
  articMarcatoTenutoAbove: {
    codepoint: 'U+E4BC',
  },
  articMarcatoTenutoBelow: {
    codepoint: 'U+E4BD',
  },
  articSoftAccentAbove: {
    codepoint: 'U+ED40',
  },
  articSoftAccentBelow: {
    codepoint: 'U+ED41',
  },
  articSoftAccentStaccatoAbove: {
    codepoint: 'U+ED42',
  },
  articSoftAccentStaccatoBelow: {
    codepoint: 'U+ED43',
  },
  articSoftAccentTenutoAbove: {
    codepoint: 'U+ED44',
  },
  articSoftAccentTenutoBelow: {
    codepoint: 'U+ED45',
  },
  articSoftAccentTenutoStaccatoAbove: {
    codepoint: 'U+ED46',
  },
  articSoftAccentTenutoStaccatoBelow: {
    codepoint: 'U+ED47',
  },
  articStaccatissimoAbove: {
    alternateCodepoint: 'U+1D17E',
    codepoint: 'U+E4A6',
  },
  articStaccatissimoBelow: {
    codepoint: 'U+E4A7',
  },
  articStaccatissimoStrokeAbove: {
    codepoint: 'U+E4AA',
  },
  articStaccatissimoStrokeBelow: {
    codepoint: 'U+E4AB',
  },
  articStaccatissimoWedgeAbove: {
    codepoint: 'U+E4A8',
  },
  articStaccatissimoWedgeBelow: {
    codepoint: 'U+E4A9',
  },
  articStaccatoAbove: {
    alternateCodepoint: 'U+1D17C',
    codepoint: 'U+E4A2',
  },
  articStaccatoBelow: {
    codepoint: 'U+E4A3',
  },
  articStressAbove: {
    codepoint: 'U+E4B6',
  },
  articStressBelow: {
    codepoint: 'U+E4B7',
  },
  articTenutoAbove: {
    alternateCodepoint: 'U+1D17D',
    codepoint: 'U+E4A4',
  },
  articTenutoAccentAbove: {
    codepoint: 'U+E4B4',
  },
  articTenutoAccentBelow: {
    codepoint: 'U+E4B5',
  },
  articTenutoBelow: {
    codepoint: 'U+E4A5',
  },
  articTenutoStaccatoAbove: {
    alternateCodepoint: 'U+1D182',
    codepoint: 'U+E4B2',
  },
  articTenutoStaccatoBelow: {
    codepoint: 'U+E4B3',
  },
  articUnstressAbove: {
    codepoint: 'U+E4B8',
  },
  articUnstressBelow: {
    codepoint: 'U+E4B9',
  },
  augmentationDot: {
    alternateCodepoint: 'U+1D16D',
    codepoint: 'U+E1E7',
  },
  barlineDashed: {
    alternateCodepoint: 'U+1D104',
    codepoint: 'U+E036',
  },
  barlineDotted: {
    codepoint: 'U+E037',
  },
  barlineDouble: {
    alternateCodepoint: 'U+1D101',
    codepoint: 'U+E031',
  },
  barlineFinal: {
    alternateCodepoint: 'U+1D102',
    codepoint: 'U+E032',
  },
  barlineHeavy: {
    codepoint: 'U+E034',
  },
  barlineHeavyHeavy: {
    codepoint: 'U+E035',
  },
  barlineReverseFinal: {
    alternateCodepoint: 'U+1D103',
    codepoint: 'U+E033',
  },
  barlineShort: {
    alternateCodepoint: 'U+1D105',
    codepoint: 'U+E038',
  },
  barlineSingle: {
    alternateCodepoint: 'U+1D100',
    codepoint: 'U+E030',
  },
  barlineTick: {
    codepoint: 'U+E039',
  },
  beamAccelRit1: {
    codepoint: 'U+EAF4',
  },
  beamAccelRit10: {
    codepoint: 'U+EAFD',
  },
  beamAccelRit11: {
    codepoint: 'U+EAFE',
  },
  beamAccelRit12: {
    codepoint: 'U+EAFF',
  },
  beamAccelRit13: {
    codepoint: 'U+EB00',
  },
  beamAccelRit14: {
    codepoint: 'U+EB01',
  },
  beamAccelRit15: {
    codepoint: 'U+EB02',
  },
  beamAccelRit2: {
    codepoint: 'U+EAF5',
  },
  beamAccelRit3: {
    codepoint: 'U+EAF6',
  },
  beamAccelRit4: {
    codepoint: 'U+EAF7',
  },
  beamAccelRit5: {
    codepoint: 'U+EAF8',
  },
  beamAccelRit6: {
    codepoint: 'U+EAF9',
  },
  beamAccelRit7: {
    codepoint: 'U+EAFA',
  },
  beamAccelRit8: {
    codepoint: 'U+EAFB',
  },
  beamAccelRit9: {
    codepoint: 'U+EAFC',
  },
  beamAccelRitFinal: {
    codepoint: 'U+EB03',
  },
  brace: {
    alternateCodepoint: 'U+1D114',
    codepoint: 'U+E000',
  },
  bracket: {
    alternateCodepoint: 'U+1D115',
    codepoint: 'U+E002',
  },
  bracketBottom: {
    codepoint: 'U+E004',
  },
  bracketTop: {
    codepoint: 'U+E003',
  },
  brassBend: {
    alternateCodepoint: 'U+1D189',
    codepoint: 'U+E5E3',
  },
  brassDoitLong: {
    codepoint: 'U+E5D6',
  },
  brassDoitMedium: {
    codepoint: 'U+E5D5',
  },
  brassDoitShort: {
    alternateCodepoint: 'U+1D185',
    codepoint: 'U+E5D4',
  },
  brassFallLipLong: {
    codepoint: 'U+E5D9',
  },
  brassFallLipMedium: {
    codepoint: 'U+E5D8',
  },
  brassFallLipShort: {
    alternateCodepoint: 'U+1D186',
    codepoint: 'U+E5D7',
  },
  brassFallRoughLong: {
    codepoint: 'U+E5DF',
  },
  brassFallRoughMedium: {
    codepoint: 'U+E5DE',
  },
  brassFallRoughShort: {
    codepoint: 'U+E5DD',
  },
  brassFallSmoothLong: {
    codepoint: 'U+E5DC',
  },
  brassFallSmoothMedium: {
    codepoint: 'U+E5DB',
  },
  brassFallSmoothShort: {
    codepoint: 'U+E5DA',
  },
  brassFlip: {
    alternateCodepoint: 'U+1D187',
    codepoint: 'U+E5E1',
  },
  brassHarmonMuteClosed: {
    codepoint: 'U+E5E8',
  },
  brassHarmonMuteStemHalfLeft: {
    codepoint: 'U+E5E9',
  },
  brassHarmonMuteStemHalfRight: {
    codepoint: 'U+E5EA',
  },
  brassHarmonMuteStemOpen: {
    codepoint: 'U+E5EB',
  },
  brassJazzTurn: {
    codepoint: 'U+E5E4',
  },
  brassLiftLong: {
    codepoint: 'U+E5D3',
  },
  brassLiftMedium: {
    codepoint: 'U+E5D2',
  },
  brassLiftShort: {
    codepoint: 'U+E5D1',
  },
  brassLiftSmoothLong: {
    codepoint: 'U+E5EE',
  },
  brassLiftSmoothMedium: {
    codepoint: 'U+E5ED',
  },
  brassLiftSmoothShort: {
    codepoint: 'U+E5EC',
  },
  brassMuteClosed: {
    codepoint: 'U+E5E5',
  },
  brassMuteHalfClosed: {
    codepoint: 'U+E5E6',
  },
  brassMuteOpen: {
    codepoint: 'U+E5E7',
  },
  brassPlop: {
    codepoint: 'U+E5E0',
  },
  brassScoop: {
    codepoint: 'U+E5D0',
  },
  brassSmear: {
    alternateCodepoint: 'U+1D188',
    codepoint: 'U+E5E2',
  },
  brassValveTrill: {
    codepoint: 'U+E5EF',
  },
  breathMarkComma: {
    alternateCodepoint: 'U+1D112',
    codepoint: 'U+E4CE',
  },
  breathMarkSalzedo: {
    codepoint: 'U+E4D5',
  },
  breathMarkTick: {
    codepoint: 'U+E4CF',
  },
  breathMarkUpbow: {
    codepoint: 'U+E4D0',
  },
  bridgeClef: {
    codepoint: 'U+E078',
  },
  buzzRoll: {
    codepoint: 'U+E22A',
  },
  cClef: {
    alternateCodepoint: 'U+1D121',
    codepoint: 'U+E05C',
  },
  cClef8vb: {
    codepoint: 'U+E05D',
  },
  cClefArrowDown: {
    codepoint: 'U+E05F',
  },
  cClefArrowUp: {
    codepoint: 'U+E05E',
  },
  cClefChange: {
    codepoint: 'U+E07B',
  },
  cClefCombining: {
    codepoint: 'U+E061',
  },
  cClefReversed: {
    codepoint: 'U+E075',
  },
  cClefSquare: {
    codepoint: 'U+E060',
  },
  caesura: {
    alternateCodepoint: 'U+1D113',
    codepoint: 'U+E4D1',
  },
  caesuraCurved: {
    codepoint: 'U+E4D4',
  },
  caesuraShort: {
    codepoint: 'U+E4D3',
  },
  caesuraSingleStroke: {
    codepoint: 'U+E4D7',
  },
  caesuraThick: {
    codepoint: 'U+E4D2',
  },
  chantAccentusAbove: {
    codepoint: 'U+E9D6',
  },
  chantAccentusBelow: {
    codepoint: 'U+E9D7',
  },
  chantAuctumAsc: {
    codepoint: 'U+E994',
  },
  chantAuctumDesc: {
    codepoint: 'U+E995',
  },
  chantAugmentum: {
    codepoint: 'U+E9D9',
  },
  chantCaesura: {
    codepoint: 'U+E8F8',
  },
  chantCclef: {
    alternateCodepoint: 'U+1D1D0',
    codepoint: 'U+E906',
  },
  chantCirculusAbove: {
    codepoint: 'U+E9D2',
  },
  chantCirculusBelow: {
    codepoint: 'U+E9D3',
  },
  chantConnectingLineAsc2nd: {
    codepoint: 'U+E9BD',
  },
  chantConnectingLineAsc3rd: {
    codepoint: 'U+E9BE',
  },
  chantConnectingLineAsc4th: {
    codepoint: 'U+E9BF',
  },
  chantConnectingLineAsc5th: {
    codepoint: 'U+E9C0',
  },
  chantConnectingLineAsc6th: {
    codepoint: 'U+E9C1',
  },
  chantCustosStemDownPosHigh: {
    codepoint: 'U+EA08',
  },
  chantCustosStemDownPosHighest: {
    codepoint: 'U+EA09',
  },
  chantCustosStemDownPosMiddle: {
    codepoint: 'U+EA07',
  },
  chantCustosStemUpPosLow: {
    codepoint: 'U+EA05',
  },
  chantCustosStemUpPosLowest: {
    codepoint: 'U+EA04',
  },
  chantCustosStemUpPosMiddle: {
    codepoint: 'U+EA06',
  },
  chantDeminutumLower: {
    codepoint: 'U+E9B3',
  },
  chantDeminutumUpper: {
    codepoint: 'U+E9B2',
  },
  chantDivisioFinalis: {
    codepoint: 'U+E8F6',
  },
  chantDivisioMaior: {
    codepoint: 'U+E8F4',
  },
  chantDivisioMaxima: {
    codepoint: 'U+E8F5',
  },
  chantDivisioMinima: {
    codepoint: 'U+E8F3',
  },
  chantEntryLineAsc2nd: {
    codepoint: 'U+E9B4',
  },
  chantEntryLineAsc3rd: {
    codepoint: 'U+E9B5',
  },
  chantEntryLineAsc4th: {
    codepoint: 'U+E9B6',
  },
  chantEntryLineAsc5th: {
    codepoint: 'U+E9B7',
  },
  chantEntryLineAsc6th: {
    codepoint: 'U+E9B8',
  },
  chantEpisema: {
    codepoint: 'U+E9D8',
  },
  chantFclef: {
    alternateCodepoint: 'U+1D1D1',
    codepoint: 'U+E902',
  },
  chantIctusAbove: {
    codepoint: 'U+E9D0',
  },
  chantIctusBelow: {
    codepoint: 'U+E9D1',
  },
  chantLigaturaDesc2nd: {
    codepoint: 'U+E9B9',
  },
  chantLigaturaDesc3rd: {
    codepoint: 'U+E9BA',
  },
  chantLigaturaDesc4th: {
    codepoint: 'U+E9BB',
  },
  chantLigaturaDesc5th: {
    codepoint: 'U+E9BC',
  },
  chantOriscusAscending: {
    codepoint: 'U+E99C',
  },
  chantOriscusDescending: {
    codepoint: 'U+E99D',
  },
  chantOriscusLiquescens: {
    codepoint: 'U+E99E',
  },
  chantPodatusLower: {
    codepoint: 'U+E9B0',
  },
  chantPodatusUpper: {
    alternateCodepoint: 'U+1D1D4',
    codepoint: 'U+E9B1',
  },
  chantPunctum: {
    codepoint: 'U+E990',
  },
  chantPunctumCavum: {
    codepoint: 'U+E998',
  },
  chantPunctumDeminutum: {
    codepoint: 'U+E9A1',
  },
  chantPunctumInclinatum: {
    codepoint: 'U+E991',
  },
  chantPunctumInclinatumAuctum: {
    codepoint: 'U+E992',
  },
  chantPunctumInclinatumDeminutum: {
    codepoint: 'U+E993',
  },
  chantPunctumLinea: {
    codepoint: 'U+E999',
  },
  chantPunctumLineaCavum: {
    codepoint: 'U+E99A',
  },
  chantPunctumVirga: {
    alternateCodepoint: 'U+1D1D3',
    codepoint: 'U+E996',
  },
  chantPunctumVirgaReversed: {
    codepoint: 'U+E997',
  },
  chantQuilisma: {
    codepoint: 'U+E99B',
  },
  chantSemicirculusAbove: {
    codepoint: 'U+E9D4',
  },
  chantSemicirculusBelow: {
    codepoint: 'U+E9D5',
  },
  chantStaff: {
    codepoint: 'U+E8F0',
  },
  chantStaffNarrow: {
    codepoint: 'U+E8F2',
  },
  chantStaffWide: {
    codepoint: 'U+E8F1',
  },
  chantStrophicus: {
    codepoint: 'U+E99F',
  },
  chantStrophicusAuctus: {
    codepoint: 'U+E9A0',
  },
  chantStrophicusLiquescens2nd: {
    codepoint: 'U+E9C2',
  },
  chantStrophicusLiquescens3rd: {
    codepoint: 'U+E9C3',
  },
  chantStrophicusLiquescens4th: {
    codepoint: 'U+E9C4',
  },
  chantStrophicusLiquescens5th: {
    codepoint: 'U+E9C5',
  },
  chantVirgula: {
    codepoint: 'U+E8F7',
  },
  clef15: {
    codepoint: 'U+E07E',
  },
  clef8: {
    codepoint: 'U+E07D',
  },
  clefChangeCombining: {
    codepoint: 'U+E07F',
  },
  coda: {
    alternateCodepoint: 'U+1D10C',
    codepoint: 'U+E048',
  },
  codaSquare: {
    codepoint: 'U+E049',
  },
  conductorBeat2Compound: {
    codepoint: 'U+E897',
  },
  conductorBeat2Simple: {
    codepoint: 'U+E894',
  },
  conductorBeat3Compound: {
    codepoint: 'U+E898',
  },
  conductorBeat3Simple: {
    codepoint: 'U+E895',
  },
  conductorBeat4Compound: {
    codepoint: 'U+E899',
  },
  conductorBeat4Simple: {
    codepoint: 'U+E896',
  },
  conductorLeftBeat: {
    codepoint: 'U+E891',
  },
  conductorRightBeat: {
    codepoint: 'U+E892',
  },
  conductorStrongBeat: {
    codepoint: 'U+E890',
  },
  conductorUnconducted: {
    codepoint: 'U+E89A',
  },
  conductorWeakBeat: {
    codepoint: 'U+E893',
  },
  controlBeginBeam: {
    alternateCodepoint: 'U+1D173',
    codepoint: 'U+E8E0',
  },
  controlBeginPhrase: {
    alternateCodepoint: 'U+1D179',
    codepoint: 'U+E8E6',
  },
  controlBeginSlur: {
    alternateCodepoint: 'U+1D177',
    codepoint: 'U+E8E4',
  },
  controlBeginTie: {
    alternateCodepoint: 'U+1D175',
    codepoint: 'U+E8E2',
  },
  controlEndBeam: {
    alternateCodepoint: 'U+1D174',
    codepoint: 'U+E8E1',
  },
  controlEndPhrase: {
    alternateCodepoint: 'U+1D17A',
    codepoint: 'U+E8E7',
  },
  controlEndSlur: {
    alternateCodepoint: 'U+1D178',
    codepoint: 'U+E8E5',
  },
  controlEndTie: {
    alternateCodepoint: 'U+1D176',
    codepoint: 'U+E8E3',
  },
  csymAccidentalDoubleFlat: {
    codepoint: 'U+ED64',
  },
  csymAccidentalDoubleSharp: {
    codepoint: 'U+ED63',
  },
  csymAccidentalFlat: {
    codepoint: 'U+ED60',
  },
  csymAccidentalNatural: {
    codepoint: 'U+ED61',
  },
  csymAccidentalSharp: {
    codepoint: 'U+ED62',
  },
  csymAccidentalTripleFlat: {
    codepoint: 'U+ED66',
  },
  csymAccidentalTripleSharp: {
    codepoint: 'U+ED65',
  },
  csymAlteredBassSlash: {
    codepoint: 'U+E87B',
  },
  csymAugmented: {
    codepoint: 'U+E872',
  },
  csymBracketLeftTall: {
    codepoint: 'U+E877',
  },
  csymBracketRightTall: {
    codepoint: 'U+E878',
  },
  csymDiagonalArrangementSlash: {
    codepoint: 'U+E87C',
  },
  csymDiminished: {
    alternateCodepoint: 'U+1D1A9',
    codepoint: 'U+E870',
  },
  csymHalfDiminished: {
    codepoint: 'U+E871',
  },
  csymMajorSeventh: {
    codepoint: 'U+E873',
  },
  csymMinor: {
    codepoint: 'U+E874',
  },
  csymParensLeftTall: {
    codepoint: 'U+E875',
  },
  csymParensLeftVeryTall: {
    codepoint: 'U+E879',
  },
  csymParensRightTall: {
    codepoint: 'U+E876',
  },
  csymParensRightVeryTall: {
    codepoint: 'U+E87A',
  },
  curlewSign: {
    codepoint: 'U+E4D6',
  },
  daCapo: {
    alternateCodepoint: 'U+1D10A',
    codepoint: 'U+E046',
  },
  dalSegno: {
    alternateCodepoint: 'U+1D109',
    codepoint: 'U+E045',
  },
  daseianExcellentes1: {
    codepoint: 'U+EA3C',
  },
  daseianExcellentes2: {
    codepoint: 'U+EA3D',
  },
  daseianExcellentes3: {
    codepoint: 'U+EA3E',
  },
  daseianExcellentes4: {
    codepoint: 'U+EA3F',
  },
  daseianFinales1: {
    codepoint: 'U+EA34',
  },
  daseianFinales2: {
    codepoint: 'U+EA35',
  },
  daseianFinales3: {
    codepoint: 'U+EA36',
  },
  daseianFinales4: {
    codepoint: 'U+EA37',
  },
  daseianGraves1: {
    codepoint: 'U+EA30',
  },
  daseianGraves2: {
    codepoint: 'U+EA31',
  },
  daseianGraves3: {
    codepoint: 'U+EA32',
  },
  daseianGraves4: {
    codepoint: 'U+EA33',
  },
  daseianResidua1: {
    codepoint: 'U+EA40',
  },
  daseianResidua2: {
    codepoint: 'U+EA41',
  },
  daseianSuperiores1: {
    codepoint: 'U+EA38',
  },
  daseianSuperiores2: {
    codepoint: 'U+EA39',
  },
  daseianSuperiores3: {
    codepoint: 'U+EA3A',
  },
  daseianSuperiores4: {
    codepoint: 'U+EA3B',
  },
  doubleLateralRollStevens: {
    codepoint: 'U+E234',
  },
  doubleTongueAbove: {
    alternateCodepoint: 'U+1D18A',
    codepoint: 'U+E5F0',
  },
  doubleTongueBelow: {
    codepoint: 'U+E5F1',
  },
  dynamicCombinedSeparatorColon: {
    codepoint: 'U+E546',
  },
  dynamicCombinedSeparatorHyphen: {
    codepoint: 'U+E547',
  },
  dynamicCombinedSeparatorSlash: {
    codepoint: 'U+E549',
  },
  dynamicCombinedSeparatorSpace: {
    codepoint: 'U+E548',
  },
  dynamicCrescendoHairpin: {
    alternateCodepoint: 'U+1D192',
    codepoint: 'U+E53E',
  },
  dynamicDiminuendoHairpin: {
    alternateCodepoint: 'U+1D193',
    codepoint: 'U+E53F',
  },
  dynamicFF: {
    codepoint: 'U+E52F',
  },
  dynamicFFF: {
    codepoint: 'U+E530',
  },
  dynamicFFFF: {
    codepoint: 'U+E531',
  },
  dynamicFFFFF: {
    codepoint: 'U+E532',
  },
  dynamicFFFFFF: {
    codepoint: 'U+E533',
  },
  dynamicForte: {
    alternateCodepoint: 'U+1D191',
    codepoint: 'U+E522',
  },
  dynamicFortePiano: {
    codepoint: 'U+E534',
  },
  dynamicForzando: {
    codepoint: 'U+E535',
  },
  dynamicHairpinBracketLeft: {
    codepoint: 'U+E544',
  },
  dynamicHairpinBracketRight: {
    codepoint: 'U+E545',
  },
  dynamicHairpinParenthesisLeft: {
    codepoint: 'U+E542',
  },
  dynamicHairpinParenthesisRight: {
    codepoint: 'U+E543',
  },
  dynamicMF: {
    codepoint: 'U+E52D',
  },
  dynamicMP: {
    codepoint: 'U+E52C',
  },
  dynamicMessaDiVoce: {
    codepoint: 'U+E540',
  },
  dynamicMezzo: {
    alternateCodepoint: 'U+1D190',
    codepoint: 'U+E521',
  },
  dynamicNiente: {
    codepoint: 'U+E526',
  },
  dynamicNienteForHairpin: {
    codepoint: 'U+E541',
  },
  dynamicPF: {
    codepoint: 'U+E52E',
  },
  dynamicPP: {
    codepoint: 'U+E52B',
  },
  dynamicPPP: {
    codepoint: 'U+E52A',
  },
  dynamicPPPP: {
    codepoint: 'U+E529',
  },
  dynamicPPPPP: {
    codepoint: 'U+E528',
  },
  dynamicPPPPPP: {
    codepoint: 'U+E527',
  },
  dynamicPiano: {
    alternateCodepoint: 'U+1D18F',
    codepoint: 'U+E520',
  },
  dynamicRinforzando: {
    alternateCodepoint: 'U+1D18C',
    codepoint: 'U+E523',
  },
  dynamicRinforzando1: {
    codepoint: 'U+E53C',
  },
  dynamicRinforzando2: {
    codepoint: 'U+E53D',
  },
  dynamicSforzando: {
    alternateCodepoint: 'U+1D18D',
    codepoint: 'U+E524',
  },
  dynamicSforzando1: {
    codepoint: 'U+E536',
  },
  dynamicSforzandoPianissimo: {
    codepoint: 'U+E538',
  },
  dynamicSforzandoPiano: {
    codepoint: 'U+E537',
  },
  dynamicSforzato: {
    codepoint: 'U+E539',
  },
  dynamicSforzatoFF: {
    codepoint: 'U+E53B',
  },
  dynamicSforzatoPiano: {
    codepoint: 'U+E53A',
  },
  dynamicZ: {
    alternateCodepoint: 'U+1D18E',
    codepoint: 'U+E525',
  },
  elecAudioChannelsEight: {
    codepoint: 'U+EB46',
  },
  elecAudioChannelsFive: {
    codepoint: 'U+EB43',
  },
  elecAudioChannelsFour: {
    codepoint: 'U+EB42',
  },
  elecAudioChannelsOne: {
    codepoint: 'U+EB3E',
  },
  elecAudioChannelsSeven: {
    codepoint: 'U+EB45',
  },
  elecAudioChannelsSix: {
    codepoint: 'U+EB44',
  },
  elecAudioChannelsThreeFrontal: {
    codepoint: 'U+EB40',
  },
  elecAudioChannelsThreeSurround: {
    codepoint: 'U+EB41',
  },
  elecAudioChannelsTwo: {
    codepoint: 'U+EB3F',
  },
  elecAudioIn: {
    codepoint: 'U+EB49',
  },
  elecAudioMono: {
    codepoint: 'U+EB3C',
  },
  elecAudioOut: {
    codepoint: 'U+EB4A',
  },
  elecAudioStereo: {
    codepoint: 'U+EB3D',
  },
  elecCamera: {
    codepoint: 'U+EB1B',
  },
  elecDataIn: {
    codepoint: 'U+EB4D',
  },
  elecDataOut: {
    codepoint: 'U+EB4E',
  },
  elecDisc: {
    codepoint: 'U+EB13',
  },
  elecDownload: {
    codepoint: 'U+EB4F',
  },
  elecEject: {
    codepoint: 'U+EB2B',
  },
  elecFastForward: {
    codepoint: 'U+EB1F',
  },
  elecHeadphones: {
    codepoint: 'U+EB11',
  },
  elecHeadset: {
    codepoint: 'U+EB12',
  },
  elecLineIn: {
    codepoint: 'U+EB47',
  },
  elecLineOut: {
    codepoint: 'U+EB48',
  },
  elecLoop: {
    codepoint: 'U+EB23',
  },
  elecLoudspeaker: {
    codepoint: 'U+EB1A',
  },
  elecMIDIController0: {
    codepoint: 'U+EB36',
  },
  elecMIDIController100: {
    codepoint: 'U+EB3B',
  },
  elecMIDIController20: {
    codepoint: 'U+EB37',
  },
  elecMIDIController40: {
    codepoint: 'U+EB38',
  },
  elecMIDIController60: {
    codepoint: 'U+EB39',
  },
  elecMIDIController80: {
    codepoint: 'U+EB3A',
  },
  elecMIDIIn: {
    codepoint: 'U+EB34',
  },
  elecMIDIOut: {
    codepoint: 'U+EB35',
  },
  elecMicrophone: {
    codepoint: 'U+EB10',
  },
  elecMicrophoneMute: {
    codepoint: 'U+EB28',
  },
  elecMicrophoneUnmute: {
    codepoint: 'U+EB29',
  },
  elecMixingConsole: {
    codepoint: 'U+EB15',
  },
  elecMonitor: {
    codepoint: 'U+EB18',
  },
  elecMute: {
    codepoint: 'U+EB26',
  },
  elecPause: {
    codepoint: 'U+EB1E',
  },
  elecPlay: {
    codepoint: 'U+EB1C',
  },
  elecPowerOnOff: {
    codepoint: 'U+EB2A',
  },
  elecProjector: {
    codepoint: 'U+EB19',
  },
  elecReplay: {
    codepoint: 'U+EB24',
  },
  elecRewind: {
    codepoint: 'U+EB20',
  },
  elecShuffle: {
    codepoint: 'U+EB25',
  },
  elecSkipBackwards: {
    codepoint: 'U+EB22',
  },
  elecSkipForwards: {
    codepoint: 'U+EB21',
  },
  elecStop: {
    codepoint: 'U+EB1D',
  },
  elecTape: {
    codepoint: 'U+EB14',
  },
  elecUSB: {
    codepoint: 'U+EB16',
  },
  elecUnmute: {
    codepoint: 'U+EB27',
  },
  elecUpload: {
    codepoint: 'U+EB50',
  },
  elecVideoCamera: {
    codepoint: 'U+EB17',
  },
  elecVideoIn: {
    codepoint: 'U+EB4B',
  },
  elecVideoOut: {
    codepoint: 'U+EB4C',
  },
  elecVolumeFader: {
    codepoint: 'U+EB2C',
  },
  elecVolumeFaderThumb: {
    codepoint: 'U+EB2D',
  },
  elecVolumeLevel0: {
    codepoint: 'U+EB2E',
  },
  elecVolumeLevel100: {
    codepoint: 'U+EB33',
  },
  elecVolumeLevel20: {
    codepoint: 'U+EB2F',
  },
  elecVolumeLevel40: {
    codepoint: 'U+EB30',
  },
  elecVolumeLevel60: {
    codepoint: 'U+EB31',
  },
  elecVolumeLevel80: {
    codepoint: 'U+EB32',
  },
  fClef: {
    alternateCodepoint: 'U+1D122',
    codepoint: 'U+E062',
  },
  fClef15ma: {
    codepoint: 'U+E066',
  },
  fClef15mb: {
    codepoint: 'U+E063',
  },
  fClef8va: {
    alternateCodepoint: 'U+1D123',
    codepoint: 'U+E065',
  },
  fClef8vb: {
    alternateCodepoint: 'U+1D124',
    codepoint: 'U+E064',
  },
  fClefArrowDown: {
    codepoint: 'U+E068',
  },
  fClefArrowUp: {
    codepoint: 'U+E067',
  },
  fClefChange: {
    codepoint: 'U+E07C',
  },
  fClefReversed: {
    codepoint: 'U+E076',
  },
  fClefTurned: {
    codepoint: 'U+E077',
  },
  fermataAbove: {
    alternateCodepoint: 'U+1D110',
    codepoint: 'U+E4C0',
  },
  fermataBelow: {
    alternateCodepoint: 'U+1D111',
    codepoint: 'U+E4C1',
  },
  fermataLongAbove: {
    codepoint: 'U+E4C6',
  },
  fermataLongBelow: {
    codepoint: 'U+E4C7',
  },
  fermataLongHenzeAbove: {
    codepoint: 'U+E4CA',
  },
  fermataLongHenzeBelow: {
    codepoint: 'U+E4CB',
  },
  fermataShortAbove: {
    codepoint: 'U+E4C4',
  },
  fermataShortBelow: {
    codepoint: 'U+E4C5',
  },
  fermataShortHenzeAbove: {
    codepoint: 'U+E4CC',
  },
  fermataShortHenzeBelow: {
    codepoint: 'U+E4CD',
  },
  fermataVeryLongAbove: {
    codepoint: 'U+E4C8',
  },
  fermataVeryLongBelow: {
    codepoint: 'U+E4C9',
  },
  fermataVeryShortAbove: {
    codepoint: 'U+E4C2',
  },
  fermataVeryShortBelow: {
    codepoint: 'U+E4C3',
  },
  figbass0: {
    codepoint: 'U+EA50',
  },
  figbass1: {
    codepoint: 'U+EA51',
  },
  figbass2: {
    codepoint: 'U+EA52',
  },
  figbass2Raised: {
    codepoint: 'U+EA53',
  },
  figbass3: {
    codepoint: 'U+EA54',
  },
  figbass4: {
    codepoint: 'U+EA55',
  },
  figbass4Raised: {
    codepoint: 'U+EA56',
  },
  figbass5: {
    codepoint: 'U+EA57',
  },
  figbass5Raised1: {
    codepoint: 'U+EA58',
  },
  figbass5Raised2: {
    codepoint: 'U+EA59',
  },
  figbass5Raised3: {
    codepoint: 'U+EA5A',
  },
  figbass6: {
    codepoint: 'U+EA5B',
  },
  figbass6Raised: {
    codepoint: 'U+EA5C',
  },
  figbass6Raised2: {
    codepoint: 'U+EA6F',
  },
  figbass7: {
    codepoint: 'U+EA5D',
  },
  figbass7Diminished: {
    codepoint: 'U+ECC0',
  },
  figbass7Raised1: {
    codepoint: 'U+EA5E',
  },
  figbass7Raised2: {
    codepoint: 'U+EA5F',
  },
  figbass8: {
    codepoint: 'U+EA60',
  },
  figbass9: {
    codepoint: 'U+EA61',
  },
  figbass9Raised: {
    codepoint: 'U+EA62',
  },
  figbassBracketLeft: {
    codepoint: 'U+EA68',
  },
  figbassBracketRight: {
    codepoint: 'U+EA69',
  },
  figbassCombiningLowering: {
    codepoint: 'U+EA6E',
  },
  figbassCombiningRaising: {
    codepoint: 'U+EA6D',
  },
  figbassDoubleFlat: {
    codepoint: 'U+EA63',
  },
  figbassDoubleSharp: {
    codepoint: 'U+EA67',
  },
  figbassFlat: {
    codepoint: 'U+EA64',
  },
  figbassNatural: {
    codepoint: 'U+EA65',
  },
  figbassParensLeft: {
    codepoint: 'U+EA6A',
  },
  figbassParensRight: {
    codepoint: 'U+EA6B',
  },
  figbassPlus: {
    codepoint: 'U+EA6C',
  },
  figbassSharp: {
    codepoint: 'U+EA66',
  },
  figbassTripleFlat: {
    codepoint: 'U+ECC1',
  },
  figbassTripleSharp: {
    codepoint: 'U+ECC2',
  },
  fingering0: {
    codepoint: 'U+ED10',
  },
  fingering0Italic: {
    codepoint: 'U+ED80',
  },
  fingering1: {
    codepoint: 'U+ED11',
  },
  fingering1Italic: {
    codepoint: 'U+ED81',
  },
  fingering2: {
    codepoint: 'U+ED12',
  },
  fingering2Italic: {
    codepoint: 'U+ED82',
  },
  fingering3: {
    codepoint: 'U+ED13',
  },
  fingering3Italic: {
    codepoint: 'U+ED83',
  },
  fingering4: {
    codepoint: 'U+ED14',
  },
  fingering4Italic: {
    codepoint: 'U+ED84',
  },
  fingering5: {
    codepoint: 'U+ED15',
  },
  fingering5Italic: {
    codepoint: 'U+ED85',
  },
  fingering6: {
    codepoint: 'U+ED24',
  },
  fingering6Italic: {
    codepoint: 'U+ED86',
  },
  fingering7: {
    codepoint: 'U+ED25',
  },
  fingering7Italic: {
    codepoint: 'U+ED87',
  },
  fingering8: {
    codepoint: 'U+ED26',
  },
  fingering8Italic: {
    codepoint: 'U+ED88',
  },
  fingering9: {
    codepoint: 'U+ED27',
  },
  fingering9Italic: {
    codepoint: 'U+ED89',
  },
  fingeringALower: {
    codepoint: 'U+ED1B',
  },
  fingeringCLower: {
    codepoint: 'U+ED1C',
  },
  fingeringELower: {
    codepoint: 'U+ED1E',
  },
  fingeringILower: {
    codepoint: 'U+ED19',
  },
  fingeringLeftBracket: {
    codepoint: 'U+ED2A',
  },
  fingeringLeftBracketItalic: {
    codepoint: 'U+ED8C',
  },
  fingeringLeftParenthesis: {
    codepoint: 'U+ED28',
  },
  fingeringLeftParenthesisItalic: {
    codepoint: 'U+ED8A',
  },
  fingeringMLower: {
    codepoint: 'U+ED1A',
  },
  fingeringMultipleNotes: {
    codepoint: 'U+ED23',
  },
  fingeringOLower: {
    codepoint: 'U+ED1F',
  },
  fingeringPLower: {
    codepoint: 'U+ED17',
  },
  fingeringQLower: {
    codepoint: 'U+ED8E',
  },
  fingeringRightBracket: {
    codepoint: 'U+ED2B',
  },
  fingeringRightBracketItalic: {
    codepoint: 'U+ED8D',
  },
  fingeringRightParenthesis: {
    codepoint: 'U+ED29',
  },
  fingeringRightParenthesisItalic: {
    codepoint: 'U+ED8B',
  },
  fingeringSLower: {
    codepoint: 'U+ED8F',
  },
  fingeringSeparatorMiddleDot: {
    codepoint: 'U+ED2C',
  },
  fingeringSeparatorMiddleDotWhite: {
    codepoint: 'U+ED2D',
  },
  fingeringSeparatorSlash: {
    codepoint: 'U+ED2E',
  },
  fingeringSubstitutionAbove: {
    codepoint: 'U+ED20',
  },
  fingeringSubstitutionBelow: {
    codepoint: 'U+ED21',
  },
  fingeringSubstitutionDash: {
    codepoint: 'U+ED22',
  },
  fingeringTLower: {
    codepoint: 'U+ED18',
  },
  fingeringTUpper: {
    codepoint: 'U+ED16',
  },
  fingeringXLower: {
    codepoint: 'U+ED1D',
  },
  flag1024thDown: {
    codepoint: 'U+E24F',
  },
  flag1024thUp: {
    codepoint: 'U+E24E',
  },
  flag128thDown: {
    codepoint: 'U+E249',
  },
  flag128thUp: {
    alternateCodepoint: 'U+1D172',
    codepoint: 'U+E248',
  },
  flag16thDown: {
    codepoint: 'U+E243',
  },
  flag16thUp: {
    alternateCodepoint: 'U+1D16F',
    codepoint: 'U+E242',
  },
  flag256thDown: {
    codepoint: 'U+E24B',
  },
  flag256thUp: {
    codepoint: 'U+E24A',
  },
  flag32ndDown: {
    codepoint: 'U+E245',
  },
  flag32ndUp: {
    alternateCodepoint: 'U+1D170',
    codepoint: 'U+E244',
  },
  flag512thDown: {
    codepoint: 'U+E24D',
  },
  flag512thUp: {
    codepoint: 'U+E24C',
  },
  flag64thDown: {
    codepoint: 'U+E247',
  },
  flag64thUp: {
    alternateCodepoint: 'U+1D171',
    codepoint: 'U+E246',
  },
  flag8thDown: {
    codepoint: 'U+E241',
  },
  flag8thUp: {
    alternateCodepoint: 'U+1D16E',
    codepoint: 'U+E240',
  },
  flagInternalDown: {
    codepoint: 'U+E251',
  },
  flagInternalUp: {
    codepoint: 'U+E250',
  },
  fretboard3String: {
    codepoint: 'U+E850',
  },
  fretboard3StringNut: {
    codepoint: 'U+E851',
  },
  fretboard4String: {
    alternateCodepoint: 'U+1D11D',
    codepoint: 'U+E852',
  },
  fretboard4StringNut: {
    codepoint: 'U+E853',
  },
  fretboard5String: {
    codepoint: 'U+E854',
  },
  fretboard5StringNut: {
    codepoint: 'U+E855',
  },
  fretboard6String: {
    alternateCodepoint: 'U+1D11C',
    codepoint: 'U+E856',
  },
  fretboard6StringNut: {
    codepoint: 'U+E857',
  },
  fretboardFilledCircle: {
    codepoint: 'U+E858',
  },
  fretboardO: {
    codepoint: 'U+E85A',
  },
  fretboardX: {
    codepoint: 'U+E859',
  },
  functionAngleLeft: {
    codepoint: 'U+EA93',
  },
  functionAngleRight: {
    codepoint: 'U+EA94',
  },
  functionBracketLeft: {
    codepoint: 'U+EA8F',
  },
  functionBracketRight: {
    codepoint: 'U+EA90',
  },
  functionDD: {
    codepoint: 'U+EA81',
  },
  functionDLower: {
    codepoint: 'U+EA80',
  },
  functionDUpper: {
    codepoint: 'U+EA7F',
  },
  functionEight: {
    codepoint: 'U+EA78',
  },
  functionFUpper: {
    codepoint: 'U+EA99',
  },
  functionFive: {
    codepoint: 'U+EA75',
  },
  functionFour: {
    codepoint: 'U+EA74',
  },
  functionGLower: {
    codepoint: 'U+EA84',
  },
  functionGUpper: {
    codepoint: 'U+EA83',
  },
  functionGreaterThan: {
    codepoint: 'U+EA7C',
  },
  functionILower: {
    codepoint: 'U+EA9B',
  },
  functionIUpper: {
    codepoint: 'U+EA9A',
  },
  functionKLower: {
    codepoint: 'U+EA9D',
  },
  functionKUpper: {
    codepoint: 'U+EA9C',
  },
  functionLLower: {
    codepoint: 'U+EA9F',
  },
  functionLUpper: {
    codepoint: 'U+EA9E',
  },
  functionLessThan: {
    codepoint: 'U+EA7A',
  },
  functionMLower: {
    codepoint: 'U+ED01',
  },
  functionMUpper: {
    codepoint: 'U+ED00',
  },
  functionMinus: {
    codepoint: 'U+EA7B',
  },
  functionNLower: {
    codepoint: 'U+EA86',
  },
  functionNUpper: {
    codepoint: 'U+EA85',
  },
  functionNUpperSuperscript: {
    codepoint: 'U+ED02',
  },
  functionNine: {
    codepoint: 'U+EA79',
  },
  functionOne: {
    codepoint: 'U+EA71',
  },
  functionPLower: {
    codepoint: 'U+EA88',
  },
  functionPUpper: {
    codepoint: 'U+EA87',
  },
  functionParensLeft: {
    codepoint: 'U+EA91',
  },
  functionParensRight: {
    codepoint: 'U+EA92',
  },
  functionPlus: {
    codepoint: 'U+EA98',
  },
  functionRLower: {
    codepoint: 'U+ED03',
  },
  functionRepetition1: {
    codepoint: 'U+EA95',
  },
  functionRepetition2: {
    codepoint: 'U+EA96',
  },
  functionRing: {
    codepoint: 'U+EA97',
  },
  functionSLower: {
    codepoint: 'U+EA8A',
  },
  functionSSLower: {
    codepoint: 'U+EA7E',
  },
  functionSSUpper: {
    codepoint: 'U+EA7D',
  },
  functionSUpper: {
    codepoint: 'U+EA89',
  },
  functionSeven: {
    codepoint: 'U+EA77',
  },
  functionSix: {
    codepoint: 'U+EA76',
  },
  functionSlashedDD: {
    codepoint: 'U+EA82',
  },
  functionTLower: {
    codepoint: 'U+EA8C',
  },
  functionTUpper: {
    codepoint: 'U+EA8B',
  },
  functionThree: {
    codepoint: 'U+EA73',
  },
  functionTwo: {
    codepoint: 'U+EA72',
  },
  functionVLower: {
    codepoint: 'U+EA8E',
  },
  functionVUpper: {
    codepoint: 'U+EA8D',
  },
  functionZero: {
    codepoint: 'U+EA70',
  },
  gClef: {
    alternateCodepoint: 'U+1D11E',
    codepoint: 'U+E050',
  },
  gClef15ma: {
    codepoint: 'U+E054',
  },
  gClef15mb: {
    codepoint: 'U+E051',
  },
  gClef8va: {
    alternateCodepoint: 'U+1D11F',
    codepoint: 'U+E053',
  },
  gClef8vb: {
    alternateCodepoint: 'U+1D120',
    codepoint: 'U+E052',
  },
  gClef8vbCClef: {
    codepoint: 'U+E056',
  },
  gClef8vbOld: {
    codepoint: 'U+E055',
  },
  gClef8vbParens: {
    codepoint: 'U+E057',
  },
  gClefArrowDown: {
    codepoint: 'U+E05B',
  },
  gClefArrowUp: {
    codepoint: 'U+E05A',
  },
  gClefChange: {
    codepoint: 'U+E07A',
  },
  gClefLigatedNumberAbove: {
    codepoint: 'U+E059',
  },
  gClefLigatedNumberBelow: {
    codepoint: 'U+E058',
  },
  gClefReversed: {
    codepoint: 'U+E073',
  },
  gClefTurned: {
    codepoint: 'U+E074',
  },
  glissandoDown: {
    alternateCodepoint: 'U+1D1B2',
    codepoint: 'U+E586',
  },
  glissandoUp: {
    alternateCodepoint: 'U+1D1B1',
    codepoint: 'U+E585',
  },
  graceNoteAcciaccaturaStemDown: {
    codepoint: 'U+E561',
  },
  graceNoteAcciaccaturaStemUp: {
    alternateCodepoint: 'U+1D194',
    codepoint: 'U+E560',
  },
  graceNoteAppoggiaturaStemDown: {
    codepoint: 'U+E563',
  },
  graceNoteAppoggiaturaStemUp: {
    alternateCodepoint: 'U+1D195',
    codepoint: 'U+E562',
  },
  graceNoteSlashStemDown: {
    codepoint: 'U+E565',
  },
  graceNoteSlashStemUp: {
    codepoint: 'U+E564',
  },
  guitarBarreFull: {
    codepoint: 'U+E848',
  },
  guitarBarreHalf: {
    codepoint: 'U+E849',
  },
  guitarClosePedal: {
    codepoint: 'U+E83F',
  },
  guitarFadeIn: {
    codepoint: 'U+E843',
  },
  guitarFadeOut: {
    codepoint: 'U+E844',
  },
  guitarGolpe: {
    codepoint: 'U+E842',
  },
  guitarHalfOpenPedal: {
    codepoint: 'U+E83E',
  },
  guitarLeftHandTapping: {
    codepoint: 'U+E840',
  },
  guitarOpenPedal: {
    codepoint: 'U+E83D',
  },
  guitarRightHandTapping: {
    codepoint: 'U+E841',
  },
  guitarShake: {
    codepoint: 'U+E832',
  },
  guitarString0: {
    codepoint: 'U+E833',
  },
  guitarString1: {
    codepoint: 'U+E834',
  },
  guitarString10: {
    codepoint: 'U+E84A',
  },
  guitarString11: {
    codepoint: 'U+E84B',
  },
  guitarString12: {
    codepoint: 'U+E84C',
  },
  guitarString13: {
    codepoint: 'U+E84D',
  },
  guitarString2: {
    codepoint: 'U+E835',
  },
  guitarString3: {
    codepoint: 'U+E836',
  },
  guitarString4: {
    codepoint: 'U+E837',
  },
  guitarString5: {
    codepoint: 'U+E838',
  },
  guitarString6: {
    codepoint: 'U+E839',
  },
  guitarString7: {
    codepoint: 'U+E83A',
  },
  guitarString8: {
    codepoint: 'U+E83B',
  },
  guitarString9: {
    codepoint: 'U+E83C',
  },
  guitarStrumDown: {
    codepoint: 'U+E847',
  },
  guitarStrumUp: {
    codepoint: 'U+E846',
  },
  guitarVibratoBarDip: {
    codepoint: 'U+E831',
  },
  guitarVibratoBarScoop: {
    codepoint: 'U+E830',
  },
  guitarVibratoStroke: {
    codepoint: 'U+EAB2',
  },
  guitarVolumeSwell: {
    codepoint: 'U+E845',
  },
  guitarWideVibratoStroke: {
    codepoint: 'U+EAB3',
  },
  handbellsBelltree: {
    codepoint: 'U+E81F',
  },
  handbellsDamp3: {
    codepoint: 'U+E81E',
  },
  handbellsEcho1: {
    codepoint: 'U+E81B',
  },
  handbellsEcho2: {
    codepoint: 'U+E81C',
  },
  handbellsGyro: {
    codepoint: 'U+E81D',
  },
  handbellsHandMartellato: {
    codepoint: 'U+E812',
  },
  handbellsMalletBellOnTable: {
    codepoint: 'U+E815',
  },
  handbellsMalletBellSuspended: {
    codepoint: 'U+E814',
  },
  handbellsMalletLft: {
    codepoint: 'U+E816',
  },
  handbellsMartellato: {
    codepoint: 'U+E810',
  },
  handbellsMartellatoLift: {
    codepoint: 'U+E811',
  },
  handbellsMutedMartellato: {
    codepoint: 'U+E813',
  },
  handbellsPluckLift: {
    codepoint: 'U+E817',
  },
  handbellsSwing: {
    codepoint: 'U+E81A',
  },
  handbellsSwingDown: {
    codepoint: 'U+E819',
  },
  handbellsSwingUp: {
    codepoint: 'U+E818',
  },
  handbellsTablePairBells: {
    codepoint: 'U+E821',
  },
  handbellsTableSingleBell: {
    codepoint: 'U+E820',
  },
  harpMetalRod: {
    codepoint: 'U+E68F',
  },
  harpPedalCentered: {
    codepoint: 'U+E681',
  },
  harpPedalDivider: {
    codepoint: 'U+E683',
  },
  harpPedalLowered: {
    codepoint: 'U+E682',
  },
  harpPedalRaised: {
    codepoint: 'U+E680',
  },
  harpSalzedoAeolianAscending: {
    codepoint: 'U+E695',
  },
  harpSalzedoAeolianDescending: {
    codepoint: 'U+E696',
  },
  harpSalzedoDampAbove: {
    codepoint: 'U+E69A',
  },
  harpSalzedoDampBelow: {
    codepoint: 'U+E699',
  },
  harpSalzedoDampBothHands: {
    codepoint: 'U+E698',
  },
  harpSalzedoDampLowStrings: {
    codepoint: 'U+E697',
  },
  harpSalzedoFluidicSoundsLeft: {
    codepoint: 'U+E68D',
  },
  harpSalzedoFluidicSoundsRight: {
    codepoint: 'U+E68E',
  },
  harpSalzedoIsolatedSounds: {
    codepoint: 'U+E69C',
  },
  harpSalzedoMetallicSounds: {
    codepoint: 'U+E688',
  },
  harpSalzedoMetallicSoundsOneString: {
    codepoint: 'U+E69B',
  },
  harpSalzedoMuffleTotally: {
    codepoint: 'U+E68C',
  },
  harpSalzedoOboicFlux: {
    codepoint: 'U+E685',
  },
  harpSalzedoPlayUpperEnd: {
    codepoint: 'U+E68A',
  },
  harpSalzedoSlideWithSuppleness: {
    codepoint: 'U+E684',
  },
  harpSalzedoSnareDrum: {
    codepoint: 'U+E69D',
  },
  harpSalzedoTamTamSounds: {
    codepoint: 'U+E689',
  },
  harpSalzedoThunderEffect: {
    codepoint: 'U+E686',
  },
  harpSalzedoTimpanicSounds: {
    codepoint: 'U+E68B',
  },
  harpSalzedoWhistlingSounds: {
    codepoint: 'U+E687',
  },
  harpStringNoiseStem: {
    codepoint: 'U+E694',
  },
  harpTuningKey: {
    codepoint: 'U+E690',
  },
  harpTuningKeyGlissando: {
    codepoint: 'U+E693',
  },
  harpTuningKeyHandle: {
    codepoint: 'U+E691',
  },
  harpTuningKeyShank: {
    codepoint: 'U+E692',
  },
  indianDrumClef: {
    codepoint: 'U+ED70',
  },
  kahnBackChug: {
    codepoint: 'U+EDE2',
  },
  kahnBackFlap: {
    codepoint: 'U+EDD8',
  },
  kahnBackRiff: {
    codepoint: 'U+EDE1',
  },
  kahnBackRip: {
    codepoint: 'U+EDDA',
  },
  kahnBallChange: {
    codepoint: 'U+EDC6',
  },
  kahnBallDig: {
    codepoint: 'U+EDCD',
  },
  kahnBrushBackward: {
    codepoint: 'U+EDA7',
  },
  kahnBrushForward: {
    codepoint: 'U+EDA6',
  },
  kahnChug: {
    codepoint: 'U+EDDD',
  },
  kahnClap: {
    codepoint: 'U+EDB8',
  },
  kahnDoubleSnap: {
    codepoint: 'U+EDBA',
  },
  kahnDoubleWing: {
    codepoint: 'U+EDEB',
  },
  kahnDrawStep: {
    codepoint: 'U+EDB2',
  },
  kahnDrawTap: {
    codepoint: 'U+EDB3',
  },
  kahnFlam: {
    codepoint: 'U+EDCF',
  },
  kahnFlap: {
    codepoint: 'U+EDD5',
  },
  kahnFlapStep: {
    codepoint: 'U+EDD7',
  },
  kahnFlat: {
    codepoint: 'U+EDA9',
  },
  kahnFleaHop: {
    codepoint: 'U+EDB0',
  },
  kahnFleaTap: {
    codepoint: 'U+EDB1',
  },
  kahnGraceTap: {
    codepoint: 'U+EDA8',
  },
  kahnGraceTapChange: {
    codepoint: 'U+EDD1',
  },
  kahnGraceTapHop: {
    codepoint: 'U+EDD0',
  },
  kahnGraceTapStamp: {
    codepoint: 'U+EDD3',
  },
  kahnHeel: {
    codepoint: 'U+EDAA',
  },
  kahnHeelChange: {
    codepoint: 'U+EDC9',
  },
  kahnHeelClick: {
    codepoint: 'U+EDBB',
  },
  kahnHeelDrop: {
    codepoint: 'U+EDB6',
  },
  kahnHeelStep: {
    codepoint: 'U+EDC4',
  },
  kahnHeelTap: {
    codepoint: 'U+EDCB',
  },
  kahnHop: {
    codepoint: 'U+EDA2',
  },
  kahnJumpApart: {
    codepoint: 'U+EDA5',
  },
  kahnJumpTogether: {
    codepoint: 'U+EDA4',
  },
  kahnKneeInward: {
    codepoint: 'U+EDAD',
  },
  kahnKneeOutward: {
    codepoint: 'U+EDAC',
  },
  kahnLeap: {
    codepoint: 'U+EDA3',
  },
  kahnLeapFlatFoot: {
    codepoint: 'U+EDD2',
  },
  kahnLeapHeelClick: {
    codepoint: 'U+EDD4',
  },
  kahnLeftCatch: {
    codepoint: 'U+EDBF',
  },
  kahnLeftCross: {
    codepoint: 'U+EDBD',
  },
  kahnLeftFoot: {
    codepoint: 'U+EDEE',
  },
  kahnLeftToeStrike: {
    codepoint: 'U+EDC1',
  },
  kahnLeftTurn: {
    codepoint: 'U+EDF0',
  },
  kahnOverTheTop: {
    codepoint: 'U+EDEC',
  },
  kahnOverTheTopTap: {
    codepoint: 'U+EDED',
  },
  kahnPull: {
    codepoint: 'U+EDE3',
  },
  kahnPush: {
    codepoint: 'U+EDDE',
  },
  kahnRiff: {
    codepoint: 'U+EDE0',
  },
  kahnRiffle: {
    codepoint: 'U+EDE7',
  },
  kahnRightCatch: {
    codepoint: 'U+EDC0',
  },
  kahnRightCross: {
    codepoint: 'U+EDBE',
  },
  kahnRightFoot: {
    codepoint: 'U+EDEF',
  },
  kahnRightToeStrike: {
    codepoint: 'U+EDC2',
  },
  kahnRightTurn: {
    codepoint: 'U+EDF1',
  },
  kahnRip: {
    codepoint: 'U+EDD6',
  },
  kahnRipple: {
    codepoint: 'U+EDE8',
  },
  kahnScrape: {
    codepoint: 'U+EDAE',
  },
  kahnScuff: {
    codepoint: 'U+EDDC',
  },
  kahnScuffle: {
    codepoint: 'U+EDE6',
  },
  kahnShuffle: {
    codepoint: 'U+EDE5',
  },
  kahnSlam: {
    codepoint: 'U+EDCE',
  },
  kahnSlap: {
    codepoint: 'U+EDD9',
  },
  kahnSlideStep: {
    codepoint: 'U+EDB4',
  },
  kahnSlideTap: {
    codepoint: 'U+EDB5',
  },
  kahnSnap: {
    codepoint: 'U+EDB9',
  },
  kahnStamp: {
    codepoint: 'U+EDC3',
  },
  kahnStampStamp: {
    codepoint: 'U+EDC8',
  },
  kahnStep: {
    codepoint: 'U+EDA0',
  },
  kahnStepStamp: {
    codepoint: 'U+EDC7',
  },
  kahnStomp: {
    codepoint: 'U+EDCA',
  },
  kahnStompBrush: {
    codepoint: 'U+EDDB',
  },
  kahnTap: {
    codepoint: 'U+EDA1',
  },
  kahnToe: {
    codepoint: 'U+EDAB',
  },
  kahnToeClick: {
    codepoint: 'U+EDBC',
  },
  kahnToeDrop: {
    codepoint: 'U+EDB7',
  },
  kahnToeStep: {
    codepoint: 'U+EDC5',
  },
  kahnToeTap: {
    codepoint: 'U+EDCC',
  },
  kahnTrench: {
    codepoint: 'U+EDAF',
  },
  kahnWing: {
    codepoint: 'U+EDE9',
  },
  kahnWingChange: {
    codepoint: 'U+EDEA',
  },
  kahnZank: {
    codepoint: 'U+EDE4',
  },
  kahnZink: {
    codepoint: 'U+EDDF',
  },
  keyboardBebung2DotsAbove: {
    codepoint: 'U+E668',
  },
  keyboardBebung2DotsBelow: {
    codepoint: 'U+E669',
  },
  keyboardBebung3DotsAbove: {
    codepoint: 'U+E66A',
  },
  keyboardBebung3DotsBelow: {
    codepoint: 'U+E66B',
  },
  keyboardBebung4DotsAbove: {
    codepoint: 'U+E66C',
  },
  keyboardBebung4DotsBelow: {
    codepoint: 'U+E66D',
  },
  keyboardLeftPedalPictogram: {
    codepoint: 'U+E65E',
  },
  keyboardMiddlePedalPictogram: {
    codepoint: 'U+E65F',
  },
  keyboardPedalD: {
    codepoint: 'U+E653',
  },
  keyboardPedalDot: {
    codepoint: 'U+E654',
  },
  keyboardPedalE: {
    codepoint: 'U+E652',
  },
  keyboardPedalHalf: {
    alternateCodepoint: 'U+1D1B0',
    codepoint: 'U+E656',
  },
  keyboardPedalHalf2: {
    codepoint: 'U+E65B',
  },
  keyboardPedalHalf3: {
    codepoint: 'U+E65C',
  },
  keyboardPedalHeel1: {
    codepoint: 'U+E661',
  },
  keyboardPedalHeel2: {
    codepoint: 'U+E662',
  },
  keyboardPedalHeel3: {
    codepoint: 'U+E663',
  },
  keyboardPedalHeelToToe: {
    codepoint: 'U+E674',
  },
  keyboardPedalHeelToe: {
    codepoint: 'U+E666',
  },
  keyboardPedalHookEnd: {
    codepoint: 'U+E673',
  },
  keyboardPedalHookStart: {
    codepoint: 'U+E672',
  },
  keyboardPedalHyphen: {
    codepoint: 'U+E658',
  },
  keyboardPedalP: {
    codepoint: 'U+E651',
  },
  keyboardPedalParensLeft: {
    codepoint: 'U+E676',
  },
  keyboardPedalParensRight: {
    codepoint: 'U+E677',
  },
  keyboardPedalPed: {
    alternateCodepoint: 'U+1D1AE',
    codepoint: 'U+E650',
  },
  keyboardPedalS: {
    codepoint: 'U+E65A',
  },
  keyboardPedalSost: {
    codepoint: 'U+E659',
  },
  keyboardPedalToe1: {
    codepoint: 'U+E664',
  },
  keyboardPedalToe2: {
    codepoint: 'U+E665',
  },
  keyboardPedalToeToHeel: {
    codepoint: 'U+E675',
  },
  keyboardPedalUp: {
    alternateCodepoint: 'U+1D1AF',
    codepoint: 'U+E655',
  },
  keyboardPedalUpNotch: {
    codepoint: 'U+E657',
  },
  keyboardPedalUpSpecial: {
    codepoint: 'U+E65D',
  },
  keyboardPlayWithLH: {
    codepoint: 'U+E670',
  },
  keyboardPlayWithLHEnd: {
    codepoint: 'U+E671',
  },
  keyboardPlayWithRH: {
    codepoint: 'U+E66E',
  },
  keyboardPlayWithRHEnd: {
    codepoint: 'U+E66F',
  },
  keyboardPluckInside: {
    codepoint: 'U+E667',
  },
  keyboardRightPedalPictogram: {
    codepoint: 'U+E660',
  },
  kievanAccidentalFlat: {
    alternateCodepoint: 'U+1D1E8',
    codepoint: 'U+EC3E',
  },
  kievanAccidentalSharp: {
    codepoint: 'U+EC3D',
  },
  kievanAugmentationDot: {
    codepoint: 'U+EC3C',
  },
  kievanCClef: {
    alternateCodepoint: 'U+1D1DE',
    codepoint: 'U+EC30',
  },
  kievanEndingSymbol: {
    alternateCodepoint: 'U+1D1DF',
    codepoint: 'U+EC31',
  },
  kievanNote8thStemDown: {
    alternateCodepoint: 'U+1D1E6',
    codepoint: 'U+EC3A',
  },
  kievanNote8thStemUp: {
    alternateCodepoint: 'U+1D1E7',
    codepoint: 'U+EC39',
  },
  kievanNoteBeam: {
    codepoint: 'U+EC3B',
  },
  kievanNoteHalfStaffLine: {
    alternateCodepoint: 'U+1D1E3',
    codepoint: 'U+EC35',
  },
  kievanNoteHalfStaffSpace: {
    codepoint: 'U+EC36',
  },
  kievanNoteQuarterStemDown: {
    alternateCodepoint: 'U+1D1E4',
    codepoint: 'U+EC38',
  },
  kievanNoteQuarterStemUp: {
    alternateCodepoint: 'U+1D1E5',
    codepoint: 'U+EC37',
  },
  kievanNoteReciting: {
    alternateCodepoint: 'U+1D1E1',
    codepoint: 'U+EC32',
  },
  kievanNoteWhole: {
    alternateCodepoint: 'U+1D1E2',
    codepoint: 'U+EC33',
  },
  kievanNoteWholeFinal: {
    alternateCodepoint: 'U+1D1E0',
    codepoint: 'U+EC34',
  },
  kodalyHandDo: {
    codepoint: 'U+EC40',
  },
  kodalyHandFa: {
    codepoint: 'U+EC43',
  },
  kodalyHandLa: {
    codepoint: 'U+EC45',
  },
  kodalyHandMi: {
    codepoint: 'U+EC42',
  },
  kodalyHandRe: {
    codepoint: 'U+EC41',
  },
  kodalyHandSo: {
    codepoint: 'U+EC44',
  },
  kodalyHandTi: {
    codepoint: 'U+EC46',
  },
  leftRepeatSmall: {
    codepoint: 'U+E04C',
  },
  legerLine: {
    codepoint: 'U+E022',
  },
  legerLineNarrow: {
    codepoint: 'U+E024',
  },
  legerLineWide: {
    codepoint: 'U+E023',
  },
  luteBarlineEndRepeat: {
    codepoint: 'U+EBA4',
  },
  luteBarlineFinal: {
    codepoint: 'U+EBA5',
  },
  luteBarlineStartRepeat: {
    codepoint: 'U+EBA3',
  },
  luteDuration16th: {
    codepoint: 'U+EBAB',
  },
  luteDuration32nd: {
    codepoint: 'U+EBAC',
  },
  luteDuration8th: {
    codepoint: 'U+EBAA',
  },
  luteDurationDoubleWhole: {
    codepoint: 'U+EBA6',
  },
  luteDurationHalf: {
    codepoint: 'U+EBA8',
  },
  luteDurationQuarter: {
    codepoint: 'U+EBA9',
  },
  luteDurationWhole: {
    codepoint: 'U+EBA7',
  },
  luteFingeringRHFirst: {
    codepoint: 'U+EBAE',
  },
  luteFingeringRHSecond: {
    codepoint: 'U+EBAF',
  },
  luteFingeringRHThird: {
    codepoint: 'U+EBB0',
  },
  luteFingeringRHThumb: {
    codepoint: 'U+EBAD',
  },
  luteFrench10thCourse: {
    codepoint: 'U+EBD0',
  },
  luteFrench7thCourse: {
    codepoint: 'U+EBCD',
  },
  luteFrench8thCourse: {
    codepoint: 'U+EBCE',
  },
  luteFrench9thCourse: {
    codepoint: 'U+EBCF',
  },
  luteFrenchAppoggiaturaAbove: {
    codepoint: 'U+EBD5',
  },
  luteFrenchAppoggiaturaBelow: {
    codepoint: 'U+EBD4',
  },
  luteFrenchFretA: {
    codepoint: 'U+EBC0',
  },
  luteFrenchFretB: {
    codepoint: 'U+EBC1',
  },
  luteFrenchFretC: {
    codepoint: 'U+EBC2',
  },
  luteFrenchFretD: {
    codepoint: 'U+EBC3',
  },
  luteFrenchFretE: {
    codepoint: 'U+EBC4',
  },
  luteFrenchFretF: {
    codepoint: 'U+EBC5',
  },
  luteFrenchFretG: {
    codepoint: 'U+EBC6',
  },
  luteFrenchFretH: {
    codepoint: 'U+EBC7',
  },
  luteFrenchFretI: {
    codepoint: 'U+EBC8',
  },
  luteFrenchFretK: {
    codepoint: 'U+EBC9',
  },
  luteFrenchFretL: {
    codepoint: 'U+EBCA',
  },
  luteFrenchFretM: {
    codepoint: 'U+EBCB',
  },
  luteFrenchFretN: {
    codepoint: 'U+EBCC',
  },
  luteFrenchMordentInverted: {
    codepoint: 'U+EBD3',
  },
  luteFrenchMordentLower: {
    codepoint: 'U+EBD2',
  },
  luteFrenchMordentUpper: {
    codepoint: 'U+EBD1',
  },
  luteGermanALower: {
    codepoint: 'U+EC00',
  },
  luteGermanAUpper: {
    codepoint: 'U+EC17',
  },
  luteGermanBLower: {
    codepoint: 'U+EC01',
  },
  luteGermanBUpper: {
    codepoint: 'U+EC18',
  },
  luteGermanCLower: {
    codepoint: 'U+EC02',
  },
  luteGermanCUpper: {
    codepoint: 'U+EC19',
  },
  luteGermanDLower: {
    codepoint: 'U+EC03',
  },
  luteGermanDUpper: {
    codepoint: 'U+EC1A',
  },
  luteGermanELower: {
    codepoint: 'U+EC04',
  },
  luteGermanEUpper: {
    codepoint: 'U+EC1B',
  },
  luteGermanFLower: {
    codepoint: 'U+EC05',
  },
  luteGermanFUpper: {
    codepoint: 'U+EC1C',
  },
  luteGermanGLower: {
    codepoint: 'U+EC06',
  },
  luteGermanGUpper: {
    codepoint: 'U+EC1D',
  },
  luteGermanHLower: {
    codepoint: 'U+EC07',
  },
  luteGermanHUpper: {
    codepoint: 'U+EC1E',
  },
  luteGermanILower: {
    codepoint: 'U+EC08',
  },
  luteGermanIUpper: {
    codepoint: 'U+EC1F',
  },
  luteGermanKLower: {
    codepoint: 'U+EC09',
  },
  luteGermanKUpper: {
    codepoint: 'U+EC20',
  },
  luteGermanLLower: {
    codepoint: 'U+EC0A',
  },
  luteGermanLUpper: {
    codepoint: 'U+EC21',
  },
  luteGermanMLower: {
    codepoint: 'U+EC0B',
  },
  luteGermanMUpper: {
    codepoint: 'U+EC22',
  },
  luteGermanNLower: {
    codepoint: 'U+EC0C',
  },
  luteGermanNUpper: {
    codepoint: 'U+EC23',
  },
  luteGermanOLower: {
    codepoint: 'U+EC0D',
  },
  luteGermanPLower: {
    codepoint: 'U+EC0E',
  },
  luteGermanQLower: {
    codepoint: 'U+EC0F',
  },
  luteGermanRLower: {
    codepoint: 'U+EC10',
  },
  luteGermanSLower: {
    codepoint: 'U+EC11',
  },
  luteGermanTLower: {
    codepoint: 'U+EC12',
  },
  luteGermanVLower: {
    codepoint: 'U+EC13',
  },
  luteGermanXLower: {
    codepoint: 'U+EC14',
  },
  luteGermanYLower: {
    codepoint: 'U+EC15',
  },
  luteGermanZLower: {
    codepoint: 'U+EC16',
  },
  luteItalianClefCSolFaUt: {
    codepoint: 'U+EBF1',
  },
  luteItalianClefFFaUt: {
    codepoint: 'U+EBF0',
  },
  luteItalianFret0: {
    codepoint: 'U+EBE0',
  },
  luteItalianFret1: {
    codepoint: 'U+EBE1',
  },
  luteItalianFret2: {
    codepoint: 'U+EBE2',
  },
  luteItalianFret3: {
    codepoint: 'U+EBE3',
  },
  luteItalianFret4: {
    codepoint: 'U+EBE4',
  },
  luteItalianFret5: {
    codepoint: 'U+EBE5',
  },
  luteItalianFret6: {
    codepoint: 'U+EBE6',
  },
  luteItalianFret7: {
    codepoint: 'U+EBE7',
  },
  luteItalianFret8: {
    codepoint: 'U+EBE8',
  },
  luteItalianFret9: {
    codepoint: 'U+EBE9',
  },
  luteItalianHoldFinger: {
    codepoint: 'U+EBF4',
  },
  luteItalianHoldNote: {
    codepoint: 'U+EBF3',
  },
  luteItalianReleaseFinger: {
    codepoint: 'U+EBF5',
  },
  luteItalianTempoFast: {
    codepoint: 'U+EBEA',
  },
  luteItalianTempoNeitherFastNorSlow: {
    codepoint: 'U+EBEC',
  },
  luteItalianTempoSlow: {
    codepoint: 'U+EBED',
  },
  luteItalianTempoSomewhatFast: {
    codepoint: 'U+EBEB',
  },
  luteItalianTempoVerySlow: {
    codepoint: 'U+EBEE',
  },
  luteItalianTimeTriple: {
    codepoint: 'U+EBEF',
  },
  luteItalianTremolo: {
    codepoint: 'U+EBF2',
  },
  luteItalianVibrato: {
    codepoint: 'U+EBF6',
  },
  luteStaff6Lines: {
    codepoint: 'U+EBA0',
  },
  luteStaff6LinesNarrow: {
    codepoint: 'U+EBA2',
  },
  luteStaff6LinesWide: {
    codepoint: 'U+EBA1',
  },
  lyricsElision: {
    codepoint: 'U+E551',
  },
  lyricsElisionNarrow: {
    codepoint: 'U+E550',
  },
  lyricsElisionWide: {
    codepoint: 'U+E552',
  },
  lyricsHyphenBaseline: {
    codepoint: 'U+E553',
  },
  lyricsHyphenBaselineNonBreaking: {
    codepoint: 'U+E554',
  },
  lyricsTextRepeat: {
    codepoint: 'U+E555',
  },
  medRenFlatHardB: {
    codepoint: 'U+E9E1',
  },
  medRenFlatSoftB: {
    alternateCodepoint: 'U+1D1D2',
    codepoint: 'U+E9E0',
  },
  medRenFlatWithDot: {
    codepoint: 'U+E9E4',
  },
  medRenGClefCMN: {
    codepoint: 'U+EA24',
  },
  medRenLiquescenceCMN: {
    codepoint: 'U+EA22',
  },
  medRenLiquescentAscCMN: {
    codepoint: 'U+EA26',
  },
  medRenLiquescentDescCMN: {
    codepoint: 'U+EA27',
  },
  medRenNatural: {
    codepoint: 'U+E9E2',
  },
  medRenNaturalWithCross: {
    codepoint: 'U+E9E5',
  },
  medRenOriscusCMN: {
    codepoint: 'U+EA2A',
  },
  medRenPlicaCMN: {
    codepoint: 'U+EA23',
  },
  medRenPunctumCMN: {
    codepoint: 'U+EA25',
  },
  medRenQuilismaCMN: {
    codepoint: 'U+EA28',
  },
  medRenSharpCroix: {
    alternateCodepoint: 'U+1D1CF',
    codepoint: 'U+E9E3',
  },
  medRenStrophicusCMN: {
    codepoint: 'U+EA29',
  },
  mensuralAlterationSign: {
    codepoint: 'U+EA10',
  },
  mensuralBlackBrevis: {
    codepoint: 'U+E952',
  },
  mensuralBlackBrevisVoid: {
    codepoint: 'U+E956',
  },
  mensuralBlackDragma: {
    codepoint: 'U+E95A',
  },
  mensuralBlackLonga: {
    codepoint: 'U+E951',
  },
  mensuralBlackMaxima: {
    codepoint: 'U+E950',
  },
  mensuralBlackMinima: {
    alternateCodepoint: 'U+1D1BC',
    codepoint: 'U+E954',
  },
  mensuralBlackMinimaVoid: {
    alternateCodepoint: 'U+1D1BB',
    codepoint: 'U+E958',
  },
  mensuralBlackSemibrevis: {
    alternateCodepoint: 'U+1D1BA',
    codepoint: 'U+E953',
  },
  mensuralBlackSemibrevisCaudata: {
    codepoint: 'U+E959',
  },
  mensuralBlackSemibrevisOblique: {
    codepoint: 'U+E95B',
  },
  mensuralBlackSemibrevisVoid: {
    alternateCodepoint: 'U+1D1B9',
    codepoint: 'U+E957',
  },
  mensuralBlackSemiminima: {
    codepoint: 'U+E955',
  },
  mensuralCclef: {
    codepoint: 'U+E905',
  },
  mensuralCclefPetrucciPosHigh: {
    codepoint: 'U+E90A',
  },
  mensuralCclefPetrucciPosHighest: {
    codepoint: 'U+E90B',
  },
  mensuralCclefPetrucciPosLow: {
    codepoint: 'U+E908',
  },
  mensuralCclefPetrucciPosLowest: {
    codepoint: 'U+E907',
  },
  mensuralCclefPetrucciPosMiddle: {
    codepoint: 'U+E909',
  },
  mensuralColorationEndRound: {
    codepoint: 'U+EA0F',
  },
  mensuralColorationEndSquare: {
    codepoint: 'U+EA0D',
  },
  mensuralColorationStartRound: {
    codepoint: 'U+EA0E',
  },
  mensuralColorationStartSquare: {
    codepoint: 'U+EA0C',
  },
  mensuralCombStemDiagonal: {
    codepoint: 'U+E940',
  },
  mensuralCombStemDown: {
    codepoint: 'U+E93F',
  },
  mensuralCombStemDownFlagExtended: {
    codepoint: 'U+E948',
  },
  mensuralCombStemDownFlagFlared: {
    codepoint: 'U+E946',
  },
  mensuralCombStemDownFlagFusa: {
    codepoint: 'U+E94C',
  },
  mensuralCombStemDownFlagLeft: {
    codepoint: 'U+E944',
  },
  mensuralCombStemDownFlagRight: {
    codepoint: 'U+E942',
  },
  mensuralCombStemDownFlagSemiminima: {
    codepoint: 'U+E94A',
  },
  mensuralCombStemUp: {
    codepoint: 'U+E93E',
  },
  mensuralCombStemUpFlagExtended: {
    codepoint: 'U+E947',
  },
  mensuralCombStemUpFlagFlared: {
    codepoint: 'U+E945',
  },
  mensuralCombStemUpFlagFusa: {
    codepoint: 'U+E94B',
  },
  mensuralCombStemUpFlagLeft: {
    codepoint: 'U+E943',
  },
  mensuralCombStemUpFlagRight: {
    codepoint: 'U+E941',
  },
  mensuralCombStemUpFlagSemiminima: {
    codepoint: 'U+E949',
  },
  mensuralCustosCheckmark: {
    codepoint: 'U+EA0A',
  },
  mensuralCustosDown: {
    codepoint: 'U+EA03',
  },
  mensuralCustosTurn: {
    codepoint: 'U+EA0B',
  },
  mensuralCustosUp: {
    codepoint: 'U+EA02',
  },
  mensuralFclef: {
    codepoint: 'U+E903',
  },
  mensuralFclefPetrucci: {
    codepoint: 'U+E904',
  },
  mensuralGclef: {
    codepoint: 'U+E900',
  },
  mensuralGclefPetrucci: {
    codepoint: 'U+E901',
  },
  mensuralModusImperfectumVert: {
    codepoint: 'U+E92D',
  },
  mensuralModusPerfectumVert: {
    codepoint: 'U+E92C',
  },
  mensuralNoteheadLongaBlack: {
    codepoint: 'U+E934',
  },
  mensuralNoteheadLongaBlackVoid: {
    codepoint: 'U+E936',
  },
  mensuralNoteheadLongaVoid: {
    codepoint: 'U+E935',
  },
  mensuralNoteheadLongaWhite: {
    codepoint: 'U+E937',
  },
  mensuralNoteheadMaximaBlack: {
    codepoint: 'U+E930',
  },
  mensuralNoteheadMaximaBlackVoid: {
    codepoint: 'U+E932',
  },
  mensuralNoteheadMaximaVoid: {
    codepoint: 'U+E931',
  },
  mensuralNoteheadMaximaWhite: {
    codepoint: 'U+E933',
  },
  mensuralNoteheadMinimaWhite: {
    codepoint: 'U+E93C',
  },
  mensuralNoteheadSemibrevisBlack: {
    codepoint: 'U+E938',
  },
  mensuralNoteheadSemibrevisBlackVoid: {
    codepoint: 'U+E93A',
  },
  mensuralNoteheadSemibrevisBlackVoidTurned: {
    codepoint: 'U+E93B',
  },
  mensuralNoteheadSemibrevisVoid: {
    codepoint: 'U+E939',
  },
  mensuralNoteheadSemiminimaWhite: {
    codepoint: 'U+E93D',
  },
  mensuralObliqueAsc2ndBlack: {
    codepoint: 'U+E970',
  },
  mensuralObliqueAsc2ndBlackVoid: {
    codepoint: 'U+E972',
  },
  mensuralObliqueAsc2ndVoid: {
    codepoint: 'U+E971',
  },
  mensuralObliqueAsc2ndWhite: {
    codepoint: 'U+E973',
  },
  mensuralObliqueAsc3rdBlack: {
    codepoint: 'U+E974',
  },
  mensuralObliqueAsc3rdBlackVoid: {
    codepoint: 'U+E976',
  },
  mensuralObliqueAsc3rdVoid: {
    codepoint: 'U+E975',
  },
  mensuralObliqueAsc3rdWhite: {
    codepoint: 'U+E977',
  },
  mensuralObliqueAsc4thBlack: {
    codepoint: 'U+E978',
  },
  mensuralObliqueAsc4thBlackVoid: {
    codepoint: 'U+E97A',
  },
  mensuralObliqueAsc4thVoid: {
    codepoint: 'U+E979',
  },
  mensuralObliqueAsc4thWhite: {
    codepoint: 'U+E97B',
  },
  mensuralObliqueAsc5thBlack: {
    codepoint: 'U+E97C',
  },
  mensuralObliqueAsc5thBlackVoid: {
    codepoint: 'U+E97E',
  },
  mensuralObliqueAsc5thVoid: {
    codepoint: 'U+E97D',
  },
  mensuralObliqueAsc5thWhite: {
    codepoint: 'U+E97F',
  },
  mensuralObliqueDesc2ndBlack: {
    codepoint: 'U+E980',
  },
  mensuralObliqueDesc2ndBlackVoid: {
    codepoint: 'U+E982',
  },
  mensuralObliqueDesc2ndVoid: {
    codepoint: 'U+E981',
  },
  mensuralObliqueDesc2ndWhite: {
    codepoint: 'U+E983',
  },
  mensuralObliqueDesc3rdBlack: {
    codepoint: 'U+E984',
  },
  mensuralObliqueDesc3rdBlackVoid: {
    codepoint: 'U+E986',
  },
  mensuralObliqueDesc3rdVoid: {
    codepoint: 'U+E985',
  },
  mensuralObliqueDesc3rdWhite: {
    codepoint: 'U+E987',
  },
  mensuralObliqueDesc4thBlack: {
    codepoint: 'U+E988',
  },
  mensuralObliqueDesc4thBlackVoid: {
    codepoint: 'U+E98A',
  },
  mensuralObliqueDesc4thVoid: {
    codepoint: 'U+E989',
  },
  mensuralObliqueDesc4thWhite: {
    codepoint: 'U+E98B',
  },
  mensuralObliqueDesc5thBlack: {
    codepoint: 'U+E98C',
  },
  mensuralObliqueDesc5thBlackVoid: {
    codepoint: 'U+E98E',
  },
  mensuralObliqueDesc5thVoid: {
    codepoint: 'U+E98D',
  },
  mensuralObliqueDesc5thWhite: {
    codepoint: 'U+E98F',
  },
  mensuralProlation1: {
    alternateCodepoint: 'U+1D1C7',
    codepoint: 'U+E910',
  },
  mensuralProlation10: {
    alternateCodepoint: 'U+1D1CE',
    codepoint: 'U+E919',
  },
  mensuralProlation11: {
    codepoint: 'U+E91A',
  },
  mensuralProlation2: {
    alternateCodepoint: 'U+1D1C8',
    codepoint: 'U+E911',
  },
  mensuralProlation3: {
    alternateCodepoint: 'U+1D1C9',
    codepoint: 'U+E912',
  },
  mensuralProlation4: {
    codepoint: 'U+E913',
  },
  mensuralProlation5: {
    alternateCodepoint: 'U+1D1CA',
    codepoint: 'U+E914',
  },
  mensuralProlation6: {
    alternateCodepoint: 'U+1D1CB',
    codepoint: 'U+E915',
  },
  mensuralProlation7: {
    alternateCodepoint: 'U+1D1CC',
    codepoint: 'U+E916',
  },
  mensuralProlation8: {
    codepoint: 'U+E917',
  },
  mensuralProlation9: {
    alternateCodepoint: 'U+1D1CD',
    codepoint: 'U+E918',
  },
  mensuralProlationCombiningDot: {
    codepoint: 'U+E920',
  },
  mensuralProlationCombiningDotVoid: {
    codepoint: 'U+E924',
  },
  mensuralProlationCombiningStroke: {
    codepoint: 'U+E925',
  },
  mensuralProlationCombiningThreeDots: {
    codepoint: 'U+E922',
  },
  mensuralProlationCombiningThreeDotsTri: {
    codepoint: 'U+E923',
  },
  mensuralProlationCombiningTwoDots: {
    codepoint: 'U+E921',
  },
  mensuralProportion1: {
    codepoint: 'U+E926',
  },
  mensuralProportion2: {
    codepoint: 'U+E927',
  },
  mensuralProportion3: {
    codepoint: 'U+E928',
  },
  mensuralProportion4: {
    codepoint: 'U+E929',
  },
  mensuralProportion5: {
    codepoint: 'U+EE90',
  },
  mensuralProportion6: {
    codepoint: 'U+EE91',
  },
  mensuralProportion7: {
    codepoint: 'U+EE92',
  },
  mensuralProportion8: {
    codepoint: 'U+EE93',
  },
  mensuralProportion9: {
    codepoint: 'U+EE94',
  },
  mensuralProportionMajor: {
    codepoint: 'U+E92B',
  },
  mensuralProportionMinor: {
    codepoint: 'U+E92A',
  },
  mensuralProportionProportioDupla1: {
    codepoint: 'U+E91C',
  },
  mensuralProportionProportioDupla2: {
    codepoint: 'U+E91D',
  },
  mensuralProportionProportioQuadrupla: {
    codepoint: 'U+E91F',
  },
  mensuralProportionProportioTripla: {
    codepoint: 'U+E91E',
  },
  mensuralProportionTempusPerfectum: {
    codepoint: 'U+E91B',
  },
  mensuralRestBrevis: {
    alternateCodepoint: 'U+1D1C3',
    codepoint: 'U+E9F3',
  },
  mensuralRestFusa: {
    codepoint: 'U+E9F7',
  },
  mensuralRestLongaImperfecta: {
    alternateCodepoint: 'U+1D1C2',
    codepoint: 'U+E9F2',
  },
  mensuralRestLongaPerfecta: {
    alternateCodepoint: 'U+1D1C1',
    codepoint: 'U+E9F1',
  },
  mensuralRestMaxima: {
    codepoint: 'U+E9F0',
  },
  mensuralRestMinima: {
    alternateCodepoint: 'U+1D1C5',
    codepoint: 'U+E9F5',
  },
  mensuralRestSemibrevis: {
    alternateCodepoint: 'U+1D1C4',
    codepoint: 'U+E9F4',
  },
  mensuralRestSemifusa: {
    codepoint: 'U+E9F8',
  },
  mensuralRestSemiminima: {
    alternateCodepoint: 'U+1D1C6',
    codepoint: 'U+E9F6',
  },
  mensuralSignumDown: {
    codepoint: 'U+EA01',
  },
  mensuralSignumUp: {
    codepoint: 'U+EA00',
  },
  mensuralTempusImperfectumHoriz: {
    codepoint: 'U+E92F',
  },
  mensuralTempusPerfectumHoriz: {
    codepoint: 'U+E92E',
  },
  mensuralWhiteBrevis: {
    alternateCodepoint: 'U+1D1B8',
    codepoint: 'U+E95E',
  },
  mensuralWhiteFusa: {
    alternateCodepoint: 'U+1D1BE',
    codepoint: 'U+E961',
  },
  mensuralWhiteLonga: {
    alternateCodepoint: 'U+1D1B7',
    codepoint: 'U+E95D',
  },
  mensuralWhiteMaxima: {
    alternateCodepoint: 'U+1D1B6',
    codepoint: 'U+E95C',
  },
  mensuralWhiteMinima: {
    codepoint: 'U+E95F',
  },
  mensuralWhiteSemibrevis: {
    alternateCodepoint: 'U+1D1B9',
    codepoint: 'U+E962',
  },
  mensuralWhiteSemiminima: {
    codepoint: 'U+E960',
  },
  metAugmentationDot: {
    codepoint: 'U+ECB7',
  },
  metNote1024thDown: {
    codepoint: 'U+ECB6',
  },
  metNote1024thUp: {
    codepoint: 'U+ECB5',
  },
  metNote128thDown: {
    codepoint: 'U+ECB0',
  },
  metNote128thUp: {
    codepoint: 'U+ECAF',
  },
  metNote16thDown: {
    codepoint: 'U+ECAA',
  },
  metNote16thUp: {
    codepoint: 'U+ECA9',
  },
  metNote256thDown: {
    codepoint: 'U+ECB2',
  },
  metNote256thUp: {
    codepoint: 'U+ECB1',
  },
  metNote32ndDown: {
    codepoint: 'U+ECAC',
  },
  metNote32ndUp: {
    codepoint: 'U+ECAB',
  },
  metNote512thDown: {
    codepoint: 'U+ECB4',
  },
  metNote512thUp: {
    codepoint: 'U+ECB3',
  },
  metNote64thDown: {
    codepoint: 'U+ECAE',
  },
  metNote64thUp: {
    codepoint: 'U+ECAD',
  },
  metNote8thDown: {
    codepoint: 'U+ECA8',
  },
  metNote8thUp: {
    codepoint: 'U+ECA7',
  },
  metNoteDoubleWhole: {
    codepoint: 'U+ECA0',
  },
  metNoteDoubleWholeSquare: {
    codepoint: 'U+ECA1',
  },
  metNoteHalfDown: {
    codepoint: 'U+ECA4',
  },
  metNoteHalfUp: {
    codepoint: 'U+ECA3',
  },
  metNoteQuarterDown: {
    codepoint: 'U+ECA6',
  },
  metNoteQuarterUp: {
    codepoint: 'U+ECA5',
  },
  metNoteWhole: {
    codepoint: 'U+ECA2',
  },
  metricModulationArrowLeft: {
    codepoint: 'U+EC63',
  },
  metricModulationArrowRight: {
    codepoint: 'U+EC64',
  },
  miscDoNotCopy: {
    codepoint: 'U+EC61',
  },
  miscDoNotPhotocopy: {
    codepoint: 'U+EC60',
  },
  miscEyeglasses: {
    codepoint: 'U+EC62',
  },
  note1024thDown: {
    codepoint: 'U+E1E6',
  },
  note1024thUp: {
    codepoint: 'U+E1E5',
  },
  note128thDown: {
    codepoint: 'U+E1E0',
  },
  note128thUp: {
    alternateCodepoint: 'U+1D164',
    codepoint: 'U+E1DF',
  },
  note16thDown: {
    codepoint: 'U+E1DA',
  },
  note16thUp: {
    alternateCodepoint: 'U+1D161',
    codepoint: 'U+E1D9',
  },
  note256thDown: {
    codepoint: 'U+E1E2',
  },
  note256thUp: {
    codepoint: 'U+E1E1',
  },
  note32ndDown: {
    codepoint: 'U+E1DC',
  },
  note32ndUp: {
    alternateCodepoint: 'U+1D162',
    codepoint: 'U+E1DB',
  },
  note512thDown: {
    codepoint: 'U+E1E4',
  },
  note512thUp: {
    codepoint: 'U+E1E3',
  },
  note64thDown: {
    codepoint: 'U+E1DE',
  },
  note64thUp: {
    alternateCodepoint: 'U+1D163',
    codepoint: 'U+E1DD',
  },
  note8thDown: {
    codepoint: 'U+E1D8',
  },
  note8thUp: {
    alternateCodepoint: 'U+1D160',
    codepoint: 'U+E1D7',
  },
  noteABlack: {
    codepoint: 'U+E197',
  },
  noteAFlatBlack: {
    codepoint: 'U+E196',
  },
  noteAFlatHalf: {
    codepoint: 'U+E17F',
  },
  noteAFlatWhole: {
    codepoint: 'U+E168',
  },
  noteAHalf: {
    codepoint: 'U+E180',
  },
  noteASharpBlack: {
    codepoint: 'U+E198',
  },
  noteASharpHalf: {
    codepoint: 'U+E181',
  },
  noteASharpWhole: {
    codepoint: 'U+E16A',
  },
  noteAWhole: {
    codepoint: 'U+E169',
  },
  noteBBlack: {
    codepoint: 'U+E19A',
  },
  noteBFlatBlack: {
    codepoint: 'U+E199',
  },
  noteBFlatHalf: {
    codepoint: 'U+E182',
  },
  noteBFlatWhole: {
    codepoint: 'U+E16B',
  },
  noteBHalf: {
    codepoint: 'U+E183',
  },
  noteBSharpBlack: {
    codepoint: 'U+E19B',
  },
  noteBSharpHalf: {
    codepoint: 'U+E184',
  },
  noteBSharpWhole: {
    codepoint: 'U+E16D',
  },
  noteBWhole: {
    codepoint: 'U+E16C',
  },
  noteCBlack: {
    codepoint: 'U+E19D',
  },
  noteCFlatBlack: {
    codepoint: 'U+E19C',
  },
  noteCFlatHalf: {
    codepoint: 'U+E185',
  },
  noteCFlatWhole: {
    codepoint: 'U+E16E',
  },
  noteCHalf: {
    codepoint: 'U+E186',
  },
  noteCSharpBlack: {
    codepoint: 'U+E19E',
  },
  noteCSharpHalf: {
    codepoint: 'U+E187',
  },
  noteCSharpWhole: {
    codepoint: 'U+E170',
  },
  noteCWhole: {
    codepoint: 'U+E16F',
  },
  noteDBlack: {
    codepoint: 'U+E1A0',
  },
  noteDFlatBlack: {
    codepoint: 'U+E19F',
  },
  noteDFlatHalf: {
    codepoint: 'U+E188',
  },
  noteDFlatWhole: {
    codepoint: 'U+E171',
  },
  noteDHalf: {
    codepoint: 'U+E189',
  },
  noteDSharpBlack: {
    codepoint: 'U+E1A1',
  },
  noteDSharpHalf: {
    codepoint: 'U+E18A',
  },
  noteDSharpWhole: {
    codepoint: 'U+E173',
  },
  noteDWhole: {
    codepoint: 'U+E172',
  },
  noteDiBlack: {
    codepoint: 'U+EEF2',
  },
  noteDiHalf: {
    codepoint: 'U+EEE9',
  },
  noteDiWhole: {
    codepoint: 'U+EEE0',
  },
  noteDoBlack: {
    codepoint: 'U+E160',
  },
  noteDoHalf: {
    codepoint: 'U+E158',
  },
  noteDoWhole: {
    codepoint: 'U+E150',
  },
  noteDoubleWhole: {
    alternateCodepoint: 'U+1D15C',
    codepoint: 'U+E1D0',
  },
  noteDoubleWholeSquare: {
    codepoint: 'U+E1D1',
  },
  noteEBlack: {
    codepoint: 'U+E1A3',
  },
  noteEFlatBlack: {
    codepoint: 'U+E1A2',
  },
  noteEFlatHalf: {
    codepoint: 'U+E18B',
  },
  noteEFlatWhole: {
    codepoint: 'U+E174',
  },
  noteEHalf: {
    codepoint: 'U+E18C',
  },
  noteESharpBlack: {
    codepoint: 'U+E1A4',
  },
  noteESharpHalf: {
    codepoint: 'U+E18D',
  },
  noteESharpWhole: {
    codepoint: 'U+E176',
  },
  noteEWhole: {
    codepoint: 'U+E175',
  },
  noteEmptyBlack: {
    codepoint: 'U+E1AF',
  },
  noteEmptyHalf: {
    codepoint: 'U+E1AE',
  },
  noteEmptyWhole: {
    codepoint: 'U+E1AD',
  },
  noteFBlack: {
    codepoint: 'U+E1A6',
  },
  noteFFlatBlack: {
    codepoint: 'U+E1A5',
  },
  noteFFlatHalf: {
    codepoint: 'U+E18E',
  },
  noteFFlatWhole: {
    codepoint: 'U+E177',
  },
  noteFHalf: {
    codepoint: 'U+E18F',
  },
  noteFSharpBlack: {
    codepoint: 'U+E1A7',
  },
  noteFSharpHalf: {
    codepoint: 'U+E190',
  },
  noteFSharpWhole: {
    codepoint: 'U+E179',
  },
  noteFWhole: {
    codepoint: 'U+E178',
  },
  noteFaBlack: {
    codepoint: 'U+E163',
  },
  noteFaHalf: {
    codepoint: 'U+E15B',
  },
  noteFaWhole: {
    codepoint: 'U+E153',
  },
  noteFiBlack: {
    codepoint: 'U+EEF6',
  },
  noteFiHalf: {
    codepoint: 'U+EEED',
  },
  noteFiWhole: {
    codepoint: 'U+EEE4',
  },
  noteGBlack: {
    codepoint: 'U+E1A9',
  },
  noteGFlatBlack: {
    codepoint: 'U+E1A8',
  },
  noteGFlatHalf: {
    codepoint: 'U+E191',
  },
  noteGFlatWhole: {
    codepoint: 'U+E17A',
  },
  noteGHalf: {
    codepoint: 'U+E192',
  },
  noteGSharpBlack: {
    codepoint: 'U+E1AA',
  },
  noteGSharpHalf: {
    codepoint: 'U+E193',
  },
  noteGSharpWhole: {
    codepoint: 'U+E17C',
  },
  noteGWhole: {
    codepoint: 'U+E17B',
  },
  noteHBlack: {
    codepoint: 'U+E1AB',
  },
  noteHHalf: {
    codepoint: 'U+E194',
  },
  noteHSharpBlack: {
    codepoint: 'U+E1AC',
  },
  noteHSharpHalf: {
    codepoint: 'U+E195',
  },
  noteHSharpWhole: {
    codepoint: 'U+E17E',
  },
  noteHWhole: {
    codepoint: 'U+E17D',
  },
  noteHalfDown: {
    codepoint: 'U+E1D4',
  },
  noteHalfUp: {
    alternateCodepoint: 'U+1D15E',
    codepoint: 'U+E1D3',
  },
  noteLaBlack: {
    codepoint: 'U+E165',
  },
  noteLaHalf: {
    codepoint: 'U+E15D',
  },
  noteLaWhole: {
    codepoint: 'U+E155',
  },
  noteLeBlack: {
    codepoint: 'U+EEF9',
  },
  noteLeHalf: {
    codepoint: 'U+EEF0',
  },
  noteLeWhole: {
    codepoint: 'U+EEE7',
  },
  noteLiBlack: {
    codepoint: 'U+EEF8',
  },
  noteLiHalf: {
    codepoint: 'U+EEEF',
  },
  noteLiWhole: {
    codepoint: 'U+EEE6',
  },
  noteMeBlack: {
    codepoint: 'U+EEF5',
  },
  noteMeHalf: {
    codepoint: 'U+EEEC',
  },
  noteMeWhole: {
    codepoint: 'U+EEE3',
  },
  noteMiBlack: {
    codepoint: 'U+E162',
  },
  noteMiHalf: {
    codepoint: 'U+E15A',
  },
  noteMiWhole: {
    codepoint: 'U+E152',
  },
  noteQuarterDown: {
    codepoint: 'U+E1D6',
  },
  noteQuarterUp: {
    alternateCodepoint: 'U+1D15F',
    codepoint: 'U+E1D5',
  },
  noteRaBlack: {
    codepoint: 'U+EEF4',
  },
  noteRaHalf: {
    codepoint: 'U+EEEB',
  },
  noteRaWhole: {
    codepoint: 'U+EEE2',
  },
  noteReBlack: {
    codepoint: 'U+E161',
  },
  noteReHalf: {
    codepoint: 'U+E159',
  },
  noteReWhole: {
    codepoint: 'U+E151',
  },
  noteRiBlack: {
    codepoint: 'U+EEF3',
  },
  noteRiHalf: {
    codepoint: 'U+EEEA',
  },
  noteRiWhole: {
    codepoint: 'U+EEE1',
  },
  noteSeBlack: {
    codepoint: 'U+EEF7',
  },
  noteSeHalf: {
    codepoint: 'U+EEEE',
  },
  noteSeWhole: {
    codepoint: 'U+EEE5',
  },
  noteShapeArrowheadLeftBlack: {
    codepoint: 'U+E1C9',
  },
  noteShapeArrowheadLeftDoubleWhole: {
    codepoint: 'U+ECDC',
  },
  noteShapeArrowheadLeftWhite: {
    codepoint: 'U+E1C8',
  },
  noteShapeDiamondBlack: {
    codepoint: 'U+E1B9',
  },
  noteShapeDiamondDoubleWhole: {
    codepoint: 'U+ECD4',
  },
  noteShapeDiamondWhite: {
    codepoint: 'U+E1B8',
  },
  noteShapeIsoscelesTriangleBlack: {
    codepoint: 'U+E1C5',
  },
  noteShapeIsoscelesTriangleDoubleWhole: {
    codepoint: 'U+ECDA',
  },
  noteShapeIsoscelesTriangleWhite: {
    codepoint: 'U+E1C4',
  },
  noteShapeKeystoneBlack: {
    codepoint: 'U+E1C1',
  },
  noteShapeKeystoneDoubleWhole: {
    codepoint: 'U+ECD8',
  },
  noteShapeKeystoneWhite: {
    codepoint: 'U+E1C0',
  },
  noteShapeMoonBlack: {
    codepoint: 'U+E1BD',
  },
  noteShapeMoonDoubleWhole: {
    codepoint: 'U+ECD6',
  },
  noteShapeMoonLeftBlack: {
    codepoint: 'U+E1C7',
  },
  noteShapeMoonLeftDoubleWhole: {
    codepoint: 'U+ECDB',
  },
  noteShapeMoonLeftWhite: {
    codepoint: 'U+E1C6',
  },
  noteShapeMoonWhite: {
    codepoint: 'U+E1BC',
  },
  noteShapeQuarterMoonBlack: {
    codepoint: 'U+E1C3',
  },
  noteShapeQuarterMoonDoubleWhole: {
    codepoint: 'U+ECD9',
  },
  noteShapeQuarterMoonWhite: {
    codepoint: 'U+E1C2',
  },
  noteShapeRoundBlack: {
    codepoint: 'U+E1B1',
  },
  noteShapeRoundDoubleWhole: {
    codepoint: 'U+ECD0',
  },
  noteShapeRoundWhite: {
    codepoint: 'U+E1B0',
  },
  noteShapeSquareBlack: {
    codepoint: 'U+E1B3',
  },
  noteShapeSquareDoubleWhole: {
    codepoint: 'U+ECD1',
  },
  noteShapeSquareWhite: {
    codepoint: 'U+E1B2',
  },
  noteShapeTriangleLeftBlack: {
    codepoint: 'U+E1B7',
  },
  noteShapeTriangleLeftDoubleWhole: {
    codepoint: 'U+ECD3',
  },
  noteShapeTriangleLeftWhite: {
    codepoint: 'U+E1B6',
  },
  noteShapeTriangleRightBlack: {
    codepoint: 'U+E1B5',
  },
  noteShapeTriangleRightDoubleWhole: {
    codepoint: 'U+ECD2',
  },
  noteShapeTriangleRightWhite: {
    codepoint: 'U+E1B4',
  },
  noteShapeTriangleRoundBlack: {
    codepoint: 'U+E1BF',
  },
  noteShapeTriangleRoundDoubleWhole: {
    codepoint: 'U+ECD7',
  },
  noteShapeTriangleRoundLeftBlack: {
    codepoint: 'U+E1CB',
  },
  noteShapeTriangleRoundLeftDoubleWhole: {
    codepoint: 'U+ECDD',
  },
  noteShapeTriangleRoundLeftWhite: {
    codepoint: 'U+E1CA',
  },
  noteShapeTriangleRoundWhite: {
    codepoint: 'U+E1BE',
  },
  noteShapeTriangleUpBlack: {
    codepoint: 'U+E1BB',
  },
  noteShapeTriangleUpDoubleWhole: {
    codepoint: 'U+ECD5',
  },
  noteShapeTriangleUpWhite: {
    codepoint: 'U+E1BA',
  },
  noteSiBlack: {
    codepoint: 'U+E167',
  },
  noteSiHalf: {
    codepoint: 'U+E15F',
  },
  noteSiWhole: {
    codepoint: 'U+E157',
  },
  noteSoBlack: {
    codepoint: 'U+E164',
  },
  noteSoHalf: {
    codepoint: 'U+E15C',
  },
  noteSoWhole: {
    codepoint: 'U+E154',
  },
  noteTeBlack: {
    codepoint: 'U+EEFA',
  },
  noteTeHalf: {
    codepoint: 'U+EEF1',
  },
  noteTeWhole: {
    codepoint: 'U+EEE8',
  },
  noteTiBlack: {
    codepoint: 'U+E166',
  },
  noteTiHalf: {
    codepoint: 'U+E15E',
  },
  noteTiWhole: {
    codepoint: 'U+E156',
  },
  noteWhole: {
    alternateCodepoint: 'U+1D15D',
    codepoint: 'U+E1D2',
  },
  noteheadBlack: {
    alternateCodepoint: 'U+1D158',
    codepoint: 'U+E0A4',
  },
  noteheadCircleSlash: {
    codepoint: 'U+E0F7',
  },
  noteheadCircleX: {
    alternateCodepoint: 'U+1D145',
    codepoint: 'U+E0B3',
  },
  noteheadCircleXDoubleWhole: {
    codepoint: 'U+E0B0',
  },
  noteheadCircleXHalf: {
    codepoint: 'U+E0B2',
  },
  noteheadCircleXWhole: {
    codepoint: 'U+E0B1',
  },
  noteheadCircledBlack: {
    codepoint: 'U+E0E4',
  },
  noteheadCircledBlackLarge: {
    codepoint: 'U+E0E8',
  },
  noteheadCircledDoubleWhole: {
    codepoint: 'U+E0E7',
  },
  noteheadCircledDoubleWholeLarge: {
    codepoint: 'U+E0EB',
  },
  noteheadCircledHalf: {
    codepoint: 'U+E0E5',
  },
  noteheadCircledHalfLarge: {
    codepoint: 'U+E0E9',
  },
  noteheadCircledWhole: {
    codepoint: 'U+E0E6',
  },
  noteheadCircledWholeLarge: {
    codepoint: 'U+E0EA',
  },
  noteheadCircledXLarge: {
    codepoint: 'U+E0EC',
  },
  noteheadClusterDoubleWhole2nd: {
    codepoint: 'U+E124',
  },
  noteheadClusterDoubleWhole3rd: {
    codepoint: 'U+E128',
  },
  noteheadClusterDoubleWholeBottom: {
    codepoint: 'U+E12E',
  },
  noteheadClusterDoubleWholeMiddle: {
    codepoint: 'U+E12D',
  },
  noteheadClusterDoubleWholeTop: {
    codepoint: 'U+E12C',
  },
  noteheadClusterHalf2nd: {
    codepoint: 'U+E126',
  },
  noteheadClusterHalf3rd: {
    codepoint: 'U+E12A',
  },
  noteheadClusterHalfBottom: {
    codepoint: 'U+E134',
  },
  noteheadClusterHalfMiddle: {
    codepoint: 'U+E133',
  },
  noteheadClusterHalfTop: {
    codepoint: 'U+E132',
  },
  noteheadClusterQuarter2nd: {
    codepoint: 'U+E127',
  },
  noteheadClusterQuarter3rd: {
    codepoint: 'U+E12B',
  },
  noteheadClusterQuarterBottom: {
    codepoint: 'U+E137',
  },
  noteheadClusterQuarterMiddle: {
    codepoint: 'U+E136',
  },
  noteheadClusterQuarterTop: {
    codepoint: 'U+E135',
  },
  noteheadClusterRoundBlack: {
    codepoint: 'U+E123',
  },
  noteheadClusterRoundWhite: {
    codepoint: 'U+E122',
  },
  noteheadClusterSquareBlack: {
    alternateCodepoint: 'U+1D15B',
    codepoint: 'U+E121',
  },
  noteheadClusterSquareWhite: {
    alternateCodepoint: 'U+1D15A',
    codepoint: 'U+E120',
  },
  noteheadClusterWhole2nd: {
    codepoint: 'U+E125',
  },
  noteheadClusterWhole3rd: {
    codepoint: 'U+E129',
  },
  noteheadClusterWholeBottom: {
    codepoint: 'U+E131',
  },
  noteheadClusterWholeMiddle: {
    codepoint: 'U+E130',
  },
  noteheadClusterWholeTop: {
    codepoint: 'U+E12F',
  },
  noteheadCowellEleventhNoteSeriesHalf: {
    codepoint: 'U+EEAE',
  },
  noteheadCowellEleventhNoteSeriesWhole: {
    codepoint: 'U+EEAD',
  },
  noteheadCowellEleventhSeriesBlack: {
    codepoint: 'U+EEAF',
  },
  noteheadCowellFifteenthNoteSeriesBlack: {
    codepoint: 'U+EEB5',
  },
  noteheadCowellFifteenthNoteSeriesHalf: {
    codepoint: 'U+EEB4',
  },
  noteheadCowellFifteenthNoteSeriesWhole: {
    codepoint: 'U+EEB3',
  },
  noteheadCowellFifthNoteSeriesBlack: {
    codepoint: 'U+EEA6',
  },
  noteheadCowellFifthNoteSeriesHalf: {
    codepoint: 'U+EEA5',
  },
  noteheadCowellFifthNoteSeriesWhole: {
    codepoint: 'U+EEA4',
  },
  noteheadCowellNinthNoteSeriesBlack: {
    codepoint: 'U+EEAC',
  },
  noteheadCowellNinthNoteSeriesHalf: {
    codepoint: 'U+EEAB',
  },
  noteheadCowellNinthNoteSeriesWhole: {
    codepoint: 'U+EEAA',
  },
  noteheadCowellSeventhNoteSeriesBlack: {
    codepoint: 'U+EEA9',
  },
  noteheadCowellSeventhNoteSeriesHalf: {
    codepoint: 'U+EEA8',
  },
  noteheadCowellSeventhNoteSeriesWhole: {
    codepoint: 'U+EEA7',
  },
  noteheadCowellThirdNoteSeriesBlack: {
    codepoint: 'U+EEA3',
  },
  noteheadCowellThirdNoteSeriesHalf: {
    codepoint: 'U+EEA2',
  },
  noteheadCowellThirdNoteSeriesWhole: {
    codepoint: 'U+EEA1',
  },
  noteheadCowellThirteenthNoteSeriesBlack: {
    codepoint: 'U+EEB2',
  },
  noteheadCowellThirteenthNoteSeriesHalf: {
    codepoint: 'U+EEB1',
  },
  noteheadCowellThirteenthNoteSeriesWhole: {
    codepoint: 'U+EEB0',
  },
  noteheadDiamondBlack: {
    codepoint: 'U+E0DB',
  },
  noteheadDiamondBlackOld: {
    codepoint: 'U+E0E2',
  },
  noteheadDiamondBlackWide: {
    codepoint: 'U+E0DC',
  },
  noteheadDiamondClusterBlack2nd: {
    codepoint: 'U+E139',
  },
  noteheadDiamondClusterBlack3rd: {
    codepoint: 'U+E13B',
  },
  noteheadDiamondClusterBlackBottom: {
    codepoint: 'U+E141',
  },
  noteheadDiamondClusterBlackMiddle: {
    codepoint: 'U+E140',
  },
  noteheadDiamondClusterBlackTop: {
    codepoint: 'U+E13F',
  },
  noteheadDiamondClusterWhite2nd: {
    codepoint: 'U+E138',
  },
  noteheadDiamondClusterWhite3rd: {
    codepoint: 'U+E13A',
  },
  noteheadDiamondClusterWhiteBottom: {
    codepoint: 'U+E13E',
  },
  noteheadDiamondClusterWhiteMiddle: {
    codepoint: 'U+E13D',
  },
  noteheadDiamondClusterWhiteTop: {
    codepoint: 'U+E13C',
  },
  noteheadDiamondDoubleWhole: {
    codepoint: 'U+E0D7',
  },
  noteheadDiamondDoubleWholeOld: {
    codepoint: 'U+E0DF',
  },
  noteheadDiamondHalf: {
    codepoint: 'U+E0D9',
  },
  noteheadDiamondHalfFilled: {
    codepoint: 'U+E0E3',
  },
  noteheadDiamondHalfOld: {
    codepoint: 'U+E0E1',
  },
  noteheadDiamondHalfWide: {
    codepoint: 'U+E0DA',
  },
  noteheadDiamondOpen: {
    codepoint: 'U+E0FC',
  },
  noteheadDiamondWhite: {
    codepoint: 'U+E0DD',
  },
  noteheadDiamondWhiteWide: {
    codepoint: 'U+E0DE',
  },
  noteheadDiamondWhole: {
    codepoint: 'U+E0D8',
  },
  noteheadDiamondWholeOld: {
    codepoint: 'U+E0E0',
  },
  noteheadDoubleWhole: {
    codepoint: 'U+E0A0',
  },
  noteheadDoubleWholeSquare: {
    codepoint: 'U+E0A1',
  },
  noteheadDoubleWholeWithX: {
    codepoint: 'U+E0B4',
  },
  noteheadHalf: {
    alternateCodepoint: 'U+1D157',
    codepoint: 'U+E0A3',
  },
  noteheadHalfFilled: {
    codepoint: 'U+E0FB',
  },
  noteheadHalfWithX: {
    codepoint: 'U+E0B6',
  },
  noteheadHeavyX: {
    codepoint: 'U+E0F8',
  },
  noteheadHeavyXHat: {
    codepoint: 'U+E0F9',
  },
  noteheadLargeArrowDownBlack: {
    codepoint: 'U+E0F4',
  },
  noteheadLargeArrowDownDoubleWhole: {
    codepoint: 'U+E0F1',
  },
  noteheadLargeArrowDownHalf: {
    codepoint: 'U+E0F3',
  },
  noteheadLargeArrowDownWhole: {
    codepoint: 'U+E0F2',
  },
  noteheadLargeArrowUpBlack: {
    codepoint: 'U+E0F0',
  },
  noteheadLargeArrowUpDoubleWhole: {
    codepoint: 'U+E0ED',
  },
  noteheadLargeArrowUpHalf: {
    codepoint: 'U+E0EF',
  },
  noteheadLargeArrowUpWhole: {
    codepoint: 'U+E0EE',
  },
  noteheadMoonBlack: {
    alternateCodepoint: 'U+1D153',
    codepoint: 'U+E0CB',
  },
  noteheadMoonWhite: {
    alternateCodepoint: 'U+1D152',
    codepoint: 'U+E0CA',
  },
  noteheadNancarrowSine: {
    codepoint: 'U+EEA0',
  },
  noteheadNull: {
    alternateCodepoint: 'U+1D159',
    codepoint: 'U+E0A5',
  },
  noteheadParenthesis: {
    alternateCodepoint: 'U+1D156',
    codepoint: 'U+E0CE',
  },
  noteheadParenthesisLeft: {
    codepoint: 'U+E0F5',
  },
  noteheadParenthesisRight: {
    codepoint: 'U+E0F6',
  },
  noteheadPlusBlack: {
    alternateCodepoint: 'U+1D144',
    codepoint: 'U+E0AF',
  },
  noteheadPlusDoubleWhole: {
    codepoint: 'U+E0AC',
  },
  noteheadPlusHalf: {
    codepoint: 'U+E0AE',
  },
  noteheadPlusWhole: {
    codepoint: 'U+E0AD',
  },
  noteheadRectangularClusterBlackBottom: {
    codepoint: 'U+E144',
  },
  noteheadRectangularClusterBlackMiddle: {
    codepoint: 'U+E143',
  },
  noteheadRectangularClusterBlackTop: {
    codepoint: 'U+E142',
  },
  noteheadRectangularClusterWhiteBottom: {
    codepoint: 'U+E147',
  },
  noteheadRectangularClusterWhiteMiddle: {
    codepoint: 'U+E146',
  },
  noteheadRectangularClusterWhiteTop: {
    codepoint: 'U+E145',
  },
  noteheadRoundBlack: {
    codepoint: 'U+E113',
  },
  noteheadRoundBlackDoubleSlashed: {
    codepoint: 'U+E11C',
  },
  noteheadRoundBlackLarge: {
    codepoint: 'U+E110',
  },
  noteheadRoundBlackSlashed: {
    codepoint: 'U+E118',
  },
  noteheadRoundBlackSlashedLarge: {
    codepoint: 'U+E116',
  },
  noteheadRoundWhite: {
    codepoint: 'U+E114',
  },
  noteheadRoundWhiteDoubleSlashed: {
    codepoint: 'U+E11D',
  },
  noteheadRoundWhiteLarge: {
    codepoint: 'U+E111',
  },
  noteheadRoundWhiteSlashed: {
    codepoint: 'U+E119',
  },
  noteheadRoundWhiteSlashedLarge: {
    codepoint: 'U+E117',
  },
  noteheadRoundWhiteWithDot: {
    codepoint: 'U+E115',
  },
  noteheadRoundWhiteWithDotLarge: {
    codepoint: 'U+E112',
  },
  noteheadSlashDiamondWhite: {
    codepoint: 'U+E104',
  },
  noteheadSlashHorizontalEnds: {
    alternateCodepoint: 'U+1D10D',
    codepoint: 'U+E101',
  },
  noteheadSlashHorizontalEndsMuted: {
    codepoint: 'U+E108',
  },
  noteheadSlashVerticalEnds: {
    codepoint: 'U+E100',
  },
  noteheadSlashVerticalEndsMuted: {
    codepoint: 'U+E107',
  },
  noteheadSlashVerticalEndsSmall: {
    codepoint: 'U+E105',
  },
  noteheadSlashWhiteDoubleWhole: {
    codepoint: 'U+E10A',
  },
  noteheadSlashWhiteHalf: {
    codepoint: 'U+E103',
  },
  noteheadSlashWhiteMuted: {
    codepoint: 'U+E109',
  },
  noteheadSlashWhiteWhole: {
    codepoint: 'U+E102',
  },
  noteheadSlashX: {
    codepoint: 'U+E106',
  },
  noteheadSlashedBlack1: {
    codepoint: 'U+E0CF',
  },
  noteheadSlashedBlack2: {
    codepoint: 'U+E0D0',
  },
  noteheadSlashedDoubleWhole1: {
    codepoint: 'U+E0D5',
  },
  noteheadSlashedDoubleWhole2: {
    codepoint: 'U+E0D6',
  },
  noteheadSlashedHalf1: {
    codepoint: 'U+E0D1',
  },
  noteheadSlashedHalf2: {
    codepoint: 'U+E0D2',
  },
  noteheadSlashedWhole1: {
    codepoint: 'U+E0D3',
  },
  noteheadSlashedWhole2: {
    codepoint: 'U+E0D4',
  },
  noteheadSquareBlack: {
    alternateCodepoint: 'U+1D147',
    codepoint: 'U+E0B9',
  },
  noteheadSquareBlackLarge: {
    codepoint: 'U+E11A',
  },
  noteheadSquareBlackWhite: {
    codepoint: 'U+E11B',
  },
  noteheadSquareWhite: {
    alternateCodepoint: 'U+1D146',
    codepoint: 'U+E0B8',
  },
  noteheadTriangleDownBlack: {
    alternateCodepoint: 'U+1D14F',
    codepoint: 'U+E0C7',
  },
  noteheadTriangleDownDoubleWhole: {
    codepoint: 'U+E0C3',
  },
  noteheadTriangleDownHalf: {
    codepoint: 'U+E0C5',
  },
  noteheadTriangleDownWhite: {
    alternateCodepoint: 'U+1D14E',
    codepoint: 'U+E0C6',
  },
  noteheadTriangleDownWhole: {
    codepoint: 'U+E0C4',
  },
  noteheadTriangleLeftBlack: {
    alternateCodepoint: 'U+1D14B',
    codepoint: 'U+E0C0',
  },
  noteheadTriangleLeftWhite: {
    alternateCodepoint: 'U+1D14A',
    codepoint: 'U+E0BF',
  },
  noteheadTriangleRightBlack: {
    alternateCodepoint: 'U+1D14D',
    codepoint: 'U+E0C2',
  },
  noteheadTriangleRightWhite: {
    alternateCodepoint: 'U+1D14C',
    codepoint: 'U+E0C1',
  },
  noteheadTriangleRoundDownBlack: {
    alternateCodepoint: 'U+1D155',
    codepoint: 'U+E0CD',
  },
  noteheadTriangleRoundDownWhite: {
    alternateCodepoint: 'U+1D154',
    codepoint: 'U+E0CC',
  },
  noteheadTriangleUpBlack: {
    alternateCodepoint: 'U+1D149',
    codepoint: 'U+E0BE',
  },
  noteheadTriangleUpDoubleWhole: {
    codepoint: 'U+E0BA',
  },
  noteheadTriangleUpHalf: {
    codepoint: 'U+E0BC',
  },
  noteheadTriangleUpRightBlack: {
    alternateCodepoint: 'U+1D151',
    codepoint: 'U+E0C9',
  },
  noteheadTriangleUpRightWhite: {
    alternateCodepoint: 'U+1D150',
    codepoint: 'U+E0C8',
  },
  noteheadTriangleUpWhite: {
    alternateCodepoint: 'U+1D148',
    codepoint: 'U+E0BD',
  },
  noteheadTriangleUpWhole: {
    codepoint: 'U+E0BB',
  },
  noteheadVoidWithX: {
    codepoint: 'U+E0B7',
  },
  noteheadWhole: {
    codepoint: 'U+E0A2',
  },
  noteheadWholeFilled: {
    codepoint: 'U+E0FA',
  },
  noteheadWholeWithX: {
    codepoint: 'U+E0B5',
  },
  noteheadXBlack: {
    alternateCodepoint: 'U+1D143',
    codepoint: 'U+E0A9',
  },
  noteheadXDoubleWhole: {
    codepoint: 'U+E0A6',
  },
  noteheadXHalf: {
    codepoint: 'U+E0A8',
  },
  noteheadXOrnate: {
    codepoint: 'U+E0AA',
  },
  noteheadXOrnateEllipse: {
    codepoint: 'U+E0AB',
  },
  noteheadXWhole: {
    codepoint: 'U+E0A7',
  },
  octaveBaselineA: {
    codepoint: 'U+EC91',
  },
  octaveBaselineB: {
    codepoint: 'U+EC93',
  },
  octaveBaselineM: {
    codepoint: 'U+EC95',
  },
  octaveBaselineV: {
    codepoint: 'U+EC97',
  },
  octaveBassa: {
    codepoint: 'U+E51F',
  },
  octaveLoco: {
    codepoint: 'U+EC90',
  },
  octaveParensLeft: {
    codepoint: 'U+E51A',
  },
  octaveParensRight: {
    codepoint: 'U+E51B',
  },
  octaveSuperscriptA: {
    codepoint: 'U+EC92',
  },
  octaveSuperscriptB: {
    codepoint: 'U+EC94',
  },
  octaveSuperscriptM: {
    codepoint: 'U+EC96',
  },
  octaveSuperscriptV: {
    codepoint: 'U+EC98',
  },
  oneHandedRollStevens: {
    codepoint: 'U+E233',
  },
  organGerman2Fusae: {
    codepoint: 'U+EE2E',
  },
  organGerman2Minimae: {
    codepoint: 'U+EE2C',
  },
  organGerman2OctaveUp: {
    codepoint: 'U+EE19',
  },
  organGerman2Semifusae: {
    codepoint: 'U+EE2F',
  },
  organGerman2Semiminimae: {
    codepoint: 'U+EE2D',
  },
  organGerman3Fusae: {
    codepoint: 'U+EE32',
  },
  organGerman3Minimae: {
    codepoint: 'U+EE30',
  },
  organGerman3Semifusae: {
    codepoint: 'U+EE33',
  },
  organGerman3Semiminimae: {
    codepoint: 'U+EE31',
  },
  organGerman4Fusae: {
    codepoint: 'U+EE36',
  },
  organGerman4Minimae: {
    codepoint: 'U+EE34',
  },
  organGerman4Semifusae: {
    codepoint: 'U+EE37',
  },
  organGerman4Semiminimae: {
    codepoint: 'U+EE35',
  },
  organGerman5Fusae: {
    codepoint: 'U+EE3A',
  },
  organGerman5Minimae: {
    codepoint: 'U+EE38',
  },
  organGerman5Semifusae: {
    codepoint: 'U+EE3B',
  },
  organGerman5Semiminimae: {
    codepoint: 'U+EE39',
  },
  organGerman6Fusae: {
    codepoint: 'U+EE3E',
  },
  organGerman6Minimae: {
    codepoint: 'U+EE3C',
  },
  organGerman6Semifusae: {
    codepoint: 'U+EE3F',
  },
  organGerman6Semiminimae: {
    codepoint: 'U+EE3D',
  },
  organGermanALower: {
    codepoint: 'U+EE15',
  },
  organGermanAUpper: {
    codepoint: 'U+EE09',
  },
  organGermanAugmentationDot: {
    codepoint: 'U+EE1C',
  },
  organGermanBLower: {
    codepoint: 'U+EE16',
  },
  organGermanBUpper: {
    codepoint: 'U+EE0A',
  },
  organGermanBuxheimerBrevis2: {
    codepoint: 'U+EE25',
  },
  organGermanBuxheimerBrevis3: {
    codepoint: 'U+EE24',
  },
  organGermanBuxheimerMinimaRest: {
    codepoint: 'U+EE1E',
  },
  organGermanBuxheimerSemibrevis: {
    codepoint: 'U+EE26',
  },
  organGermanBuxheimerSemibrevisRest: {
    codepoint: 'U+EE1D',
  },
  organGermanCLower: {
    codepoint: 'U+EE0C',
  },
  organGermanCUpper: {
    codepoint: 'U+EE00',
  },
  organGermanCisLower: {
    codepoint: 'U+EE0D',
  },
  organGermanCisUpper: {
    codepoint: 'U+EE01',
  },
  organGermanDLower: {
    codepoint: 'U+EE0E',
  },
  organGermanDUpper: {
    codepoint: 'U+EE02',
  },
  organGermanDisLower: {
    codepoint: 'U+EE0F',
  },
  organGermanDisUpper: {
    codepoint: 'U+EE03',
  },
  organGermanELower: {
    codepoint: 'U+EE10',
  },
  organGermanEUpper: {
    codepoint: 'U+EE04',
  },
  organGermanFLower: {
    codepoint: 'U+EE11',
  },
  organGermanFUpper: {
    codepoint: 'U+EE05',
  },
  organGermanFisLower: {
    codepoint: 'U+EE12',
  },
  organGermanFisUpper: {
    codepoint: 'U+EE06',
  },
  organGermanFusa: {
    codepoint: 'U+EE2A',
  },
  organGermanFusaRest: {
    codepoint: 'U+EE22',
  },
  organGermanGLower: {
    codepoint: 'U+EE13',
  },
  organGermanGUpper: {
    codepoint: 'U+EE07',
  },
  organGermanGisLower: {
    codepoint: 'U+EE14',
  },
  organGermanGisUpper: {
    codepoint: 'U+EE08',
  },
  organGermanHLower: {
    codepoint: 'U+EE17',
  },
  organGermanHUpper: {
    codepoint: 'U+EE0B',
  },
  organGermanMinima: {
    codepoint: 'U+EE28',
  },
  organGermanMinimaRest: {
    codepoint: 'U+EE20',
  },
  organGermanOctaveDown: {
    codepoint: 'U+EE1A',
  },
  organGermanOctaveUp: {
    codepoint: 'U+EE18',
  },
  organGermanSemibrevis: {
    codepoint: 'U+EE27',
  },
  organGermanSemibrevisRest: {
    codepoint: 'U+EE1F',
  },
  organGermanSemifusa: {
    codepoint: 'U+EE2B',
  },
  organGermanSemifusaRest: {
    codepoint: 'U+EE23',
  },
  organGermanSemiminima: {
    codepoint: 'U+EE29',
  },
  organGermanSemiminimaRest: {
    codepoint: 'U+EE21',
  },
  organGermanTie: {
    codepoint: 'U+EE1B',
  },
  ornamentBottomLeftConcaveStroke: {
    codepoint: 'U+E59A',
  },
  ornamentBottomLeftConcaveStrokeLarge: {
    alternateCodepoint: 'U+1D1A1',
    codepoint: 'U+E59B',
  },
  ornamentBottomLeftConvexStroke: {
    codepoint: 'U+E59C',
  },
  ornamentBottomRightConcaveStroke: {
    alternateCodepoint: 'U+1D19F',
    codepoint: 'U+E5A7',
  },
  ornamentBottomRightConvexStroke: {
    codepoint: 'U+E5A8',
  },
  ornamentComma: {
    codepoint: 'U+E581',
  },
  ornamentDoubleObliqueLinesAfterNote: {
    codepoint: 'U+E57E',
  },
  ornamentDoubleObliqueLinesBeforeNote: {
    codepoint: 'U+E57D',
  },
  ornamentDownCurve: {
    codepoint: 'U+E578',
  },
  ornamentHaydn: {
    codepoint: 'U+E56F',
  },
  ornamentHighLeftConcaveStroke: {
    codepoint: 'U+E592',
  },
  ornamentHighLeftConvexStroke: {
    alternateCodepoint: 'U+1D1A2',
    codepoint: 'U+E593',
  },
  ornamentHighRightConcaveStroke: {
    codepoint: 'U+E5A2',
  },
  ornamentHighRightConvexStroke: {
    codepoint: 'U+E5A3',
  },
  ornamentHookAfterNote: {
    codepoint: 'U+E576',
  },
  ornamentHookBeforeNote: {
    codepoint: 'U+E575',
  },
  ornamentLeftFacingHalfCircle: {
    codepoint: 'U+E572',
  },
  ornamentLeftFacingHook: {
    codepoint: 'U+E574',
  },
  ornamentLeftPlus: {
    codepoint: 'U+E597',
  },
  ornamentLeftShakeT: {
    codepoint: 'U+E596',
  },
  ornamentLeftVerticalStroke: {
    alternateCodepoint: 'U+1D19B',
    codepoint: 'U+E594',
  },
  ornamentLeftVerticalStrokeWithCross: {
    codepoint: 'U+E595',
  },
  ornamentLowLeftConcaveStroke: {
    codepoint: 'U+E598',
  },
  ornamentLowLeftConvexStroke: {
    alternateCodepoint: 'U+1D1A4',
    codepoint: 'U+E599',
  },
  ornamentLowRightConcaveStroke: {
    alternateCodepoint: 'U+1D1A3',
    codepoint: 'U+E5A5',
  },
  ornamentLowRightConvexStroke: {
    codepoint: 'U+E5A6',
  },
  ornamentMiddleVerticalStroke: {
    alternateCodepoint: 'U+1D1A0',
    codepoint: 'U+E59F',
  },
  ornamentMordent: {
    codepoint: 'U+E56D',
  },
  ornamentObliqueLineAfterNote: {
    codepoint: 'U+E57C',
  },
  ornamentObliqueLineBeforeNote: {
    codepoint: 'U+E57B',
  },
  ornamentObliqueLineHorizAfterNote: {
    codepoint: 'U+E580',
  },
  ornamentObliqueLineHorizBeforeNote: {
    codepoint: 'U+E57F',
  },
  ornamentOriscus: {
    codepoint: 'U+EA21',
  },
  ornamentPinceCouperin: {
    codepoint: 'U+E588',
  },
  ornamentPortDeVoixV: {
    codepoint: 'U+E570',
  },
  ornamentPrecompAppoggTrill: {
    codepoint: 'U+E5B2',
  },
  ornamentPrecompAppoggTrillSuffix: {
    codepoint: 'U+E5B3',
  },
  ornamentPrecompCadence: {
    codepoint: 'U+E5BE',
  },
  ornamentPrecompCadenceUpperPrefix: {
    codepoint: 'U+E5C1',
  },
  ornamentPrecompCadenceUpperPrefixTurn: {
    codepoint: 'U+E5C2',
  },
  ornamentPrecompCadenceWithTurn: {
    codepoint: 'U+E5BF',
  },
  ornamentPrecompDescendingSlide: {
    codepoint: 'U+E5B1',
  },
  ornamentPrecompDoubleCadenceLowerPrefix: {
    codepoint: 'U+E5C0',
  },
  ornamentPrecompDoubleCadenceUpperPrefix: {
    codepoint: 'U+E5C3',
  },
  ornamentPrecompDoubleCadenceUpperPrefixTurn: {
    codepoint: 'U+E5C4',
  },
  ornamentPrecompInvertedMordentUpperPrefix: {
    codepoint: 'U+E5C7',
  },
  ornamentPrecompMordentRelease: {
    codepoint: 'U+E5C5',
  },
  ornamentPrecompMordentUpperPrefix: {
    codepoint: 'U+E5C6',
  },
  ornamentPrecompPortDeVoixMordent: {
    codepoint: 'U+E5BC',
  },
  ornamentPrecompSlide: {
    codepoint: 'U+E5B0',
  },
  ornamentPrecompSlideTrillBach: {
    codepoint: 'U+E5B8',
  },
  ornamentPrecompSlideTrillDAnglebert: {
    codepoint: 'U+E5B5',
  },
  ornamentPrecompSlideTrillMarpurg: {
    codepoint: 'U+E5B6',
  },
  ornamentPrecompSlideTrillMuffat: {
    codepoint: 'U+E5B9',
  },
  ornamentPrecompSlideTrillSuffixMuffat: {
    codepoint: 'U+E5BA',
  },
  ornamentPrecompTrillLowerSuffix: {
    codepoint: 'U+E5C8',
  },
  ornamentPrecompTrillSuffixDandrieu: {
    codepoint: 'U+E5BB',
  },
  ornamentPrecompTrillWithMordent: {
    codepoint: 'U+E5BD',
  },
  ornamentPrecompTurnTrillBach: {
    codepoint: 'U+E5B7',
  },
  ornamentPrecompTurnTrillDAnglebert: {
    codepoint: 'U+E5B4',
  },
  ornamentQuilisma: {
    codepoint: 'U+EA20',
  },
  ornamentRightFacingHalfCircle: {
    codepoint: 'U+E571',
  },
  ornamentRightFacingHook: {
    codepoint: 'U+E573',
  },
  ornamentRightVerticalStroke: {
    codepoint: 'U+E5A4',
  },
  ornamentSchleifer: {
    codepoint: 'U+E587',
  },
  ornamentShake3: {
    codepoint: 'U+E582',
  },
  ornamentShakeMuffat1: {
    codepoint: 'U+E584',
  },
  ornamentShortObliqueLineAfterNote: {
    codepoint: 'U+E57A',
  },
  ornamentShortObliqueLineBeforeNote: {
    codepoint: 'U+E579',
  },
  ornamentShortTrill: {
    codepoint: 'U+E56C',
  },
  ornamentTopLeftConcaveStroke: {
    codepoint: 'U+E590',
  },
  ornamentTopLeftConvexStroke: {
    alternateCodepoint: 'U+1D1A5',
    codepoint: 'U+E591',
  },
  ornamentTopRightConcaveStroke: {
    codepoint: 'U+E5A0',
  },
  ornamentTopRightConvexStroke: {
    alternateCodepoint: 'U+1D19E',
    codepoint: 'U+E5A1',
  },
  ornamentTremblement: {
    codepoint: 'U+E56E',
  },
  ornamentTremblementCouperin: {
    codepoint: 'U+E589',
  },
  ornamentTrill: {
    alternateCodepoint: 'U+1D196',
    codepoint: 'U+E566',
  },
  ornamentTurn: {
    alternateCodepoint: 'U+1D197',
    codepoint: 'U+E567',
  },
  ornamentTurnInverted: {
    alternateCodepoint: 'U+1D198',
    codepoint: 'U+E568',
  },
  ornamentTurnSlash: {
    alternateCodepoint: 'U+1D199',
    codepoint: 'U+E569',
  },
  ornamentTurnUp: {
    alternateCodepoint: 'U+1D19A',
    codepoint: 'U+E56A',
  },
  ornamentTurnUpS: {
    codepoint: 'U+E56B',
  },
  ornamentUpCurve: {
    codepoint: 'U+E577',
  },
  ornamentVerticalLine: {
    codepoint: 'U+E583',
  },
  ornamentZigZagLineNoRightEnd: {
    alternateCodepoint: 'U+1D19C',
    codepoint: 'U+E59D',
  },
  ornamentZigZagLineWithRightEnd: {
    alternateCodepoint: 'U+1D19D',
    codepoint: 'U+E59E',
  },
  ottava: {
    codepoint: 'U+E510',
  },
  ottavaAlta: {
    alternateCodepoint: 'U+1D136',
    codepoint: 'U+E511',
  },
  ottavaBassa: {
    alternateCodepoint: 'U+1D137',
    codepoint: 'U+E512',
  },
  ottavaBassaBa: {
    codepoint: 'U+E513',
  },
  ottavaBassaVb: {
    codepoint: 'U+E51C',
  },
  pendereckiTremolo: {
    codepoint: 'U+E22B',
  },
  pictAgogo: {
    codepoint: 'U+E717',
  },
  pictAlmglocken: {
    codepoint: 'U+E712',
  },
  pictAnvil: {
    codepoint: 'U+E701',
  },
  pictBambooChimes: {
    codepoint: 'U+E6C3',
  },
  pictBambooScraper: {
    codepoint: 'U+E6FB',
  },
  pictBassDrum: {
    codepoint: 'U+E6D4',
  },
  pictBassDrumOnSide: {
    codepoint: 'U+E6D5',
  },
  pictBeaterBow: {
    codepoint: 'U+E7DE',
  },
  pictBeaterBox: {
    codepoint: 'U+E7EB',
  },
  pictBeaterBrassMalletsDown: {
    codepoint: 'U+E7DA',
  },
  pictBeaterBrassMalletsLeft: {
    codepoint: 'U+E7EE',
  },
  pictBeaterBrassMalletsRight: {
    codepoint: 'U+E7ED',
  },
  pictBeaterBrassMalletsUp: {
    codepoint: 'U+E7D9',
  },
  pictBeaterCombiningDashedCircle: {
    codepoint: 'U+E7EA',
  },
  pictBeaterCombiningParentheses: {
    codepoint: 'U+E7E9',
  },
  pictBeaterDoubleBassDrumDown: {
    codepoint: 'U+E7A1',
  },
  pictBeaterDoubleBassDrumUp: {
    codepoint: 'U+E7A0',
  },
  pictBeaterFinger: {
    codepoint: 'U+E7E4',
  },
  pictBeaterFingernails: {
    codepoint: 'U+E7E6',
  },
  pictBeaterFist: {
    codepoint: 'U+E7E5',
  },
  pictBeaterGuiroScraper: {
    codepoint: 'U+E7DD',
  },
  pictBeaterHammer: {
    codepoint: 'U+E7E1',
  },
  pictBeaterHammerMetalDown: {
    codepoint: 'U+E7D0',
  },
  pictBeaterHammerMetalUp: {
    codepoint: 'U+E7CF',
  },
  pictBeaterHammerPlasticDown: {
    codepoint: 'U+E7CE',
  },
  pictBeaterHammerPlasticUp: {
    codepoint: 'U+E7CD',
  },
  pictBeaterHammerWoodDown: {
    codepoint: 'U+E7CC',
  },
  pictBeaterHammerWoodUp: {
    codepoint: 'U+E7CB',
  },
  pictBeaterHand: {
    codepoint: 'U+E7E3',
  },
  pictBeaterHardBassDrumDown: {
    codepoint: 'U+E79D',
  },
  pictBeaterHardBassDrumUp: {
    codepoint: 'U+E79C',
  },
  pictBeaterHardGlockenspielDown: {
    codepoint: 'U+E785',
  },
  pictBeaterHardGlockenspielLeft: {
    codepoint: 'U+E787',
  },
  pictBeaterHardGlockenspielRight: {
    codepoint: 'U+E786',
  },
  pictBeaterHardGlockenspielUp: {
    codepoint: 'U+E784',
  },
  pictBeaterHardTimpaniDown: {
    codepoint: 'U+E791',
  },
  pictBeaterHardTimpaniLeft: {
    codepoint: 'U+E793',
  },
  pictBeaterHardTimpaniRight: {
    codepoint: 'U+E792',
  },
  pictBeaterHardTimpaniUp: {
    codepoint: 'U+E790',
  },
  pictBeaterHardXylophoneDown: {
    codepoint: 'U+E779',
  },
  pictBeaterHardXylophoneLeft: {
    codepoint: 'U+E77B',
  },
  pictBeaterHardXylophoneRight: {
    codepoint: 'U+E77A',
  },
  pictBeaterHardXylophoneUp: {
    codepoint: 'U+E778',
  },
  pictBeaterHardYarnDown: {
    codepoint: 'U+E7AB',
  },
  pictBeaterHardYarnLeft: {
    codepoint: 'U+E7AD',
  },
  pictBeaterHardYarnRight: {
    codepoint: 'U+E7AC',
  },
  pictBeaterHardYarnUp: {
    codepoint: 'U+E7AA',
  },
  pictBeaterJazzSticksDown: {
    codepoint: 'U+E7D4',
  },
  pictBeaterJazzSticksUp: {
    codepoint: 'U+E7D3',
  },
  pictBeaterKnittingNeedle: {
    codepoint: 'U+E7E2',
  },
  pictBeaterMallet: {
    codepoint: 'U+E7DF',
  },
  pictBeaterMalletDown: {
    codepoint: 'U+E7EC',
  },
  pictBeaterMediumBassDrumDown: {
    codepoint: 'U+E79B',
  },
  pictBeaterMediumBassDrumUp: {
    codepoint: 'U+E79A',
  },
  pictBeaterMediumTimpaniDown: {
    codepoint: 'U+E78D',
  },
  pictBeaterMediumTimpaniLeft: {
    codepoint: 'U+E78F',
  },
  pictBeaterMediumTimpaniRight: {
    codepoint: 'U+E78E',
  },
  pictBeaterMediumTimpaniUp: {
    codepoint: 'U+E78C',
  },
  pictBeaterMediumXylophoneDown: {
    codepoint: 'U+E775',
  },
  pictBeaterMediumXylophoneLeft: {
    codepoint: 'U+E777',
  },
  pictBeaterMediumXylophoneRight: {
    codepoint: 'U+E776',
  },
  pictBeaterMediumXylophoneUp: {
    codepoint: 'U+E774',
  },
  pictBeaterMediumYarnDown: {
    codepoint: 'U+E7A7',
  },
  pictBeaterMediumYarnLeft: {
    codepoint: 'U+E7A9',
  },
  pictBeaterMediumYarnRight: {
    codepoint: 'U+E7A8',
  },
  pictBeaterMediumYarnUp: {
    codepoint: 'U+E7A6',
  },
  pictBeaterMetalBassDrumDown: {
    codepoint: 'U+E79F',
  },
  pictBeaterMetalBassDrumUp: {
    codepoint: 'U+E79E',
  },
  pictBeaterMetalDown: {
    codepoint: 'U+E7C8',
  },
  pictBeaterMetalHammer: {
    codepoint: 'U+E7E0',
  },
  pictBeaterMetalLeft: {
    codepoint: 'U+E7CA',
  },
  pictBeaterMetalRight: {
    codepoint: 'U+E7C9',
  },
  pictBeaterMetalUp: {
    codepoint: 'U+E7C7',
  },
  pictBeaterSnareSticksDown: {
    codepoint: 'U+E7D2',
  },
  pictBeaterSnareSticksUp: {
    codepoint: 'U+E7D1',
  },
  pictBeaterSoftBassDrumDown: {
    codepoint: 'U+E799',
  },
  pictBeaterSoftBassDrumUp: {
    codepoint: 'U+E798',
  },
  pictBeaterSoftGlockenspielDown: {
    codepoint: 'U+E781',
  },
  pictBeaterSoftGlockenspielLeft: {
    codepoint: 'U+E783',
  },
  pictBeaterSoftGlockenspielRight: {
    codepoint: 'U+E782',
  },
  pictBeaterSoftGlockenspielUp: {
    codepoint: 'U+E780',
  },
  pictBeaterSoftTimpaniDown: {
    codepoint: 'U+E789',
  },
  pictBeaterSoftTimpaniLeft: {
    codepoint: 'U+E78B',
  },
  pictBeaterSoftTimpaniRight: {
    codepoint: 'U+E78A',
  },
  pictBeaterSoftTimpaniUp: {
    codepoint: 'U+E788',
  },
  pictBeaterSoftXylophone: {
    codepoint: 'U+E7DB',
  },
  pictBeaterSoftXylophoneDown: {
    codepoint: 'U+E771',
  },
  pictBeaterSoftXylophoneLeft: {
    codepoint: 'U+E773',
  },
  pictBeaterSoftXylophoneRight: {
    codepoint: 'U+E772',
  },
  pictBeaterSoftXylophoneUp: {
    codepoint: 'U+E770',
  },
  pictBeaterSoftYarnDown: {
    codepoint: 'U+E7A3',
  },
  pictBeaterSoftYarnLeft: {
    codepoint: 'U+E7A5',
  },
  pictBeaterSoftYarnRight: {
    codepoint: 'U+E7A4',
  },
  pictBeaterSoftYarnUp: {
    codepoint: 'U+E7A2',
  },
  pictBeaterSpoonWoodenMallet: {
    codepoint: 'U+E7DC',
  },
  pictBeaterSuperballDown: {
    codepoint: 'U+E7AF',
  },
  pictBeaterSuperballLeft: {
    codepoint: 'U+E7B1',
  },
  pictBeaterSuperballRight: {
    codepoint: 'U+E7B0',
  },
  pictBeaterSuperballUp: {
    codepoint: 'U+E7AE',
  },
  pictBeaterTriangleDown: {
    codepoint: 'U+E7D6',
  },
  pictBeaterTrianglePlain: {
    codepoint: 'U+E7EF',
  },
  pictBeaterTriangleUp: {
    codepoint: 'U+E7D5',
  },
  pictBeaterWireBrushesDown: {
    codepoint: 'U+E7D8',
  },
  pictBeaterWireBrushesUp: {
    codepoint: 'U+E7D7',
  },
  pictBeaterWoodTimpaniDown: {
    codepoint: 'U+E795',
  },
  pictBeaterWoodTimpaniLeft: {
    codepoint: 'U+E797',
  },
  pictBeaterWoodTimpaniRight: {
    codepoint: 'U+E796',
  },
  pictBeaterWoodTimpaniUp: {
    codepoint: 'U+E794',
  },
  pictBeaterWoodXylophoneDown: {
    codepoint: 'U+E77D',
  },
  pictBeaterWoodXylophoneLeft: {
    codepoint: 'U+E77F',
  },
  pictBeaterWoodXylophoneRight: {
    codepoint: 'U+E77E',
  },
  pictBeaterWoodXylophoneUp: {
    codepoint: 'U+E77C',
  },
  pictBell: {
    codepoint: 'U+E714',
  },
  pictBellOfCymbal: {
    codepoint: 'U+E72A',
  },
  pictBellPlate: {
    codepoint: 'U+E713',
  },
  pictBellTree: {
    codepoint: 'U+E71A',
  },
  pictBirdWhistle: {
    codepoint: 'U+E751',
  },
  pictBoardClapper: {
    codepoint: 'U+E6F7',
  },
  pictBongos: {
    codepoint: 'U+E6DD',
  },
  pictBrakeDrum: {
    codepoint: 'U+E6E1',
  },
  pictCabasa: {
    codepoint: 'U+E743',
  },
  pictCannon: {
    codepoint: 'U+E761',
  },
  pictCarHorn: {
    codepoint: 'U+E755',
  },
  pictCastanets: {
    codepoint: 'U+E6F8',
  },
  pictCastanetsWithHandle: {
    codepoint: 'U+E6F9',
  },
  pictCelesta: {
    codepoint: 'U+E6B0',
  },
  pictCencerro: {
    codepoint: 'U+E716',
  },
  pictCenter1: {
    codepoint: 'U+E7FE',
  },
  pictCenter2: {
    codepoint: 'U+E7FF',
  },
  pictCenter3: {
    codepoint: 'U+E800',
  },
  pictChainRattle: {
    codepoint: 'U+E748',
  },
  pictChimes: {
    codepoint: 'U+E6C2',
  },
  pictChineseCymbal: {
    codepoint: 'U+E726',
  },
  pictChokeCymbal: {
    codepoint: 'U+E805',
  },
  pictClaves: {
    codepoint: 'U+E6F2',
  },
  pictCoins: {
    codepoint: 'U+E7E7',
  },
  pictConga: {
    codepoint: 'U+E6DE',
  },
  pictCowBell: {
    codepoint: 'U+E711',
  },
  pictCrashCymbals: {
    codepoint: 'U+E720',
  },
  pictCrotales: {
    codepoint: 'U+E6AE',
  },
  pictCrushStem: {
    codepoint: 'U+E80C',
  },
  pictCuica: {
    codepoint: 'U+E6E4',
  },
  pictCymbalTongs: {
    codepoint: 'U+E728',
  },
  pictDamp1: {
    codepoint: 'U+E7F9',
  },
  pictDamp2: {
    codepoint: 'U+E7FA',
  },
  pictDamp3: {
    codepoint: 'U+E7FB',
  },
  pictDamp4: {
    codepoint: 'U+E7FC',
  },
  pictDeadNoteStem: {
    codepoint: 'U+E80D',
  },
  pictDrumStick: {
    codepoint: 'U+E7E8',
  },
  pictDuckCall: {
    codepoint: 'U+E757',
  },
  pictEdgeOfCymbal: {
    codepoint: 'U+E729',
  },
  pictEmptyTrap: {
    codepoint: 'U+E6A9',
  },
  pictFingerCymbals: {
    codepoint: 'U+E727',
  },
  pictFlexatone: {
    codepoint: 'U+E740',
  },
  pictFootballRatchet: {
    codepoint: 'U+E6F5',
  },
  pictGlassHarmonica: {
    codepoint: 'U+E765',
  },
  pictGlassHarp: {
    codepoint: 'U+E764',
  },
  pictGlassPlateChimes: {
    codepoint: 'U+E6C6',
  },
  pictGlassTubeChimes: {
    codepoint: 'U+E6C5',
  },
  pictGlsp: {
    codepoint: 'U+E6A0',
  },
  pictGlspSmithBrindle: {
    codepoint: 'U+E6AA',
  },
  pictGobletDrum: {
    codepoint: 'U+E6E2',
  },
  pictGong: {
    codepoint: 'U+E732',
  },
  pictGongWithButton: {
    codepoint: 'U+E733',
  },
  pictGuiro: {
    codepoint: 'U+E6F3',
  },
  pictGumHardDown: {
    codepoint: 'U+E7C4',
  },
  pictGumHardLeft: {
    codepoint: 'U+E7C6',
  },
  pictGumHardRight: {
    codepoint: 'U+E7C5',
  },
  pictGumHardUp: {
    codepoint: 'U+E7C3',
  },
  pictGumMediumDown: {
    codepoint: 'U+E7C0',
  },
  pictGumMediumLeft: {
    codepoint: 'U+E7C2',
  },
  pictGumMediumRight: {
    codepoint: 'U+E7C1',
  },
  pictGumMediumUp: {
    codepoint: 'U+E7BF',
  },
  pictGumSoftDown: {
    codepoint: 'U+E7BC',
  },
  pictGumSoftLeft: {
    codepoint: 'U+E7BE',
  },
  pictGumSoftRight: {
    codepoint: 'U+E7BD',
  },
  pictGumSoftUp: {
    codepoint: 'U+E7BB',
  },
  pictHalfOpen1: {
    codepoint: 'U+E7F6',
  },
  pictHalfOpen2: {
    codepoint: 'U+E7F7',
  },
  pictHandbell: {
    codepoint: 'U+E715',
  },
  pictHiHat: {
    codepoint: 'U+E722',
  },
  pictHiHatOnStand: {
    codepoint: 'U+E723',
  },
  pictJawHarp: {
    codepoint: 'U+E767',
  },
  pictJingleBells: {
    codepoint: 'U+E719',
  },
  pictKlaxonHorn: {
    codepoint: 'U+E756',
  },
  pictLeftHandCircle: {
    codepoint: 'U+E807',
  },
  pictLionsRoar: {
    codepoint: 'U+E763',
  },
  pictLithophone: {
    codepoint: 'U+E6B1',
  },
  pictLogDrum: {
    codepoint: 'U+E6DF',
  },
  pictLotusFlute: {
    codepoint: 'U+E75A',
  },
  pictMar: {
    codepoint: 'U+E6A6',
  },
  pictMarSmithBrindle: {
    codepoint: 'U+E6AC',
  },
  pictMaraca: {
    codepoint: 'U+E741',
  },
  pictMaracas: {
    codepoint: 'U+E742',
  },
  pictMegaphone: {
    codepoint: 'U+E759',
  },
  pictMetalPlateChimes: {
    codepoint: 'U+E6C8',
  },
  pictMetalTubeChimes: {
    codepoint: 'U+E6C7',
  },
  pictMusicalSaw: {
    codepoint: 'U+E766',
  },
  pictNormalPosition: {
    codepoint: 'U+E804',
  },
  pictOnRim: {
    codepoint: 'U+E7F4',
  },
  pictOpen: {
    codepoint: 'U+E7F8',
  },
  pictOpenRimShot: {
    codepoint: 'U+E7F5',
  },
  pictPistolShot: {
    codepoint: 'U+E760',
  },
  pictPoliceWhistle: {
    codepoint: 'U+E752',
  },
  pictQuijada: {
    codepoint: 'U+E6FA',
  },
  pictRainstick: {
    codepoint: 'U+E747',
  },
  pictRatchet: {
    codepoint: 'U+E6F4',
  },
  pictRecoReco: {
    codepoint: 'U+E6FC',
  },
  pictRightHandSquare: {
    codepoint: 'U+E806',
  },
  pictRim1: {
    codepoint: 'U+E801',
  },
  pictRim2: {
    codepoint: 'U+E802',
  },
  pictRim3: {
    codepoint: 'U+E803',
  },
  pictRimShotOnStem: {
    codepoint: 'U+E7FD',
  },
  pictSandpaperBlocks: {
    codepoint: 'U+E762',
  },
  pictScrapeAroundRim: {
    codepoint: 'U+E7F3',
  },
  pictScrapeAroundRimClockwise: {
    codepoint: 'U+E80E',
  },
  pictScrapeCenterToEdge: {
    codepoint: 'U+E7F1',
  },
  pictScrapeEdgeToCenter: {
    codepoint: 'U+E7F2',
  },
  pictShellBells: {
    codepoint: 'U+E718',
  },
  pictShellChimes: {
    codepoint: 'U+E6C4',
  },
  pictSiren: {
    codepoint: 'U+E753',
  },
  pictSistrum: {
    codepoint: 'U+E746',
  },
  pictSizzleCymbal: {
    codepoint: 'U+E724',
  },
  pictSleighBell: {
    codepoint: 'U+E710',
  },
  pictSlideBrushOnGong: {
    codepoint: 'U+E734',
  },
  pictSlideWhistle: {
    codepoint: 'U+E750',
  },
  pictSlitDrum: {
    codepoint: 'U+E6E0',
  },
  pictSnareDrum: {
    codepoint: 'U+E6D1',
  },
  pictSnareDrumMilitary: {
    codepoint: 'U+E6D3',
  },
  pictSnareDrumSnaresOff: {
    codepoint: 'U+E6D2',
  },
  pictSteelDrums: {
    codepoint: 'U+E6AF',
  },
  pictStickShot: {
    codepoint: 'U+E7F0',
  },
  pictSuperball: {
    codepoint: 'U+E7B2',
  },
  pictSuspendedCymbal: {
    codepoint: 'U+E721',
  },
  pictSwishStem: {
    codepoint: 'U+E808',
  },
  pictTabla: {
    codepoint: 'U+E6E3',
  },
  pictTamTam: {
    codepoint: 'U+E730',
  },
  pictTamTamWithBeater: {
    codepoint: 'U+E731',
  },
  pictTambourine: {
    codepoint: 'U+E6DB',
  },
  pictTempleBlocks: {
    codepoint: 'U+E6F1',
  },
  pictTenorDrum: {
    codepoint: 'U+E6D6',
  },
  pictThundersheet: {
    codepoint: 'U+E744',
  },
  pictTimbales: {
    codepoint: 'U+E6DC',
  },
  pictTimpani: {
    codepoint: 'U+E6D0',
  },
  pictTomTom: {
    codepoint: 'U+E6D7',
  },
  pictTomTomChinese: {
    codepoint: 'U+E6D8',
  },
  pictTomTomIndoAmerican: {
    codepoint: 'U+E6DA',
  },
  pictTomTomJapanese: {
    codepoint: 'U+E6D9',
  },
  pictTriangle: {
    codepoint: 'U+E700',
  },
  pictTubaphone: {
    codepoint: 'U+E6B2',
  },
  pictTubularBells: {
    codepoint: 'U+E6C0',
  },
  pictTurnLeftStem: {
    codepoint: 'U+E80A',
  },
  pictTurnRightLeftStem: {
    codepoint: 'U+E80B',
  },
  pictTurnRightStem: {
    codepoint: 'U+E809',
  },
  pictVib: {
    codepoint: 'U+E6A7',
  },
  pictVibMotorOff: {
    codepoint: 'U+E6A8',
  },
  pictVibSmithBrindle: {
    codepoint: 'U+E6AD',
  },
  pictVibraslap: {
    codepoint: 'U+E745',
  },
  pictVietnameseHat: {
    codepoint: 'U+E725',
  },
  pictWhip: {
    codepoint: 'U+E6F6',
  },
  pictWindChimesGlass: {
    codepoint: 'U+E6C1',
  },
  pictWindMachine: {
    codepoint: 'U+E754',
  },
  pictWindWhistle: {
    codepoint: 'U+E758',
  },
  pictWoodBlock: {
    codepoint: 'U+E6F0',
  },
  pictWoundHardDown: {
    codepoint: 'U+E7B4',
  },
  pictWoundHardLeft: {
    codepoint: 'U+E7B6',
  },
  pictWoundHardRight: {
    codepoint: 'U+E7B5',
  },
  pictWoundHardUp: {
    codepoint: 'U+E7B3',
  },
  pictWoundSoftDown: {
    codepoint: 'U+E7B8',
  },
  pictWoundSoftLeft: {
    codepoint: 'U+E7BA',
  },
  pictWoundSoftRight: {
    codepoint: 'U+E7B9',
  },
  pictWoundSoftUp: {
    codepoint: 'U+E7B7',
  },
  pictXyl: {
    codepoint: 'U+E6A1',
  },
  pictXylBass: {
    codepoint: 'U+E6A3',
  },
  pictXylSmithBrindle: {
    codepoint: 'U+E6AB',
  },
  pictXylTenor: {
    codepoint: 'U+E6A2',
  },
  pictXylTenorTrough: {
    codepoint: 'U+E6A5',
  },
  pictXylTrough: {
    codepoint: 'U+E6A4',
  },
  pluckedBuzzPizzicato: {
    codepoint: 'U+E632',
  },
  pluckedDamp: {
    alternateCodepoint: 'U+1D1B4',
    codepoint: 'U+E638',
  },
  pluckedDampAll: {
    alternateCodepoint: 'U+1D1B5',
    codepoint: 'U+E639',
  },
  pluckedDampOnStem: {
    codepoint: 'U+E63B',
  },
  pluckedFingernailFlick: {
    codepoint: 'U+E637',
  },
  pluckedLeftHandPizzicato: {
    codepoint: 'U+E633',
  },
  pluckedPlectrum: {
    codepoint: 'U+E63A',
  },
  pluckedSnapPizzicatoAbove: {
    codepoint: 'U+E631',
  },
  pluckedSnapPizzicatoBelow: {
    alternateCodepoint: 'U+1D1AD',
    codepoint: 'U+E630',
  },
  pluckedWithFingernails: {
    alternateCodepoint: 'U+1D1B3',
    codepoint: 'U+E636',
  },
  quindicesima: {
    codepoint: 'U+E514',
  },
  quindicesimaAlta: {
    codepoint: 'U+E515',
  },
  quindicesimaBassa: {
    alternateCodepoint: 'U+1D139',
    codepoint: 'U+E516',
  },
  quindicesimaBassaMb: {
    codepoint: 'U+E51D',
  },
  repeat1Bar: {
    alternateCodepoint: 'U+1D10E',
    codepoint: 'U+E500',
  },
  repeat2Bars: {
    alternateCodepoint: 'U+1D10F',
    codepoint: 'U+E501',
  },
  repeat4Bars: {
    codepoint: 'U+E502',
  },
  repeatBarLowerDot: {
    codepoint: 'U+E505',
  },
  repeatBarSlash: {
    codepoint: 'U+E504',
  },
  repeatBarUpperDot: {
    codepoint: 'U+E503',
  },
  repeatDot: {
    codepoint: 'U+E044',
  },
  repeatDots: {
    alternateCodepoint: 'U+1D108',
    codepoint: 'U+E043',
  },
  repeatLeft: {
    alternateCodepoint: 'U+1D106',
    codepoint: 'U+E040',
  },
  repeatRight: {
    alternateCodepoint: 'U+1D107',
    codepoint: 'U+E041',
  },
  repeatRightLeft: {
    codepoint: 'U+E042',
  },
  rest1024th: {
    codepoint: 'U+E4ED',
  },
  rest128th: {
    alternateCodepoint: 'U+1D142',
    codepoint: 'U+E4EA',
  },
  rest16th: {
    alternateCodepoint: 'U+1D13F',
    codepoint: 'U+E4E7',
  },
  rest256th: {
    codepoint: 'U+E4EB',
  },
  rest32nd: {
    alternateCodepoint: 'U+1D140',
    codepoint: 'U+E4E8',
  },
  rest512th: {
    codepoint: 'U+E4EC',
  },
  rest64th: {
    alternateCodepoint: 'U+1D141',
    codepoint: 'U+E4E9',
  },
  rest8th: {
    alternateCodepoint: 'U+1D13E',
    codepoint: 'U+E4E6',
  },
  restDoubleWhole: {
    alternateCodepoint: 'U+1D13A',
    codepoint: 'U+E4E2',
  },
  restDoubleWholeLegerLine: {
    codepoint: 'U+E4F3',
  },
  restHBar: {
    alternateCodepoint: 'U+1D129',
    codepoint: 'U+E4EE',
  },
  restHBarLeft: {
    codepoint: 'U+E4EF',
  },
  restHBarMiddle: {
    codepoint: 'U+E4F0',
  },
  restHBarRight: {
    codepoint: 'U+E4F1',
  },
  restHalf: {
    alternateCodepoint: 'U+1D13C',
    codepoint: 'U+E4E4',
  },
  restHalfLegerLine: {
    codepoint: 'U+E4F5',
  },
  restLonga: {
    codepoint: 'U+E4E1',
  },
  restMaxima: {
    codepoint: 'U+E4E0',
  },
  restQuarter: {
    alternateCodepoint: 'U+1D13D',
    codepoint: 'U+E4E5',
  },
  restQuarterOld: {
    codepoint: 'U+E4F2',
  },
  restQuarterZ: {
    codepoint: 'U+E4F6',
  },
  restWhole: {
    alternateCodepoint: 'U+1D13B',
    codepoint: 'U+E4E3',
  },
  restWholeLegerLine: {
    codepoint: 'U+E4F4',
  },
  reversedBrace: {
    codepoint: 'U+E001',
  },
  reversedBracketBottom: {
    codepoint: 'U+E006',
  },
  reversedBracketTop: {
    codepoint: 'U+E005',
  },
  rightRepeatSmall: {
    codepoint: 'U+E04D',
  },
  scaleDegree1: {
    codepoint: 'U+EF00',
  },
  scaleDegree2: {
    codepoint: 'U+EF01',
  },
  scaleDegree3: {
    codepoint: 'U+EF02',
  },
  scaleDegree4: {
    codepoint: 'U+EF03',
  },
  scaleDegree5: {
    codepoint: 'U+EF04',
  },
  scaleDegree6: {
    codepoint: 'U+EF05',
  },
  scaleDegree7: {
    codepoint: 'U+EF06',
  },
  scaleDegree8: {
    codepoint: 'U+EF07',
  },
  scaleDegree9: {
    codepoint: 'U+EF08',
  },
  schaefferClef: {
    codepoint: 'U+E06F',
  },
  schaefferFClefToGClef: {
    codepoint: 'U+E072',
  },
  schaefferGClefToFClef: {
    codepoint: 'U+E071',
  },
  schaefferPreviousClef: {
    codepoint: 'U+E070',
  },
  segno: {
    alternateCodepoint: 'U+1D10B',
    codepoint: 'U+E047',
  },
  segnoSerpent1: {
    codepoint: 'U+E04A',
  },
  segnoSerpent2: {
    codepoint: 'U+E04B',
  },
  semipitchedPercussionClef1: {
    codepoint: 'U+E06B',
  },
  semipitchedPercussionClef2: {
    codepoint: 'U+E06C',
  },
  smnFlat: {
    codepoint: 'U+EC52',
  },
  smnFlatWhite: {
    codepoint: 'U+EC53',
  },
  smnHistoryDoubleFlat: {
    codepoint: 'U+EC57',
  },
  smnHistoryDoubleSharp: {
    codepoint: 'U+EC55',
  },
  smnHistoryFlat: {
    codepoint: 'U+EC56',
  },
  smnHistorySharp: {
    codepoint: 'U+EC54',
  },
  smnNatural: {
    codepoint: 'U+EC58',
  },
  smnSharp: {
    codepoint: 'U+EC50',
  },
  smnSharpDown: {
    codepoint: 'U+EC59',
  },
  smnSharpWhite: {
    codepoint: 'U+EC51',
  },
  smnSharpWhiteDown: {
    codepoint: 'U+EC5A',
  },
  splitBarDivider: {
    codepoint: 'U+E00A',
  },
  staff1Line: {
    alternateCodepoint: 'U+1D116',
    codepoint: 'U+E010',
  },
  staff1LineNarrow: {
    codepoint: 'U+E01C',
  },
  staff1LineWide: {
    codepoint: 'U+E016',
  },
  staff2Lines: {
    alternateCodepoint: 'U+1D117',
    codepoint: 'U+E011',
  },
  staff2LinesNarrow: {
    codepoint: 'U+E01D',
  },
  staff2LinesWide: {
    codepoint: 'U+E017',
  },
  staff3Lines: {
    alternateCodepoint: 'U+1D118',
    codepoint: 'U+E012',
  },
  staff3LinesNarrow: {
    codepoint: 'U+E01E',
  },
  staff3LinesWide: {
    codepoint: 'U+E018',
  },
  staff4Lines: {
    alternateCodepoint: 'U+1D119',
    codepoint: 'U+E013',
  },
  staff4LinesNarrow: {
    codepoint: 'U+E01F',
  },
  staff4LinesWide: {
    codepoint: 'U+E019',
  },
  staff5Lines: {
    alternateCodepoint: 'U+1D11A',
    codepoint: 'U+E014',
  },
  staff5LinesNarrow: {
    codepoint: 'U+E020',
  },
  staff5LinesWide: {
    codepoint: 'U+E01A',
  },
  staff6Lines: {
    alternateCodepoint: 'U+1D11B',
    codepoint: 'U+E015',
  },
  staff6LinesNarrow: {
    codepoint: 'U+E021',
  },
  staff6LinesWide: {
    codepoint: 'U+E01B',
  },
  staffDivideArrowDown: {
    codepoint: 'U+E00B',
  },
  staffDivideArrowUp: {
    codepoint: 'U+E00C',
  },
  staffDivideArrowUpDown: {
    codepoint: 'U+E00D',
  },
  staffPosLower1: {
    codepoint: 'U+EB98',
  },
  staffPosLower2: {
    codepoint: 'U+EB99',
  },
  staffPosLower3: {
    codepoint: 'U+EB9A',
  },
  staffPosLower4: {
    codepoint: 'U+EB9B',
  },
  staffPosLower5: {
    codepoint: 'U+EB9C',
  },
  staffPosLower6: {
    codepoint: 'U+EB9D',
  },
  staffPosLower7: {
    codepoint: 'U+EB9E',
  },
  staffPosLower8: {
    codepoint: 'U+EB9F',
  },
  staffPosRaise1: {
    codepoint: 'U+EB90',
  },
  staffPosRaise2: {
    codepoint: 'U+EB91',
  },
  staffPosRaise3: {
    codepoint: 'U+EB92',
  },
  staffPosRaise4: {
    codepoint: 'U+EB93',
  },
  staffPosRaise5: {
    codepoint: 'U+EB94',
  },
  staffPosRaise6: {
    codepoint: 'U+EB95',
  },
  staffPosRaise7: {
    codepoint: 'U+EB96',
  },
  staffPosRaise8: {
    codepoint: 'U+EB97',
  },
  stem: {
    alternateCodepoint: 'U+1D165',
    codepoint: 'U+E210',
  },
  stemBowOnBridge: {
    codepoint: 'U+E215',
  },
  stemBowOnTailpiece: {
    codepoint: 'U+E216',
  },
  stemBuzzRoll: {
    codepoint: 'U+E217',
  },
  stemDamp: {
    codepoint: 'U+E218',
  },
  stemHarpStringNoise: {
    codepoint: 'U+E21F',
  },
  stemMultiphonicsBlack: {
    codepoint: 'U+E21A',
  },
  stemMultiphonicsBlackWhite: {
    codepoint: 'U+E21C',
  },
  stemMultiphonicsWhite: {
    codepoint: 'U+E21B',
  },
  stemPendereckiTremolo: {
    codepoint: 'U+E213',
  },
  stemRimShot: {
    codepoint: 'U+E21E',
  },
  stemSprechgesang: {
    alternateCodepoint: 'U+1D166',
    codepoint: 'U+E211',
  },
  stemSulPonticello: {
    codepoint: 'U+E214',
  },
  stemSussurando: {
    codepoint: 'U+E21D',
  },
  stemSwished: {
    codepoint: 'U+E212',
  },
  stemVibratoPulse: {
    codepoint: 'U+E219',
  },
  stockhausenTremolo: {
    codepoint: 'U+E232',
  },
  stringsBowBehindBridge: {
    codepoint: 'U+E618',
  },
  stringsBowBehindBridgeFourStrings: {
    codepoint: 'U+E62A',
  },
  stringsBowBehindBridgeOneString: {
    codepoint: 'U+E627',
  },
  stringsBowBehindBridgeThreeStrings: {
    codepoint: 'U+E629',
  },
  stringsBowBehindBridgeTwoStrings: {
    codepoint: 'U+E628',
  },
  stringsBowOnBridge: {
    codepoint: 'U+E619',
  },
  stringsBowOnTailpiece: {
    codepoint: 'U+E61A',
  },
  stringsChangeBowDirection: {
    codepoint: 'U+E626',
  },
  stringsDownBow: {
    alternateCodepoint: 'U+1D1AA',
    codepoint: 'U+E610',
  },
  stringsDownBowAwayFromBody: {
    codepoint: 'U+EE82',
  },
  stringsDownBowBeyondBridge: {
    codepoint: 'U+EE84',
  },
  stringsDownBowTowardsBody: {
    codepoint: 'U+EE80',
  },
  stringsDownBowTurned: {
    codepoint: 'U+E611',
  },
  stringsFouette: {
    codepoint: 'U+E622',
  },
  stringsHalfHarmonic: {
    codepoint: 'U+E615',
  },
  stringsHarmonic: {
    alternateCodepoint: 'U+1D1AC',
    codepoint: 'U+E614',
  },
  stringsJeteAbove: {
    codepoint: 'U+E620',
  },
  stringsJeteBelow: {
    codepoint: 'U+E621',
  },
  stringsMuteOff: {
    codepoint: 'U+E617',
  },
  stringsMuteOn: {
    codepoint: 'U+E616',
  },
  stringsOverpressureDownBow: {
    codepoint: 'U+E61B',
  },
  stringsOverpressureNoDirection: {
    codepoint: 'U+E61F',
  },
  stringsOverpressurePossibileDownBow: {
    codepoint: 'U+E61D',
  },
  stringsOverpressurePossibileUpBow: {
    codepoint: 'U+E61E',
  },
  stringsOverpressureUpBow: {
    codepoint: 'U+E61C',
  },
  stringsScrapeCircularClockwise: {
    codepoint: 'U+EE88',
  },
  stringsScrapeCircularCounterclockwise: {
    codepoint: 'U+EE89',
  },
  stringsScrapeParallelInward: {
    codepoint: 'U+EE86',
  },
  stringsScrapeParallelOutward: {
    codepoint: 'U+EE87',
  },
  stringsThumbPosition: {
    codepoint: 'U+E624',
  },
  stringsThumbPositionTurned: {
    codepoint: 'U+E625',
  },
  stringsTripleChopInward: {
    codepoint: 'U+EE8A',
  },
  stringsTripleChopOutward: {
    codepoint: 'U+EE8B',
  },
  stringsUpBow: {
    alternateCodepoint: 'U+1D1AB',
    codepoint: 'U+E612',
  },
  stringsUpBowAwayFromBody: {
    codepoint: 'U+EE83',
  },
  stringsUpBowBeyondBridge: {
    codepoint: 'U+EE85',
  },
  stringsUpBowTowardsBody: {
    codepoint: 'U+EE81',
  },
  stringsUpBowTurned: {
    codepoint: 'U+E613',
  },
  stringsVibratoPulse: {
    codepoint: 'U+E623',
  },
  swissRudimentsNoteheadBlackDouble: {
    codepoint: 'U+EE72',
  },
  swissRudimentsNoteheadBlackFlam: {
    codepoint: 'U+EE70',
  },
  swissRudimentsNoteheadHalfDouble: {
    codepoint: 'U+EE73',
  },
  swissRudimentsNoteheadHalfFlam: {
    codepoint: 'U+EE71',
  },
  systemDivider: {
    codepoint: 'U+E007',
  },
  systemDividerExtraLong: {
    codepoint: 'U+E009',
  },
  systemDividerLong: {
    codepoint: 'U+E008',
  },
  textAugmentationDot: {
    codepoint: 'U+E1FC',
  },
  textBlackNoteFrac16thLongStem: {
    codepoint: 'U+E1F5',
  },
  textBlackNoteFrac16thShortStem: {
    codepoint: 'U+E1F4',
  },
  textBlackNoteFrac32ndLongStem: {
    codepoint: 'U+E1F6',
  },
  textBlackNoteFrac8thLongStem: {
    codepoint: 'U+E1F3',
  },
  textBlackNoteFrac8thShortStem: {
    codepoint: 'U+E1F2',
  },
  textBlackNoteLongStem: {
    codepoint: 'U+E1F1',
  },
  textBlackNoteShortStem: {
    codepoint: 'U+E1F0',
  },
  textCont16thBeamLongStem: {
    codepoint: 'U+E1FA',
  },
  textCont16thBeamShortStem: {
    codepoint: 'U+E1F9',
  },
  textCont32ndBeamLongStem: {
    codepoint: 'U+E1FB',
  },
  textCont8thBeamLongStem: {
    codepoint: 'U+E1F8',
  },
  textCont8thBeamShortStem: {
    codepoint: 'U+E1F7',
  },
  textHeadlessBlackNoteFrac16thLongStem: {
    codepoint: 'U+E209',
  },
  textHeadlessBlackNoteFrac16thShortStem: {
    codepoint: 'U+E208',
  },
  textHeadlessBlackNoteFrac32ndLongStem: {
    codepoint: 'U+E20A',
  },
  textHeadlessBlackNoteFrac8thLongStem: {
    codepoint: 'U+E207',
  },
  textHeadlessBlackNoteFrac8thShortStem: {
    codepoint: 'U+E206',
  },
  textHeadlessBlackNoteLongStem: {
    codepoint: 'U+E205',
  },
  textHeadlessBlackNoteShortStem: {
    codepoint: 'U+E204',
  },
  textTie: {
    codepoint: 'U+E1FD',
  },
  textTuplet3LongStem: {
    codepoint: 'U+E202',
  },
  textTuplet3ShortStem: {
    codepoint: 'U+E1FF',
  },
  textTupletBracketEndLongStem: {
    codepoint: 'U+E203',
  },
  textTupletBracketEndShortStem: {
    codepoint: 'U+E200',
  },
  textTupletBracketStartLongStem: {
    codepoint: 'U+E201',
  },
  textTupletBracketStartShortStem: {
    codepoint: 'U+E1FE',
  },
  timeSig0: {
    codepoint: 'U+E080',
  },
  timeSig0Reversed: {
    codepoint: 'U+ECF0',
  },
  timeSig0Turned: {
    codepoint: 'U+ECE0',
  },
  timeSig1: {
    codepoint: 'U+E081',
  },
  timeSig1Reversed: {
    codepoint: 'U+ECF1',
  },
  timeSig1Turned: {
    codepoint: 'U+ECE1',
  },
  timeSig2: {
    codepoint: 'U+E082',
  },
  timeSig2Reversed: {
    codepoint: 'U+ECF2',
  },
  timeSig2Turned: {
    codepoint: 'U+ECE2',
  },
  timeSig3: {
    codepoint: 'U+E083',
  },
  timeSig3Reversed: {
    codepoint: 'U+ECF3',
  },
  timeSig3Turned: {
    codepoint: 'U+ECE3',
  },
  timeSig4: {
    codepoint: 'U+E084',
  },
  timeSig4Reversed: {
    codepoint: 'U+ECF4',
  },
  timeSig4Turned: {
    codepoint: 'U+ECE4',
  },
  timeSig5: {
    codepoint: 'U+E085',
  },
  timeSig5Reversed: {
    codepoint: 'U+ECF5',
  },
  timeSig5Turned: {
    codepoint: 'U+ECE5',
  },
  timeSig6: {
    codepoint: 'U+E086',
  },
  timeSig6Reversed: {
    codepoint: 'U+ECF6',
  },
  timeSig6Turned: {
    codepoint: 'U+ECE6',
  },
  timeSig7: {
    codepoint: 'U+E087',
  },
  timeSig7Reversed: {
    codepoint: 'U+ECF7',
  },
  timeSig7Turned: {
    codepoint: 'U+ECE7',
  },
  timeSig8: {
    codepoint: 'U+E088',
  },
  timeSig8Reversed: {
    codepoint: 'U+ECF8',
  },
  timeSig8Turned: {
    codepoint: 'U+ECE8',
  },
  timeSig9: {
    codepoint: 'U+E089',
  },
  timeSig9Reversed: {
    codepoint: 'U+ECF9',
  },
  timeSig9Turned: {
    codepoint: 'U+ECE9',
  },
  timeSigBracketLeft: {
    codepoint: 'U+EC80',
  },
  timeSigBracketLeftSmall: {
    codepoint: 'U+EC82',
  },
  timeSigBracketRight: {
    codepoint: 'U+EC81',
  },
  timeSigBracketRightSmall: {
    codepoint: 'U+EC83',
  },
  timeSigCombDenominator: {
    codepoint: 'U+E09F',
  },
  timeSigCombNumerator: {
    codepoint: 'U+E09E',
  },
  timeSigComma: {
    codepoint: 'U+E096',
  },
  timeSigCommon: {
    alternateCodepoint: 'U+1D134',
    codepoint: 'U+E08A',
  },
  timeSigCommonReversed: {
    codepoint: 'U+ECFA',
  },
  timeSigCommonTurned: {
    codepoint: 'U+ECEA',
  },
  timeSigCut2: {
    codepoint: 'U+EC85',
  },
  timeSigCut3: {
    codepoint: 'U+EC86',
  },
  timeSigCutCommon: {
    alternateCodepoint: 'U+1D135',
    codepoint: 'U+E08B',
  },
  timeSigCutCommonReversed: {
    codepoint: 'U+ECFB',
  },
  timeSigCutCommonTurned: {
    codepoint: 'U+ECEB',
  },
  timeSigEquals: {
    codepoint: 'U+E08F',
  },
  timeSigFractionHalf: {
    codepoint: 'U+E098',
  },
  timeSigFractionOneThird: {
    codepoint: 'U+E09A',
  },
  timeSigFractionQuarter: {
    codepoint: 'U+E097',
  },
  timeSigFractionThreeQuarters: {
    codepoint: 'U+E099',
  },
  timeSigFractionTwoThirds: {
    codepoint: 'U+E09B',
  },
  timeSigFractionalSlash: {
    codepoint: 'U+E08E',
  },
  timeSigMinus: {
    codepoint: 'U+E090',
  },
  timeSigMultiply: {
    codepoint: 'U+E091',
  },
  timeSigOpenPenderecki: {
    codepoint: 'U+E09D',
  },
  timeSigParensLeft: {
    codepoint: 'U+E094',
  },
  timeSigParensLeftSmall: {
    codepoint: 'U+E092',
  },
  timeSigParensRight: {
    codepoint: 'U+E095',
  },
  timeSigParensRightSmall: {
    codepoint: 'U+E093',
  },
  timeSigPlus: {
    codepoint: 'U+E08C',
  },
  timeSigPlusSmall: {
    codepoint: 'U+E08D',
  },
  timeSigSlash: {
    codepoint: 'U+EC84',
  },
  timeSigX: {
    codepoint: 'U+E09C',
  },
  tremolo1: {
    alternateCodepoint: 'U+1D167',
    codepoint: 'U+E220',
  },
  tremolo2: {
    alternateCodepoint: 'U+1D168',
    codepoint: 'U+E221',
  },
  tremolo3: {
    alternateCodepoint: 'U+1D169',
    codepoint: 'U+E222',
  },
  tremolo4: {
    codepoint: 'U+E223',
  },
  tremolo5: {
    codepoint: 'U+E224',
  },
  tremoloDivisiDots2: {
    codepoint: 'U+E22E',
  },
  tremoloDivisiDots3: {
    codepoint: 'U+E22F',
  },
  tremoloDivisiDots4: {
    codepoint: 'U+E230',
  },
  tremoloDivisiDots6: {
    codepoint: 'U+E231',
  },
  tremoloFingered1: {
    alternateCodepoint: 'U+1D16A',
    codepoint: 'U+E225',
  },
  tremoloFingered2: {
    alternateCodepoint: 'U+1D16B',
    codepoint: 'U+E226',
  },
  tremoloFingered3: {
    alternateCodepoint: 'U+1D16C',
    codepoint: 'U+E227',
  },
  tremoloFingered4: {
    codepoint: 'U+E228',
  },
  tremoloFingered5: {
    codepoint: 'U+E229',
  },
  tripleTongueAbove: {
    alternateCodepoint: 'U+1D18B',
    codepoint: 'U+E5F2',
  },
  tripleTongueBelow: {
    codepoint: 'U+E5F3',
  },
  tuplet0: {
    codepoint: 'U+E880',
  },
  tuplet1: {
    codepoint: 'U+E881',
  },
  tuplet2: {
    codepoint: 'U+E882',
  },
  tuplet3: {
    codepoint: 'U+E883',
  },
  tuplet4: {
    codepoint: 'U+E884',
  },
  tuplet5: {
    codepoint: 'U+E885',
  },
  tuplet6: {
    codepoint: 'U+E886',
  },
  tuplet7: {
    codepoint: 'U+E887',
  },
  tuplet8: {
    codepoint: 'U+E888',
  },
  tuplet9: {
    codepoint: 'U+E889',
  },
  tupletColon: {
    codepoint: 'U+E88A',
  },
  unmeasuredTremolo: {
    codepoint: 'U+E22C',
  },
  unmeasuredTremoloSimple: {
    codepoint: 'U+E22D',
  },
  unpitchedPercussionClef1: {
    alternateCodepoint: 'U+1D125',
    codepoint: 'U+E069',
  },
  unpitchedPercussionClef2: {
    alternateCodepoint: 'U+1D126',
    codepoint: 'U+E06A',
  },
  ventiduesima: {
    codepoint: 'U+E517',
  },
  ventiduesimaAlta: {
    codepoint: 'U+E518',
  },
  ventiduesimaBassa: {
    codepoint: 'U+E519',
  },
  ventiduesimaBassaMb: {
    codepoint: 'U+E51E',
  },
  vocalFingerClickStockhausen: {
    codepoint: 'U+E649',
  },
  vocalHalbGesungen: {
    codepoint: 'U+E64B',
  },
  vocalMouthClosed: {
    codepoint: 'U+E640',
  },
  vocalMouthOpen: {
    codepoint: 'U+E642',
  },
  vocalMouthPursed: {
    codepoint: 'U+E644',
  },
  vocalMouthSlightlyOpen: {
    codepoint: 'U+E641',
  },
  vocalMouthWideOpen: {
    codepoint: 'U+E643',
  },
  vocalNasalVoice: {
    codepoint: 'U+E647',
  },
  vocalSprechgesang: {
    codepoint: 'U+E645',
  },
  vocalTongueClickStockhausen: {
    codepoint: 'U+E648',
  },
  vocalTongueFingerClickStockhausen: {
    codepoint: 'U+E64A',
  },
  vocalsSussurando: {
    codepoint: 'U+E646',
  },
  wiggleArpeggiatoDown: {
    codepoint: 'U+EAAA',
  },
  wiggleArpeggiatoDownArrow: {
    codepoint: 'U+EAAE',
  },
  wiggleArpeggiatoDownSwash: {
    codepoint: 'U+EAAC',
  },
  wiggleArpeggiatoUp: {
    codepoint: 'U+EAA9',
  },
  wiggleArpeggiatoUpArrow: {
    codepoint: 'U+EAAD',
  },
  wiggleArpeggiatoUpSwash: {
    codepoint: 'U+EAAB',
  },
  wiggleCircular: {
    codepoint: 'U+EAC9',
  },
  wiggleCircularConstant: {
    codepoint: 'U+EAC0',
  },
  wiggleCircularConstantFlipped: {
    codepoint: 'U+EAC1',
  },
  wiggleCircularConstantFlippedLarge: {
    codepoint: 'U+EAC3',
  },
  wiggleCircularConstantLarge: {
    codepoint: 'U+EAC2',
  },
  wiggleCircularEnd: {
    codepoint: 'U+EACB',
  },
  wiggleCircularLarge: {
    codepoint: 'U+EAC8',
  },
  wiggleCircularLarger: {
    codepoint: 'U+EAC7',
  },
  wiggleCircularLargerStill: {
    codepoint: 'U+EAC6',
  },
  wiggleCircularLargest: {
    codepoint: 'U+EAC5',
  },
  wiggleCircularSmall: {
    codepoint: 'U+EACA',
  },
  wiggleCircularStart: {
    codepoint: 'U+EAC4',
  },
  wiggleGlissando: {
    codepoint: 'U+EAAF',
  },
  wiggleGlissandoGroup1: {
    codepoint: 'U+EABD',
  },
  wiggleGlissandoGroup2: {
    codepoint: 'U+EABE',
  },
  wiggleGlissandoGroup3: {
    codepoint: 'U+EABF',
  },
  wiggleRandom1: {
    codepoint: 'U+EAF0',
  },
  wiggleRandom2: {
    codepoint: 'U+EAF1',
  },
  wiggleRandom3: {
    codepoint: 'U+EAF2',
  },
  wiggleRandom4: {
    codepoint: 'U+EAF3',
  },
  wiggleSawtooth: {
    codepoint: 'U+EABB',
  },
  wiggleSawtoothNarrow: {
    codepoint: 'U+EABA',
  },
  wiggleSawtoothWide: {
    codepoint: 'U+EABC',
  },
  wiggleSquareWave: {
    codepoint: 'U+EAB8',
  },
  wiggleSquareWaveNarrow: {
    codepoint: 'U+EAB7',
  },
  wiggleSquareWaveWide: {
    codepoint: 'U+EAB9',
  },
  wiggleTrill: {
    codepoint: 'U+EAA4',
  },
  wiggleTrillFast: {
    codepoint: 'U+EAA3',
  },
  wiggleTrillFaster: {
    codepoint: 'U+EAA2',
  },
  wiggleTrillFasterStill: {
    codepoint: 'U+EAA1',
  },
  wiggleTrillFastest: {
    codepoint: 'U+EAA0',
  },
  wiggleTrillSlow: {
    codepoint: 'U+EAA5',
  },
  wiggleTrillSlower: {
    codepoint: 'U+EAA6',
  },
  wiggleTrillSlowerStill: {
    codepoint: 'U+EAA7',
  },
  wiggleTrillSlowest: {
    codepoint: 'U+EAA8',
  },
  wiggleVIbratoLargestSlower: {
    codepoint: 'U+EAEE',
  },
  wiggleVIbratoMediumSlower: {
    codepoint: 'U+EAE0',
  },
  wiggleVibrato: {
    codepoint: 'U+EAB0',
  },
  wiggleVibratoLargeFast: {
    codepoint: 'U+EAE5',
  },
  wiggleVibratoLargeFaster: {
    codepoint: 'U+EAE4',
  },
  wiggleVibratoLargeFasterStill: {
    codepoint: 'U+EAE3',
  },
  wiggleVibratoLargeFastest: {
    codepoint: 'U+EAE2',
  },
  wiggleVibratoLargeSlow: {
    codepoint: 'U+EAE6',
  },
  wiggleVibratoLargeSlower: {
    codepoint: 'U+EAE7',
  },
  wiggleVibratoLargeSlowest: {
    codepoint: 'U+EAE8',
  },
  wiggleVibratoLargestFast: {
    codepoint: 'U+EAEC',
  },
  wiggleVibratoLargestFaster: {
    codepoint: 'U+EAEB',
  },
  wiggleVibratoLargestFasterStill: {
    codepoint: 'U+EAEA',
  },
  wiggleVibratoLargestFastest: {
    codepoint: 'U+EAE9',
  },
  wiggleVibratoLargestSlow: {
    codepoint: 'U+EAED',
  },
  wiggleVibratoLargestSlowest: {
    codepoint: 'U+EAEF',
  },
  wiggleVibratoMediumFast: {
    codepoint: 'U+EADE',
  },
  wiggleVibratoMediumFaster: {
    codepoint: 'U+EADD',
  },
  wiggleVibratoMediumFasterStill: {
    codepoint: 'U+EADC',
  },
  wiggleVibratoMediumFastest: {
    codepoint: 'U+EADB',
  },
  wiggleVibratoMediumSlow: {
    codepoint: 'U+EADF',
  },
  wiggleVibratoMediumSlowest: {
    codepoint: 'U+EAE1',
  },
  wiggleVibratoSmallFast: {
    codepoint: 'U+EAD7',
  },
  wiggleVibratoSmallFaster: {
    codepoint: 'U+EAD6',
  },
  wiggleVibratoSmallFasterStill: {
    codepoint: 'U+EAD5',
  },
  wiggleVibratoSmallFastest: {
    codepoint: 'U+EAD4',
  },
  wiggleVibratoSmallSlow: {
    codepoint: 'U+EAD8',
  },
  wiggleVibratoSmallSlower: {
    codepoint: 'U+EAD9',
  },
  wiggleVibratoSmallSlowest: {
    codepoint: 'U+EADA',
  },
  wiggleVibratoSmallestFast: {
    codepoint: 'U+EAD0',
  },
  wiggleVibratoSmallestFaster: {
    codepoint: 'U+EACF',
  },
  wiggleVibratoSmallestFasterStill: {
    codepoint: 'U+EACE',
  },
  wiggleVibratoSmallestFastest: {
    codepoint: 'U+EACD',
  },
  wiggleVibratoSmallestSlow: {
    codepoint: 'U+EAD1',
  },
  wiggleVibratoSmallestSlower: {
    codepoint: 'U+EAD2',
  },
  wiggleVibratoSmallestSlowest: {
    codepoint: 'U+EAD3',
  },
  wiggleVibratoStart: {
    codepoint: 'U+EACC',
  },
  wiggleVibratoWide: {
    codepoint: 'U+EAB1',
  },
  wiggleWavy: {
    codepoint: 'U+EAB5',
  },
  wiggleWavyNarrow: {
    codepoint: 'U+EAB4',
  },
  wiggleWavyWide: {
    codepoint: 'U+EAB6',
  },
  windClosedHole: {
    codepoint: 'U+E5F4',
  },
  windFlatEmbouchure: {
    codepoint: 'U+E5FB',
  },
  windHalfClosedHole1: {
    codepoint: 'U+E5F6',
  },
  windHalfClosedHole2: {
    codepoint: 'U+E5F7',
  },
  windHalfClosedHole3: {
    codepoint: 'U+E5F8',
  },
  windLessRelaxedEmbouchure: {
    codepoint: 'U+E5FE',
  },
  windLessTightEmbouchure: {
    codepoint: 'U+E600',
  },
  windMouthpiecePop: {
    codepoint: 'U+E60A',
  },
  windMultiphonicsBlackStem: {
    codepoint: 'U+E607',
  },
  windMultiphonicsBlackWhiteStem: {
    codepoint: 'U+E609',
  },
  windMultiphonicsWhiteStem: {
    codepoint: 'U+E608',
  },
  windOpenHole: {
    codepoint: 'U+E5F9',
  },
  windReedPositionIn: {
    codepoint: 'U+E606',
  },
  windReedPositionNormal: {
    codepoint: 'U+E604',
  },
  windReedPositionOut: {
    codepoint: 'U+E605',
  },
  windRelaxedEmbouchure: {
    codepoint: 'U+E5FD',
  },
  windRimOnly: {
    codepoint: 'U+E60B',
  },
  windSharpEmbouchure: {
    codepoint: 'U+E5FC',
  },
  windStrongAirPressure: {
    codepoint: 'U+E603',
  },
  windThreeQuartersClosedHole: {
    codepoint: 'U+E5F5',
  },
  windTightEmbouchure: {
    codepoint: 'U+E5FF',
  },
  windTrillKey: {
    codepoint: 'U+E5FA',
  },
  windVeryTightEmbouchure: {
    codepoint: 'U+E601',
  },
  windWeakAirPressure: {
    codepoint: 'U+E602',
  },
};
